/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/** 
 * @file     WebSocket.cpp 
 * @brief    Implementation of WebSocket.
 */

#include "WebSocket.h"
#include "Log.h"

#include <openssl/sha.h>
#include <boost/archive/iterators/base64_from_binary.hpp>  
#include <boost/archive/iterators/binary_from_base64.hpp>  
#include <boost/archive/iterators/transform_width.hpp> 
#include <string>  
#include <iostream>  
#include <sstream> 
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>

const uint32_t MESSAGE_LENGTH = 2048;
const uint32_t PATH_LENGTH = 128;
const uint32_t WEBSOCKET_KEY_SIZE = 1024;
const uint32_t SHA1_BUFFER_SIZE = 64;

pthread_cond_t CWebSocket::cond = PTHREAD_COND_INITIALIZER;  
pthread_mutex_t CWebSocket::lock = PTHREAD_MUTEX_INITIALIZER;  

CWebSocket::CWebSocket(void)
{
    m_hSocket = 0;
    port = 0;
    maxListeners = 0;
    dataHandFunction = NULL;
    listLock=PTHREAD_MUTEX_INITIALIZER;
}

CWebSocket::~CWebSocket(void)
{
    if(0 != m_hSocket) {
        close(m_hSocket);
    }

    m_hSocket = 0;
    port = 0;
    maxListeners = 0;
}

void CWebSocket::initSocket(string hostIp, int portNo, int maxLis)
{
    ip = hostIp;
    port = portNo;
    maxListeners = maxLis;
    dataHandFunction = &websocketHandAConnection;
    return;
}

bool CWebSocket::startListenThread() 
{ 
    SOCKET sSocket = 0;
    SocketInfo info;
    info.ws = this;    
    
    m_hSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(INVALID_SOCKET == m_hSocket) {
        MECFCGI_LOG(ERR, "socket() failed, errno[%d], errmsg[%s]\n", 
            errno, strerror(errno));
        return false;
    }

    int reuseAddr = 1;
    if (0 != setsockopt(m_hSocket, SOL_SOCKET, SO_REUSEADDR, &reuseAddr, 
        sizeof(reuseAddr))) {
        MECFCGI_LOG(ERR, 
            "setsockopt() socket[%d] failed, errno[%d], errmsg[%s]\n", 
            m_hSocket, errno, strerror(errno));
        close(m_hSocket);
        return false;
    }

    sockaddr_in sin;
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = htons(INADDR_ANY); 

    if(SOCKET_ERROR == bind(m_hSocket, (struct sockaddr*)&sin, sizeof(sin))) {
        MECFCGI_LOG(ERR, "bind() socket[%d] failed, errno[%d], errmsg[%s]\n", 
            m_hSocket, errno, strerror(errno));
        close(m_hSocket);
        return false;
    }
    
    if(SOCKET_ERROR == listen(m_hSocket, maxListeners)) {
        MECFCGI_LOG(ERR, "listen() socket[%d] failed, errno[%d], errmsg[%s]\n", 
            m_hSocket, errno, strerror(errno));
        close(m_hSocket);
        return false;
    }

    while(true) {
        sockaddr_in remoteAddr;
        socklen_t nAddrlen = sizeof(remoteAddr);

        sSocket = accept(m_hSocket, (struct sockaddr*)&remoteAddr, &nAddrlen);

        if(INVALID_SOCKET == sSocket) {
            MECFCGI_LOG(ERR, "accept() failed, errno[%d], errmsg[%s]\n", errno, 
                strerror(errno));
            return false;
        }
        
        info.clSock = sSocket;
        pthread_t threadID;
        
        pthread_mutex_lock(&lock);  
        pthread_create(&threadID, 0, dataHandFunction, &info);        
        pthread_cond_wait(&cond, &lock);     
        pthread_mutex_unlock(&lock);  
    }
    MECFCGI_LOG(ERR, "Listen thread error.");
    return false;
}

bool Base64Encode(const string &input, string *output) {  
    typedef boost::archive::iterators::base64_from_binary<boost::archive::
            iterators::transform_width<string::const_iterator, 6, 8> > 
            Base64EncodeIter;  
    stringstream result;  
    copy(Base64EncodeIter(input.begin()) , Base64EncodeIter(input.end()), 
        ostream_iterator<char>(result));  
    size_t equal_count = (3 - input.length() % 3) % 3;  
    for (size_t i = 0; i < equal_count; i++) {  
        result.put('=');  
    }  
    *output = result.str();  
    return (false == output->empty());  
}

char* CWebSocket::get_hand_shake_msg(char *dest, char *req, string &token)
{
    if (NULL == dest || NULL == req) {
        MECFCGI_LOG(ERR, "Pointer is NULL.");
        return NULL;
    }

    char *secwebSocketKey = NULL;
    
    char *path = NULL;
    path = strstr(req, "/notifications");
    if(NULL == path) {
        return NULL;
    }
    char fullPath[PATH_LENGTH];
    memset(fullPath, 0, sizeof(fullPath));

    int j = 0;
    while(*path != ' ') {
        fullPath[j++] = *path;
        path++;
    }
    string strPath(fullPath);

    istringstream sstrPath(strPath);// "/notifications/token"
    getline(sstrPath, token, '/');  // ""
    getline(sstrPath, token, '/');  // "notifications"
    getline(sstrPath, token);       // "token"

    secwebSocketKey = strstr(req, "Sec-WebSocket-Key:");
    if(NULL == secwebSocketKey) {
        return NULL;
    }

    char tSecwebSocketKey[WEBSOCKET_KEY_SIZE];
    memset(tSecwebSocketKey, 0, sizeof(tSecwebSocketKey));

    char *start = strstr(secwebSocketKey, ":");

    // ": SocketKey" --> "SocketKey"
    start += 2;

    int kk = 0;
    while((*start != '\r')&&(*start != '\n')) {
        tSecwebSocketKey[kk++] = *start;
        start++;
    }

    tSecwebSocketKey[kk] = 0;
    const char *guid = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    strncat(tSecwebSocketKey, guid, strlen(guid));

    char tbuffer[SHA1_BUFFER_SIZE];
    memset(tbuffer, 0, sizeof(tbuffer));

    get_sha1_string(tbuffer, tSecwebSocketKey);

    string base64;  
    Base64Encode(tbuffer, &base64);

    string resp;
    resp += "HTTP/1.1 101 Switching Protocols\r\n";
    resp += "Connection: Upgrade\r\n";
    resp += "Upgrade: WebSocket\r\n";
    resp += "Sec-WebSocket-Accept: " + base64 + "\r\n";
    resp += "\r\n";

    memcpy(dest, (char*)resp.c_str(), strlen((char*)resp.c_str()));
    return dest;
}

static int g_GetEncodeOutgoingMsg(char *msg, char *data)
{
    if (NULL == msg || NULL == data) {
        MECFCGI_LOG(ERR, "Pointer is NULL.");
        return 0;
    }

    int64_t payloadSize = strlen(data);

    int steps = 0;
    char payloadFlags = 129;
    msg[steps] = payloadFlags; steps++;

    //create the length byte(s)
    // * The 7 least-significant bits (LSB) of the 2nd byte represents the 
    // length of the data, but values 126 and 127 are reserved by the protocol. 
    // * So when the length of the data is less than 125, the length of the data
    // is recorded in the 7 LSBs of the 2nd byte.
    // * If the length is greater than 125 but less than or equal to 65535,
    // the value 126 is put into the 7 LSBs of the 2nd byte, and the length of
    // the data is recorded in the 3rd and the 4th bytes (two bytes in total).
    // * If the length of the data is greater than 65535 (0xFFFF), the value 127
    // is recorded in the 7 LSBs of the 2nd byte, and the length of the data is
    // recorded in the 3rd through 10th bytes.
    if (payloadSize <= 125) {
        char basicSize = (char)payloadSize;
        msg[steps] = basicSize; steps++;
    } else if ((payloadSize > 125) & (payloadSize <= 65535)) {
        char basicSize = 126;
        msg[steps] = basicSize; steps++;

        char len[2];
        len[0] = ( payloadSize >> 8 ) & 255;
        len[1] = ( payloadSize ) & 255;
        msg[steps] = len[0]; steps++;
        msg[steps] = len[1]; steps++;
    } else {
        char basicSize = 127;
        msg[steps] = basicSize; steps++;

        char len[8];
        len[0] = ( payloadSize >> 56 ) & 255;
        len[1] = ( payloadSize >> 48  ) & 255;
        len[2] = ( payloadSize >> 40 ) & 255;
        len[3] = ( payloadSize >> 32  ) & 255;
        len[4] = ( payloadSize >> 24 ) & 255;
        len[5] = ( payloadSize >> 16  ) & 255;
        len[6] = ( payloadSize >> 8 ) & 255;
        len[7] = ( payloadSize ) & 255;
        for(int i=0; i<8; i++) {
            msg[steps] = len[i]; steps++;
        }
    }

    memcpy(msg+steps, data, payloadSize);

    return payloadSize + steps;    
}

int CWebSocket::getEncodeOutgoingMsg(char *msg, char *data)
{
    return g_GetEncodeOutgoingMsg(msg, data);
}

void CWebSocket::get_sha1_string(char *dest, char *source)
{
    SHA_CTX shactx;
    unsigned char md[SHA_DIGEST_LENGTH];
    SHA1_Init(&shactx);  
    SHA1_Update(&shactx, (unsigned char *)source, strlen(source)); 
    SHA1_Final(md, &shactx);
    strncpy(dest, (char *)md, SHA_DIGEST_LENGTH);
    return;
}

bool CWebSocket::setNewSocket(string token, SOCKET sock)
{
    bool ret = true;
    if(token.length() > 0) {
        pthread_mutex_lock(&listLock);       
        map<string, SOCKET>::iterator iter = clientList.find(token);
        if(iter != clientList.end()) {
            close(iter->second);
            clientList.erase(iter);
            clientList.insert(pair<string, SOCKET>(token, sock));
        } else {
            clientList.insert(pair<string, SOCKET>(token, sock));
        }
        pthread_mutex_unlock(&listLock);  
    } else {
        ret = false;
        MECFCGI_LOG(ERR, "Parameter token error.\n");
    }
    return ret;
}

bool CWebSocket::closeSocket(string token)
{
    bool ret = true;
    if(token.length() > 0) {
        pthread_mutex_lock(&listLock);       
        map<string, SOCKET>::iterator iter = clientList.find(token);
        if(iter != clientList.end()) {
            close(iter->second);
            clientList.erase(iter);
        } else {
            MECFCGI_LOG(ERR, "token does not exist: %s.\n", token.c_str());
            ret = false;
        }
        pthread_mutex_unlock(&listLock);  
    } else {
        ret = false;
        MECFCGI_LOG(ERR, "Token error.\n");
    }
    return ret;
}

void *CWebSocket::websocketHandAConnection(void *parm)
{
    SOCKET sClient = -1;
    int ret = 0;
    char revData[RECV_BUFF] = {0};
    char headMsg[HEAD_BUFF] = {0};
    char localData[LOCAL_BUFF] = {0};

    string token="";

    SocketInfo *info = (SocketInfo *)parm;
    if(NULL == info) {
        MECFCGI_LOG(ERR, "Parameter is NULL.\n");
        return 0;
    }

    CWebSocket *pWebSocket = info->ws;
    
    sClient = info->clSock;

    memset(revData, 0, RECV_BUFF);
    memset(headMsg, 0, HEAD_BUFF);
    memset(localData, 0, LOCAL_BUFF);

    int totalLen = 0;
    int i = 0;

    pthread_mutex_lock(&lock);  
    pthread_cond_signal(&cond);  
    pthread_mutex_unlock(&lock);  
    
    while(1) {
        ret = recv(sClient, revData, RECV_BUFF, 0);
        if(ret <= 0) {
            continue;
        }
        
        for(i = 0; i < ret; i++) {
            localData[totalLen] = revData[i];
            totalLen++;
        }
        
        //Invalid packet, continue to receive
        if(totalLen < 5) {
            continue;
        }
        
        //The end of the packet is "\r\n\r\n".
        if(('\r' == localData[totalLen - 4]) &&
           ('\n' == localData[totalLen - 3]) &&
           ('\r' == localData[totalLen - 2]) &&
           ('\n' == localData[totalLen - 1])) {
            break;
        }
    }

    if(pWebSocket->get_hand_shake_msg(headMsg, localData, token)) {
        send(sClient, headMsg, strlen(headMsg), 0);
        bool ret = pWebSocket->setNewSocket(token, sClient);
        if(false == ret) {
            MECFCGI_LOG(ERR, "New client connection failed, token: %s : \
                sClient: %d.\n", token.c_str(), sClient);
            close(sClient);
            sClient = -1;
        } else {
            MECFCGI_LOG(INFO, "New client connection established, token: %s : \
                sClient: %d.\n", token.c_str(), sClient);
        }
    } else {
        MECFCGI_LOG(ERR, "New client connection failed, token: %s : \
            sClient: %d.\n", token.c_str(), sClient);
        close(sClient);
        sClient = -1;
    }
    return 0;
}    
int CWebSocket::sendEventToClient(string token, char *pdata, int size)
{
    SOCKET sClient = -1;

    pthread_mutex_lock(&listLock);
    map<string, SOCKET>::iterator iter = clientList.find(token);
    if(iter != clientList.end()) {
        sClient = iter->second;
    }
    pthread_mutex_unlock(&listLock);
    
    if(-1 == sClient) {
        MECFCGI_LOG(ERR, "Sock token is invalid: %s.\n", token.c_str());
        return -1;
    }
    if (size <= 0) {
        MECFCGI_LOG(ERR, "Data size is invalid: %d.\n", size);
        return -1;
    }
    if (NULL == pdata) {
        MECFCGI_LOG(ERR, "pdata is null.\n");
        return -1;
    }

    unsigned char strBuffSendTrue[MESSAGE_LENGTH];
    memset(strBuffSendTrue, 0, sizeof(strBuffSendTrue));
    
    int strLen = getEncodeOutgoingMsg((char *)strBuffSendTrue, (char *)pdata);    
    int len = send(sClient, (char *)strBuffSendTrue, strLen, 0);

    return len;
}

void CWebSocket::pushData(string target, const string eventId, string data)
{
    sendEventToClient(target, (char*)data.c_str(), data.length());
}