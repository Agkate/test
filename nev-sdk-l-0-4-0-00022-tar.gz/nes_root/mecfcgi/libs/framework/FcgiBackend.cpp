/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  FcgiBackend.cpp
* @brief FastCGI backend manager for Mobile Edge Applications.
*/

#include "FcgiBackend.h"
#include "Log.h"
#include <boost/asio.hpp>
#include "Exception.h"

using namespace boost::asio;

FcgiBackend::nginx_info_t FcgiBackend::nginxInfo;
const int FCGX_BACKLOG = 99;

void FcgiBackend::setNginxInfo(string hostIp, uint16_t hostPort, string fastcgiPass)
{
    nginxInfo.hostIp = hostIp;
    nginxInfo.hostPort = hostPort;
    nginxInfo.fastcgiPass = fastcgiPass;
}

void FcgiBackend::run(RawRequest &raw)
{
    FCGX_Request request;
    FCGX_Init();
    dup2(FCGX_OpenSocket(nginxInfo.fastcgiPass.c_str(), FCGX_BACKLOG), 0);
    FCGX_InitRequest(&request, 0, 0);

    while (0 == FCGX_Accept_r(&request)) {
        fcgi_streambuf cin_fcgi_streambuf(request.in);
        fcgi_streambuf cout_fcgi_streambuf(request.out);
        std::streambuf* in_backup = cin.rdbuf(&cin_fcgi_streambuf);
        std::streambuf* out_backup = cout.rdbuf(&cout_fcgi_streambuf);

        try {
            raw.dispatch(request);
        }
        catch (Exception &e) {
            switch(e.code) {
                case Exception::DISPATCH_NOTARGET:
                    cout << "Status: 404 Not Found\r\n\r\n";
                    break;
                case Exception::DISPATCH_NOTYPE:
                    cout << "Status: 406 Not Acceptable\r\n\r\n";
                    break;
                case Exception::PARSING_JSON_BODY:
                    cout << "Status: 400 Bad Request\r\n\r\n";
                    break;
                case Exception::SESSION_INV:
                    cout << "Status: 403 Forbidden\r\n\r\n";
                    break;
                default:
                    cout << "Status: 520 Unknown Error\r\n\r\n";
            }
            MECFCGI_LOG(ERR, "ERROR(%d):%s \n", e.code, e.err.c_str());
        }
        catch (runtime_error::exception &e) {
            MECFCGI_LOG(ERR, "%s \n",  e.what());
        }
        cin.rdbuf(in_backup);
        cout.rdbuf(out_backup);
    }
}


