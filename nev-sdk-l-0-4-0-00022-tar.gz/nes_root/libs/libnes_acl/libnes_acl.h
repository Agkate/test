/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file libnes_acl.h
 * @brief Header file for libnes_acl
 */
#ifndef _LIBNES_ACL_H
#define	_LIBNES_ACL_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <rte_acl.h>
#include <rte_spinlock.h>
#include <assert.h>

#define USER_DATA_OFFSET 1
#define MAX_DATA_NUM 64
#define DEFAULT_CATEGORIES 1

typedef struct nes_acl_ctx_s {
    struct rte_acl_ctx *acl_ctx;
    rte_spinlock_t acl_lock;

    char names[2][RTE_ACL_NAMESIZE];
    uint8_t name_id;

    void **entries;
    uint32_t entry_size;
    uint32_t entries_cnt;
    uint32_t max_entries;

    struct rte_acl_rule **rules;
    struct rte_acl_field_def* acl_fields_def;
    uint32_t acl_fields_cnt;
} nes_acl_ctx_t;


int nes_acl_ctor(nes_acl_ctx_t *ctx, const char *context_name, uint32_t entry_size, uint32_t max_entries_cnt, struct rte_acl_field_def* acl_fields_def, uint32_t acl_fields_cnt);
void nes_acl_dtor(nes_acl_ctx_t *ctx);
int nes_acl_add_entries(nes_acl_ctx_t *ctx, void **entries, struct rte_acl_rule **rules, uint32_t count);
int nes_acl_del_entry(nes_acl_ctx_t *ctx, struct rte_acl_rule * rule);
int nes_acl_find_rule_id(nes_acl_ctx_t *ctx, struct rte_acl_rule * rule);

static inline void
nes_acl_lookup(nes_acl_ctx_t* ctx, const uint8_t **data, uint32_t data_cnt, void **entries) {  
    assert(ctx);
    
    uint32_t results[MAX_DATA_NUM] = { 0 };
    uint32_t i;
    
    memset(entries, 0, data_cnt * sizeof(void*));
    if (unlikely(NULL == ctx->acl_ctx)) {
        return;
    }

    rte_spinlock_lock(&ctx->acl_lock);
    if (likely(NULL != ctx->acl_ctx)) {
        rte_acl_classify(ctx->acl_ctx, data, results, data_cnt, DEFAULT_CATEGORIES);
    }
    rte_spinlock_unlock(&ctx->acl_lock);
    for (i = 0; i < data_cnt; i++) {
        if (results[i]) {
            entries[i] = ctx->entries[results[i] - USER_DATA_OFFSET];
        }
    }
}

#ifdef	__cplusplus
}
#endif

#endif	/* _LIBNES_ACL_H */
