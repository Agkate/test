/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file     PasswordHash.cpp
* @brief    Password hashing implementation
*/

#include <sstream>
#include <algorithm>
#include <iomanip>

#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/buffer.h>
#include <openssl/rand.h>

#include "PasswordHash.h"
#include "Log.h"

using std::string;
using std::vector;

const uint32_t keylen = 64;
const int32_t iterations = 4096;
const int32_t salt_len = 2;
const char salt_separator = '_';

static string byteToHex(const vector<uint8_t> &data)
{
    std::stringstream strs;
    strs << std::hex << std::setfill('0');
    for (const uint8_t &byte : data)
        strs << std::setw(2) << (int)byte;

    return strs.str();
}

static bool hexToByte(const string &data, vector<uint8_t> &res)
{
    if (data.length() % 2) {
        MECFCGI_LOG(ERR, "[PasswordHash] Bad data length\n");
        return false;
    }

    res.resize(data.length() / 2);
    for (size_t i = 0; i < data.length(); i += 2) {
        if (1 != sscanf(data.c_str() + i, "%2hhx", &res[i / 2])) {
            MECFCGI_LOG(ERR, "[PasswordHash] Failed to parse hex byte\n");
            return false;
        }
    }

    return true;
}

static bool genSalt(uint8_t len, vector<uint8_t> &res)
{
    if (len < 1)
        return false;
    res.resize(len);

    if (!RAND_bytes(res.data(), len))
        return false;

    return true;
}

static bool getSalt(const string &hash, vector<uint8_t> &salt)
{
    std::size_t salt_pos = hash.rfind(salt_separator);

    if (string::npos == salt_pos || (hash.length() - salt_pos) == 0)
        return false;

    string salt_str = hash.substr(salt_pos + 1);
    return hexToByte(salt_str, salt);
}

static bool pbkdf2(const string &password, const vector<uint8_t> &salt, string &res)
{
    vector<uint8_t> digest(keylen);
    if (!PKCS5_PBKDF2_HMAC(password.c_str(), password.length(), salt.data(),
                salt.size(), iterations, EVP_sha512(), keylen, digest.data()))
        return false;
    res = byteToHex(digest) + salt_separator + byteToHex(salt);
    return true;
}

bool PasswordHash::hash(const string &password, string &password_hash)
{
    vector<uint8_t> salt;
    if (!genSalt(salt_len, salt)) {
        MECFCGI_LOG(ERR, "[PasswordHash] Failed to generate salt\n");
        return false;
    }
    return pbkdf2(password, salt, password_hash);
}

bool PasswordHash::verify(const string &password_hash, const string &password)
{
    vector<uint8_t> salt;
    string expected_hash;

    if (!getSalt(password_hash, salt)) {
        MECFCGI_LOG(ERR, "[PasswordHash] Failed to get salt\n");
        return false;
    }

    if (!pbkdf2(password, salt, expected_hash)) {
        MECFCGI_LOG(ERR, "[PasswordHash] Failed to hash password\n");
        return false;
    }
    return (0 == password_hash.compare(expected_hash));
}
