/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file     Common.cpp
* @brief    Commonly-used function implementaitons.
*/

#include "SessionManager.h"
#include "ServiceRegistryPort.h"
#include "Exception.h"
#include "HandlerCommon.h"
#include "DbManager.h"
#include "Log.h"
#include "RawRequest.h"
#include "NesPortFactory.h"
#include "WebSocketServer.h"

/**
 * @brief            Uses an ME App's token to deactivate all of its services,
 *                   and then pushes ServiceAvailabilityChange to all ME Apps.
 * @param[in]        token     ME App's token (reference ID).
 * @return           void
 */
static void deactivationService(string token);

void HandlerCommon::delMeAppInformation(string appid)
{
    string token = "";
    DbManager::getSessionByAppid(token, appid);

    bool exist;
    string appType;
    DbManager::checkAndGetAppTypeByAppid(exist, appType, appid);

    if (!exist){
        MECFCGI_LOG(ERR, "ME App type does not exist.\n");
        throw Exception(Exception::APPID_NOT_EXIST);
    }

    if (0 == appType.compare(MEAPP_TYPE_MEAPPSERVICE)){
        // Notifications are sent to all of its subscribers.
        deactivationService(token);
    }

    // Delete subscribed service list.
    DbManager::delServiceSubscriptionListByToken(token);

    // Delete traffic rules info.
    DbManager::StringArrayType trafficRuleIdList;
    DbManager::getTrafficRuleIdList(trafficRuleIdList);
    if (trafficRuleIdList.size() > 0) {
        for (string &trafficRuleId_ : trafficRuleIdList) {
            string trafficRuleToken;
            istringstream ssTrafficRuleId(trafficRuleId_);
            getline(ssTrafficRuleId, trafficRuleId_, SPLIT_MARK);
            getline(ssTrafficRuleId, trafficRuleId_);
            DbManager::getTrafficRuleTokenByRuleId(trafficRuleToken,
                trafficRuleId_);
            if(0 == trafficRuleToken.compare(token)){
                string lookupKeys;
                DbManager::getTrafficRuleLookupByRuleId(lookupKeys,
                    trafficRuleId_);
                NesPort::RemoveRoute removeRoute;
                removeRoute.lookupKeys = lookupKeys;
                NesPortFactory::getInstance().removeRoute (removeRoute);
                DbManager::delTrafficRulesInfo(trafficRuleId_);
            }
        }
    }
    // Delete ME App info.
    DbManager::clearMeAppInfo(appid);
    // Close websocket connection.
    getWebServer()->closeSocket(token);

    // Delete ME App token.
    SessionManager::deleteSession(token);
}

void deactivationService(string token)
{
    string appid;
    DbManager::StringArrayType activatedServiceIdList;
    DbManager::getActivatedServiceIdList(activatedServiceIdList);
    SessionManager::getAppidBySession(token, appid);
    if (activatedServiceIdList.size() > 0) {
        for (string &activatedServiceId_ : activatedServiceIdList) {
            string activatedServiceId = "";
            string activatedServiceName = "";
            string activatedServiceToken = "";
            string activatedServiceVersion = "";
            string activatedServiceEndPoint = "";
            string activatedServiceType = "";
            istringstream ssActivatedService(activatedServiceId_);
            // MeAPS:serviceId
            getline(ssActivatedService, activatedServiceId, SPLIT_MARK);
            getline(ssActivatedService, activatedServiceId);
            DbManager::getActivatedServiceToken(activatedServiceId,
                activatedServiceToken);
            if (0 == activatedServiceToken.compare(token)){
                DbManager::getActivatedServiceName(activatedServiceId,
                                                    activatedServiceName);
                Json::Value subscriberAppidList;
                ServiceRegistryPort::getAppidListFromServiceRegistry(
                    subscriberAppidList, activatedServiceName, appid);
                    
                DbManager::getActivatedServiceVersion(activatedServiceId, 
                                                    activatedServiceVersion);
                DbManager::getActivatedServiceEndPoint(activatedServiceId, 
                                                    activatedServiceEndPoint);
                DbManager::getActivatedServiceServiceType(activatedServiceId,
                                                    activatedServiceType);
                Json::Value serviceInfo;
                serviceInfo["serviceId"] = activatedServiceId;
                serviceInfo["serviceName"] = activatedServiceName;
                serviceInfo["version"] = activatedServiceVersion;
                serviceInfo["endPoint"] = activatedServiceEndPoint;
                serviceInfo["serviceType"] = activatedServiceType;

                Json::Value message;
                message["id"] = "ServiceAvailabilityChange";
                message["data"] = serviceInfo;                                
                Json::FastWriter writer;
                string sMessage = writer.write(message);
                int size = subscriberAppidList.size();
                for (int i = 0; i < size; i++) {
                    string subscriberAppid_ =
                        subscriberAppidList[i].get(
                            "appid", "Nil").asString();
                    try {
                        string subscriberToken;
                        DbManager::getSessionByAppid(subscriberToken,
                                                        subscriberAppid_);
                        getWebServer()->pushData(subscriberToken,
                            "ServiceAvailabilityChange", sMessage);
                    } catch (Exception &e) {
                        if (e.code != Exception::APPID_NOT_EXIST) {
                            MECFCGI_LOG(ERR, "Database error.\n");
                            throw;
                        }
                    }
                }
                DbManager::delActivatedServiceByServiceId(activatedServiceId);
            }
        }
    }
}