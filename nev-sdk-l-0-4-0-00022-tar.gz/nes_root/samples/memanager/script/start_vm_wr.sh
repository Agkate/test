#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################
VM0_CFG_MAC=525400000001
VM0_CFG_VCPUPIN='0,0x20,0'

VM1_CFG_MAC=525400000002
VM1_CFG_VCPUPIN='0,0x40,0'

VM2_CFG_MAC=525400000003
VM2_CFG_VCPUPIN='0,0x80,0'

VM3_CFG_MAC=525400000004
VM3_CFG_VCPUPIN='0,0x100,0'

FLAVOR_TYPE=m1.localvnic

source /etc/nova/openrc
export PHYSNET1='physnet1'
export PHYSNET2='physnet2'
export MGMT_NET='tenant-mgmt-net'
export MGMT_SUBNET='tenant-mgmt-subnet'
export TENANT_NET1='tenant-net1'
export TENANT_NET2='tenant-net2'
export TENANT_SUBNET1='tenant-subnet1'
export TENANT_SUBNET2='tenant-subnet2'
export PUBLICROUTER='public-router0'
export tenant_mgmt_net_UUID=`neutron net-list | grep ${MGMT_NET} | awk '{print $2}'`
export tenant_net1_UUID=`neutron net-list | grep ${TENANT_NET1} | awk '{print $2}'`
export tenant_net2_UUID=`neutron net-list | grep ${TENANT_NET2} | awk '{print $2}'`
sleep 2

function start_VM(){
    vmid=vm${2}
    nova boot \
    --flavor ${FLAVOR_TYPE} \
    --image ${1} \
    --nic net-id=${tenant_mgmt_net_UUID} \
    --nic net-id=${tenant_net2_UUID} \
    --security-group default ${vmid} \
    --meta vhost=usvhost-1:${3} \
    --meta vcpupin=${4}
    test $? = 0 || exit -1
}

case $2 in
"0" ) start_VM $1 $2 ${VM0_CFG_MAC} ${VM0_CFG_VCPUPIN} ;;
"1" ) start_VM $1 $2 ${VM1_CFG_MAC} ${VM1_CFG_VCPUPIN} ;;
"2" ) start_VM $1 $2 ${VM2_CFG_MAC} ${VM2_CFG_VCPUPIN} ;;
"3" ) start_VM $1 $2 ${VM3_CFG_MAC} ${VM3_CFG_VCPUPIN} ;;
*)
{
    echo "ERROR VM Num:$2"
    exit -1
}
;;
esac

exit 0