/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file RawRequest.h
 * @brief Header file for RawRequest
*/

#ifndef __MECFCGI__RAWREQUEST__
#define __MECFCGI__RAWREQUEST__

#include "PostRequestDispatcher.h"
#include "GetRequestDispatcher.h"
#include "PutRequestDispatcher.h"
#include "DelRequestDispatcher.h"
#include <fcgio.h>
#include <stdio.h>

class RawRequest
{
    void postRequest(const string &action, FCGX_Request &request, map<string, string> &cookies, PostRequestDispatcher &dispatcher);
    void getRequest(const string &action, FCGX_Request &request, map<string, string> &cookies, GetRequestDispatcher &dispatcher);
    void putRequest(const string &action, FCGX_Request &request, map<string, string> &cookies, PutRequestDispatcher &dispatcher);
    void delRequest(const string &action, FCGX_Request &request, map<string, string> &cookies, DelRequestDispatcher &dispatcher);
    void printHeaders(map<string, string> &headers);
    const string baseURI;
public:

    /**
     * @brief        Constructs a RawRequest object using a common base URI for the system.
     * @param[in]    baseURI A common base URI for directing requests within the system.
     */
    RawRequest(string &&baseURI);

    /**
     * @brief        Dispatches a FastCGI request.
     * @param[in]    request      A FastCGI request using either POST or GET method.
     * @throw        Exception    Thrown on failure.
     * @return       void
     */
    void dispatch(FCGX_Request &request);

    PostRequestDispatcher postDispatcher;
    GetRequestDispatcher getDispatcher;
    PutRequestDispatcher putDispatcher;
    DelRequestDispatcher delDispatcher;
};

#endif /* defined(__MECFCGI__RAWREQUEST__) */
