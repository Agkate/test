#!/usr/bin/expect
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

set timeout 10
log_user 0

spawn ssh -q -o StrictHostKeyChecking=no $::env(DEV1_USER)@$::env(DEV1_IP)

set timeout 30

send "ping $::env(GG_CORE1) -c 4\r"

expect {
    timeout { send_user "\nTimeout on $::env(DEV1_IP). Ping to $::env(GG_CORE1) is not working\n"; }
    "*4 packets transmitted, 4 received*" { send_user "\nPing to $::env(GG_CORE1) is working. Exiting...\n"; exit 1 }
    "*4 packets transmitted, 0 received*" { send_user "\nPing to $::env(GG_CORE1) is not working\n" }
}

set timeout 30

send "cd ~/$::env(SAMPLE_PATH); PYTHONPATH=.. python route_config.py -vDEBUG \
--root-ca=root-ca.pem \
--certificate=$::env(KEY).cert.pem \
--private-key=$::env(KEY).private.key \
--client-id=$::env(DEVICE_ID) \
--topic=$::env(TOPIC) \
--subscribe \
--publish \
--mec-action $::env(ACTION) $::env(ENDPOINT)\r"


expect {
    timeout { send_user "\nTimeout on $::env(DEV1_IP). Test 4 failed on script execution.\n"; exit 1}
    "*No such file or directory" { send_user "\nFailed to find directory on $::env(DEV1_IP)\n"; exit 1 }
    "*\"result\": \"Route added successfully\"*" { send_user "\nRoute added successfully.\n" }
}

set timeout 30

send "ping $::env(GG_CORE1) -c 4\r"

expect {
    timeout { send_user "\nTimeout on $::env(DEV1_IP). Ping to $::env(GG_CORE1) is not working\n"; exit 1}
    "4 packets transmitted, 4 received*" { send_user "\nPing to $::env(GG_CORE1) is working. Test 4 success.\n"; exit 0 }
}

send "exit\r"
close
