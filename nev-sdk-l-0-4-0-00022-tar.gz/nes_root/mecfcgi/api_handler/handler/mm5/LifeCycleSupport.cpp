/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file     LifeCycleSupport.cpp
* @brief    Implementation of Mobile Edge Application Configuration and 
*           Termination handlers.
*/

#include "LifeCycleSupport.h"
#include "ServiceRegistryPort.h"
#include "SessionManager.h"
#include "Exception.h"
#include "HandlerCommon.h"
#include "DbManager.h"
#include "Log.h"
#include "RawRequest.h"
#include "WebSocketServer.h"

static TimeoutChecker timeoutChecker;

void AppConfiguration::execute(Json::Value &request, Json::Value &response,
                    map<string, string> &headers, map<string, string> &cookies)
{
    try {
        string appid = request.get("appid", "Nil").asString();
        string secret = request.get("secret", "Nil").asString();

        // Check for empty fields.
        if (0 == appid.compare("Nil")) {
            MECFCGI_LOG(ERR, "[appid] is not found in request.\n");
            throw Exception(Exception::INVALID_APPID);
        }
        if (0 == secret.compare("Nil")) {
            MECFCGI_LOG(ERR,  "[secret] is not found in request.\n");
            throw Exception(Exception::INVALID_SECRET);
        }

        // Check ME app's operation state (running, not running)
        bool isFound = false;
        string token = "";
        DbManager::checkAndGetTokenByAppid(isFound, token, appid);
        if (isFound) {
            MECFCGI_LOG(WARNING,
                "App with appid[%s] is already running.\n", appid.c_str());
            throw Exception(Exception::DUPLICATE_APPID);
        }

        // Save configuration information to service registry.
        string result = "";
        ServiceRegistryPort::saveMeAppConfiguration(result, request);
        if (0 == result.compare("OK")) {
            headers["Status"] = HTTP_SC_OK;
            response["result"] = "OK";
        } else {
            if (0 == result.compare("InvalidProvidableServices") ) {
                MECFCGI_LOG(ERR,  "Providable service list is invalid.\n");
                throw Exception(Exception::INVALID_PROVIDABLESERVICES);
            } else if (0 == result.compare("InvalidSubscribableServices") ) {
                MECFCGI_LOG(ERR,  "Subscribable service list is invalid.\n");
                throw Exception(Exception::INVALID_SUBSCRIBABLESERVICES);
            } else if (0 == result.compare("InvalidSettableTrafficRules") ) {
                MECFCGI_LOG(ERR,  "Settable traffic rule list is invalid.\n");
                throw Exception(Exception::INVALID_SETTABLETRAFFICRULES);
            } else if (0 == result.compare("DatabaseFailure") ) {
                MECFCGI_LOG(ERR,  "Database operation failed.\n");
                throw Exception(Exception::DATA_BASE_FAILURE);
            } else {
                MECFCGI_LOG(ERR,"Unkown Error occurred: %s.\n", result.c_str());
                throw Exception(Exception::UNKOWN_ERROR);
            }
        }
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void AppTermination::execute(Json::Value &request, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies)
{
    try {

        string appid = request.get("appid", "Nil").asString();

        // Check for empty fields.
        if (0 == appid.compare("Nil")) {
            MECFCGI_LOG(ERR, "[appid] is not found in request.\n");
            throw Exception(Exception::INVALID_APPID);
        }

        if ((!request.isMember("gracefulTerminationTimeout")) ||
            (!request["gracefulTerminationTimeout"].isUInt())) {
            // Invalid gracefulTerminationTimeout
            throw Exception(Exception::INVALID_TIME_OUT_VALUE);
        }

        uint32_t gracefulTerminationTimeout =
            request.get("gracefulTerminationTimeout", "").asUInt();

        // Check ME app's operation state (running, not running).
        bool isFound = false;
        string token = "";
        DbManager::checkAndGetTokenByAppid(isFound, token, appid);

        if (isFound) {
            TimeoutChecker::getInstance().setAppTimeoutValue(
                        appid, gracefulTerminationTimeout);
            if (TimeoutChecker::STATE_STOPPED ==
                TimeoutChecker::getInstance().getTimeoutWatcherStatus()) {
                TimeoutChecker::getInstance().startTimeoutWatcher();
            }
            Json::Value message;
            message["id"] = "TerminationNotification";
            message["data"] = appid;
            Json::FastWriter writer;
            string sMessage = writer.write(message);
            getWebServer()->pushData(token, "TerminationNotification", sMessage);

            headers["Status"] = HTTP_SC_OK;
            response["result"] = "OK";
        } else {
            MECFCGI_LOG(WARNING,
                        "App with appid[%s] is not running.\n",appid.c_str());
            throw Exception(Exception::APP_NOT_RUNNING);
        }
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

static void timeoutWatcher(TimeoutChecker *self)
{
    while (self->state == TimeoutChecker::STATE_RUNNING) {
        for (map<string, uint32_t>::iterator iter = self->timeoutMap.begin();
            iter != self->timeoutMap.end(); ){
            pthread_mutex_lock(&(self->listLock));
            if(0 == iter->second){
                string appid = iter->first;
                self->timeoutMap.erase(iter++);
                try {
                    HandlerCommon::delMeAppInformation(appid);
                }
                catch (Exception &e){
                    MECFCGI_LOG(ERR, "Error occurred when clearing information \
                        of App with appid %s: errno: %d.\n", 
                        appid.c_str(), e.code);
                }
                string result = "";
                ServiceRegistryPort::removeMeAppConfiguration(result, appid);

                Json::Value message;
                message["id"] = "TerminationNotification";
                message["data"] = appid;
                Json::FastWriter writer;
                string sMessage = writer.write(message);
                getWebServer()->pushData("memanager", "TerminationNotification", 
                                sMessage);
            } else {
                iter->second--;
                iter++;
            }
            pthread_mutex_unlock(&(self->listLock));
        }
        if (0 == self->timeoutMap.size()) {
            self->state = TimeoutChecker::STATE_STOPPED;
        }
        sleep(1);
    }
}

TimeoutChecker &TimeoutChecker::getInstance()
{
    return timeoutChecker;
}

void TimeoutChecker::startTimeoutWatcher()
{
    if (STATE_STOPPED == state) {
        state = STATE_RUNNING;
        worker = thread(timeoutWatcher, this);
    }
}

TimeoutChecker::TimeoutChecker(void):state(STATE_STOPPED)
{

}

TimeoutChecker::~TimeoutChecker(void)
{

}    

TimeoutChecker::STATE TimeoutChecker::getTimeoutWatcherStatus(void)
{
    return state;
}

void TimeoutChecker::setAppTimeoutValue(string appid, uint32_t timer)
{
    pthread_mutex_lock(&listLock);
    timeoutMap[appid] = timer;
    pthread_mutex_unlock(&listLock);
}

void TimeoutChecker::cleanAppTimeoutValue(string appid)
{
    pthread_mutex_lock(&listLock);
    map<string, uint32_t>::iterator iter = timeoutMap.find(appid);
    if(iter != timeoutMap.end()) {
        timeoutMap.erase(iter);
    }
    pthread_mutex_unlock(&listLock);
}

void TimeoutChecker::findAppTimeoutStatus(bool &isFound, string appid)
{
    isFound = false;
    map<string, uint32_t>::iterator iter = timeoutMap.find(appid);
    if(iter != timeoutMap.end()) {
        isFound = true;
    }
}