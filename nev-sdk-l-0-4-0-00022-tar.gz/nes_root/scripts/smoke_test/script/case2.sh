#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

. functions.sh
. test_handler.sh

TEST_TARGET=${ME_APP_LOG}
RESPONSE_STATUS_CODE=200
RESPONSE_RESULT=OK
CASE_NAME="case2"
TEST_DESCRIPTION="MP1 API - Live Indicator"

copy_sshkey_to_vm $VM1_IP_ADDR

MEAPP_JSON_FILE="-p ${BASE_PATH_VM}/case/${CASE_NAME}/json/meapp/"
PRE_MEAPP_CMD="-n \"o n s z m\""
MEAPP_CMD="-n \"o n s z m z\""

exec_on_vm $VM1_IP_ADDR "cd ${MEAPP_EXE_DIR}; python meapp.py ${PRE_MEAPP_CMD} ${MEAPP_JSON_FILE}"

copy_sshkey_to_vm $VM_NES_MGMT_IP
exec_on_vm $VM_NES_MGMT_IP "python ${MEMANAGER_EXE_DIR} -n \"o n a\" -a \"app001\" -p \"${TEST_ROOT_DIR}/case/${CASE_NAME}/json/memanager/\""
get_sample_app_log $VM_NES_MGMT_IP:$ME_APP_MANAGER_LOG $ME_APP_MANAGER_LOG
rem_sshkey_in_vm $VM_NES_MGMT_IP

exec_on_vm $VM1_IP_ADDR "cd ${MEAPP_EXE_DIR}; python meapp.py ${MEAPP_CMD} ${MEAPP_JSON_FILE}"

get_sample_app_log $VM1_IP_ADDR:${BASE_PATH_VM}/samples/meapp/log/meapp.log ${ME_APP_LOG}
rem_sshkey_in_vm $VM1_IP_ADDR
check_status_and_result ${TEST_TARGET} ${RESPONSE_STATUS_CODE} ${RESPONSE_RESULT} ${CASE_NAME} "${TEST_DESCRIPTION}"