/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file nes_arp.c
 * @brief implementation of nes_arp
 */

#include <assert.h>
#include <stdio.h>
#include <stdint.h>

#include "nes_arp.h"
#include "nes_common.h"

int
nes_arp_response(struct rte_mbuf *m, struct ether_addr eth_addr) {
    assert(m);
    uint32_t tmp_ip;

    struct ether_hdr *eth = rte_pktmbuf_mtod(m, struct ether_hdr *);
    arp_header_ipv4_t *arp_r = (arp_header_ipv4_t *) (eth + 1);
    if (rte_cpu_to_be_16(HTYPE_ETHER) != arp_r->htype ||
            rte_cpu_to_be_16(ETHER_TYPE_IPv4) != arp_r->ptype ||
            rte_cpu_to_be_16(ARP_REQUEST) != arp_r->oper) {
        return NES_FAIL;
    }

    // reuse original mbuf to create the response
    ether_addr_copy(&arp_r->sha, &eth->d_addr);
    ether_addr_copy(&eth_addr, &eth->s_addr);

    arp_r->oper = rte_cpu_to_be_16(ARP_REPLY);
    tmp_ip = arp_r->tpa;
    arp_r->tpa = arp_r->spa;
    ether_addr_copy(&arp_r->sha, &arp_r->tha);
    arp_r->spa = tmp_ip;
    ether_addr_copy(&eth_addr, &arp_r->sha);

    return NES_SUCCESS;
}
