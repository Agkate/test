/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/

/**
* @file libnes_sq.c
* @brief Implementation of nes library for queues
*/
#include <assert.h>

#ifdef LIBNES_API
#include <stdlib.h>
#else
#include <rte_malloc.h>
#endif
#include "nes_common.h"
#include "libnes_sq.h"

#ifdef LIBNES_API
    #define  nes_malloc(size) malloc((size))
    #define  nes_free(ptr) free((ptr))
#else
    #define  nes_malloc(size) rte_malloc(NULL,(size),0);
    #define  nes_free(ptr) rte_free((ptr))
#endif

void nes_sq_ctor(nes_sq_t *queue)
{
    assert(queue);
    queue->head = NULL;
    queue->tail = NULL;
    queue->cnt=0;
}

void nes_sq_dtor(nes_sq_t *queue)
{
    nes_sq_node_t *node;
    void          *data;
    NES_SQ_FOREACH(node,queue) {
        nes_sq_deq(queue,&data);
    }
}

void nes_sq_dtor_free(nes_sq_t *queue)
{
    nes_sq_node_t *node;
    void          *data;
    NES_SQ_FOREACH(node,queue) {
        nes_sq_deq(queue,&data);
        nes_free(data);
    }
}

int nes_sq_enq(nes_sq_t *queue, void *data)
{
    nes_sq_node_t *newnode;
    
    assert(queue);
    newnode = nes_malloc(sizeof(*newnode));
    if (NULL == newnode) {
        return NES_FAIL;
    }
    
    newnode->next = NULL;
    newnode->data = data;    
    
    if (NULL == queue->head) {
        queue->head = newnode;
    }
    if (NULL != queue->tail) {
        queue->tail->next = newnode;
    }        
    
    queue->tail = newnode;
    queue->cnt++;

    return NES_SUCCESS;
}

int nes_sq_deq(nes_sq_t *queue, void **data)
{
    nes_sq_node_t *node;
    int retval;

    assert(queue);    
    node = queue->head;
    if (NULL != node) {
        *data = node->data;
        queue->head = node->next;
        queue->cnt--;
        nes_free(node);
        retval = NES_SUCCESS;
    } else {
        *data = NULL;
        retval = NES_FAIL;
    }
    if (NULL == queue->head) {
        queue->tail = NULL;
    }
    return retval;
}

nes_sq_node_t *nes_sq_get(nes_sq_t *queue, uint16_t index)
{
    int i;
    nes_sq_node_t *item;
 
    item = nes_sq_head(queue);
 
    for (i = 0; i < index; i++) {
        if (NULL == item) {
            return NULL;
        }
        item = item->next;
    }
 
    return item;
}

void nes_sq_remove(nes_sq_t *queue, nes_sq_node_t *node)
{
    nes_sq_node_t *item;
    assert(queue);
    assert(node);

    if (queue->head == node) {
        queue->head = node->next;
        if (queue->tail == node) {
            queue->tail = NULL;
        }  
        nes_free(node);
        queue->cnt--;        
    }
    else {
        NES_SQ_FOREACH(item,queue) {
            if (item->next == node || item == node ) {
                item->next = item->next->next;
                if (NULL == item->next) {
                    queue->tail = item;
                }    
                nes_free(node);
                queue->cnt--;
                break;
            }
        }
    }
}
