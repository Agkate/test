/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file nes_io.c
* @brief Implementation of nes i/o
*/
#include <rte_config.h>
#include <rte_log.h>
#include <rte_cycles.h>
#include <rte_malloc.h>
#include "nes_common.h"
#include "libnes_queue.h"
#include "libnes_cfgfile.h"
#include "io/nes_dev.h"
#include "io/nes_io.h"
#include "io/nes_mac_lookup.h"

static nes_queue_t nes_io_devices;
rte_atomic32_t threads_started = RTE_ATOMIC32_INIT(0);

__attribute__((constructor))
static void nes_io_early_init(void)
{
    nes_queue_ctor(&nes_io_devices);
}

void nes_io_dev_queue_get(nes_queue_t **queue)
{
    *queue = &nes_io_devices;
}

static int nes_io_init(void)
{
    return nes_mac_lookup_init();
}

int nes_io_main(__attribute__((unused))void *arg)
{
    if (NES_SUCCESS != nes_io_init()) {
        NES_LOG(EMERG,"NES:IO_THREAD init failed.\n");
        return NES_FAIL;
    }
 
    while( THREADS_MASK != rte_atomic32_read(&threads_started) ) {
        usleep(1);
    }
    
    NES_LOG(INFO, "NES_IO started\n");
    for (NES_FOREVER_LOOP) {
        nes_dev_t *device;
        nes_queue_node_t *node, *removed_node;
        /* Receive, scatter and send*/
        NES_QUEUE_FOREACH(node, &nes_io_devices){
            device = node->data;
            if (device->recv) {
                device->recv(device,NULL);
            }
            if (device->scatter) {
                device->scatter(device,NULL);
            }
            if (device->send) {
                device->send(device,NULL);
            }
            if (unlikely(device->remove)) {
                nes_queue_node_unlock(node);
                if ((removed_node = nes_queue_remove(&nes_io_devices, node)) != NULL) {
                    /*rte_free(device);*/
		    rte_free(removed_node);
                }
		break;
            }

        } /* end for all devices nodes */
    } /* end for(;;) */
 
    return NES_SUCCESS;

}

