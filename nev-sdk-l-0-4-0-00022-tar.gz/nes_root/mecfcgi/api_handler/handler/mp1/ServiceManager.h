/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    ServiceManager.h
 * @brief   Classes of handlers responsible for handling Mobile Edge Service 
 *          Activation,Deactivation and Discovery.
 *
 *          <Mobile Edge Service Activation>
 *          An ME App Service may activate its services on the ME Platform once
 *          it is capable of producing service data for them. After service
 *          activation, the ME Platform informs other ME Apps/ME App Services
 *          who are allowed to subscribe to the service via a New Service
 *          Announcement.
 *          This is a mandatory API. An ME application cannot activate its
 *          service(s) without using this API.
 *
 *          <Mobile Edge Service Deactivation>
 *          An ME App Service can deactivate its own service if the service was
 *          previously activated. Whenever an ME App Service deactivates one
 *          of its own service, Service Availability Change Notification will
 *          be sent to all ME Apps/ME App Services that have subscribed or may 
 *          subscribe to the service.
 *          This is an optional API. An ME application is not required to
 *          deactivate its service using this API.
 *
 *          <Mobile Edge Service Discovery>
 *          Once an ME App/ME App Service has been authenticated by the ME
 *          Platform, it may discover the availability of its subscribable
 *          services on the ME Platform by sending a Service Discovery Request.
 *          The ME Platform returns in a list the available services that the
 *          ME App/ME App Service may subscribe to. Using this list, the
 *          ME App/ME App Service may learn which of its subscribable services
 *          are available on the ME Platform, and how subscribe to those
 *          service(s).
 *          This is a mandatory API. An ME application cannot discover all of
 *          subscribable services without using this API.
 */

#ifndef __MECFCGI__SERVICEMANAGER__
#define __MECFCGI__SERVICEMANAGER__

#include "PostRequestHandler.h"
#include "DelRequestHandler.h"
#include "GetRequestHandler.h"

class ServiceActivation : public PostRequestHandler
{
public:
    /**
    * @brief            Handles REST API Requests for activating a ME Service.
    * @param[in]        request     JSON-formatted request data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute(Json::Value &request, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

class ServiceDeactivation : public DelRequestHandler
{
public:
    /**
    * @brief            Handles REST API Requests for deactivating an ME
    *                   Service.
    * @param[in]        request     JSON-formatted request data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute(map<string, string> params, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

class ServiceDiscovery : public GetRequestHandler
{
public:
    /**
    * @brief        Handles REST API Requests for discovering ME Services.
    * @param[in]    request     JSON-formatted request data.
    * @param[out]   response    JSON-formatted key-value pair(s) indicating
    *                           response.
    * @param[out]   headers     Response headers.
    * @param[in]    cookies     Cookies header in request.
    * @throw        Exception   Thrown on failure.
    * @return       void
    */
    void execute(map<string, string> params, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

#endif //__MECFCGI__SERVICEMANAGER__
