#!/usr/bin/python
# coding: utf-8
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

import httplib2
import threading
import socket
import time
import json
import sys
import re
import ctypes
import getopt
import os.path
import logging
import websocket
import random

def outputLog():  
    if False == os.path.exists('./log'):
        os.makedirs('./log')
    logFilename = './log/meapp.log'
    logging.basicConfig(  
                    level   = logging.DEBUG,                                                           
                    format  = '%(message)s',
                    datefmt = '%m-%d %H:%M',
                    filename= logFilename, 
                    filemode= 'w')

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(message)s')
    console.setFormatter(formatter)  
    logging.getLogger().addHandler(console)

MEAPP_LOG = logging.getLogger('MEAPP_LOG')

# Select a module to run by specifying the corresponding command
COMMANDS = {'L1': 'oqn',
            'L2': 'msq',
            'L3.1': 'strq',
            'L3.2': 'zmlcsxubtfrq'}
dictOpts = {'quit': 'q',                                                 # common
            'nevSdk': 'n', 'logOut': 'o',                                # L1
            'multiPro': 'm', 'singlePro': 's',                           # L2
            'startUsingServices': 's', 'stopUsingServices': 't',         # L3.1
            'liveindicator': 'z',                                        # L3.2
            'terminationindicator': 'm',
            'connectionestablishment': 'l',
            'servicediscovery': 'c',
            'servicesubscription': 's',
            'subscriptionsupdate': 'x',
            'serviceunsubscription': 'u',
            'subscriptionsreset': 'b',
            'trafficrulecreation': 't',
            'trafficruleupdate': 'f',
            'trafficruleremoval': 'r',}
gLevel = 'L1'

class Vector:
    first=""
    second=""
    def __init__(self,x,y):
        self.first=x
        self.second=y

# Meapp class
class Meapp:
    def __init__(self):
        self.__HOSTPORT = '8080'                            # host port number
        self.__WEBSOCKETPORT = '8888'                       # websocket port number
        self.__HOSTADDR = 'mec.local'                       # host ip
        self.__CERTPATH = 'mec.crt'
        self.__h = httplib2.Http(".cache", ca_certs=self.__CERTPATH)
        self.__cookie = ''                                  # cookie value
        self.__stopped = True                               # thread switch
        self.__baseJsonPath = "json/"                       # file path prefix for json files
        self.logFlagForDebug = False                        # debug log output switch
        self.arrServiceID = ''                              #
        self.thread = ""                                    # websocket thread
        self.__trafficName = ""
        self.__updatetraffic = ""
        self.__subscription = ""
        self.subscribableServiceList = []                   # list of ME services an ME App may subscribe to.
        self.subscribedServicesList = []                    # list of ME services an ME App has been subscribed.
        self.trafficRuleList = []
        self.createdTrafficRuleList = []
        self.__baseUrl = 'https://' + self.__HOSTADDR + ':' + self.__HOSTPORT + '/appliance/v1' # url prefix

# Do Mobile Edge Application Live Indicator(-z)
    def liveIndicator(self):
        procedure = 'Live Indicator Request'
        url = self.__baseUrl + '/live_apps'
        method = "POST"
        contentType = "application/json"

        jsonPath = self.__baseJsonPath + 'AppLiveIndicator.json'
        if not os.path.exists(jsonPath):
            print("[NG] The file \"{}\" cannot be found.".format(jsonPath))
            return

        # Read request data from json file
        requestBody = self.loadJsonFile(jsonPath)

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            # Save cookies
            self.__cookie = resp['set-cookie']
            print('[OK] Mobile Edge Application Live Indicator.')
        else:
            print('[NG] Mobile Edge Application Live Indicator.')

# Do Mobile Edge Application Termination Indicator(-m)
    def terminationIndicator(self):
        procedure = 'Termination Indicator Request'
        url = self.__baseUrl + '/live_apps'
        method = "DELETE"
        contentType = ""
        requestBody = ""

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            if self.thread:
                self.delWebSocket()
                self.thread = ""
                time.sleep(1)

            self.__cookie = ""                    # init cookie value
            self.createdTrafficRuleList = []      # init traffic rule Id
            self.subscribedServicesList = []      # init list of services to subscribe to
            print('[OK] Mobile Edge Application Termination Indicator.')
        else:
            print('[NG] Mobile Edge Application Termination Indicator.')

# Do Mobile Edge Application Connection Establishment(-l)
    def connectionEstablishment(self):
        if not self.__stopped:
            print('[WARNING] ME App Connection is already established.')
            return
        self.__stopped = False
        self.thread = threading.Thread(name = "WebsocketThread", target = self.createWebSocket)
        self.thread.setDaemon(True)
        self.thread.start()

# Delete thread
    def delWebSocket(self):
        self.__stopped = True

    def formatChannelListenerResponse(self, str):
        str = list(str)
        temp = ""
        count = 0
        for s in str:
            if s == '{' :
                count += 1
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == '[' :
                count += 1
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == ',':
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == '}':
                count -= 1
                temp += '\n'
                temp = self.addTable(temp,count)
                temp += s
            elif s == ']':
                count -= 1
                temp += '\n'
                temp = self.addTable(temp,count)
                temp += s
            else:
                temp += s
        return temp
    def addTable(self,s,num):
        for i in range(0,num):
            s += '    '
        return s

# Create WebSocket
    def createWebSocket(self):
        if not self.__cookie:
            print('[NG] ME App Connection Establishment Failed: cookie is null')
            self.__stopped = True
            return

        if self.__cookie.find('SESSID=') != -1:
            refId = self.__cookie[self.__cookie.find('SESSID=') + 7:]
        else:
            refId = self.__cookie
        url = 'ws://' + self.__HOSTADDR + ':' + self.__WEBSOCKETPORT + '/notifications/' + refId
        try:
            websocket.enableTrace(True)
            ws = websocket.create_connection(url)
        except:
            print ('[NG] ME App Connection Establishment Failed: WebSocket header is invalid. Please try again.')
            self.__stopped = True
            return
        print ('[OK] ME App Connection Establishment.')
        while not self.__stopped:
            result = ws.recv()
            if result:
                result = self.formatChannelListenerResponse(result)
                MEAPP_LOG.info(result)

# Do Mobile Edge Service Discovery(-c)
    def serviceDiscovery(self, userAction = True):
        procedure = 'Service Discovery Request'
        url = self.__baseUrl + '/service'
        method = "GET"
        contentType = ""
        requestBody = ""

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})
        if userAction and self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            serviceList = json.loads(content)
            del self.subscribableServiceList[:]
            for service in serviceList['services']:
                serviceName = service['serviceName']
                serviceId = service['serviceId']
                subscribableService = Vector(serviceName, serviceId)
                self.subscribableServiceList.append(subscribableService)
            if userAction:
                if not self.subscribableServiceList:
                    print ("There are no services available to the user.")
                print('[OK] ME App Service Discovery.')
        elif userAction:
            print('[NG] ME App Service Discovery.')

# Do Mobile Edge Service Subscription(-s)
    def serviceSubscription(self, serviceName = "", serviceId = ""):
        procedure = 'Service Subscription Request'

        method = "GET"
        contentType = "application/json"

        if not serviceId and not serviceName:
            self.serviceDiscovery(False)

            if not self.subscribableServiceList:
                print ("There are no available services.")
                return
            if self.__subscription:
                for subscribableService_ in self.subscribableServiceList:
                    if self.__subscription == subscribableService_.first:
                        serviceId = subscribableService_.second
                        serviceName = subscribableService_.first
                        break
                if not serviceId:
                    print("The subscription specified on the command line is not found.")
                    return                        
            else:
                serviceId = self.getServicesFromUser(self.subscribableServiceList).second
                if not serviceId:
                    print("No serial number was entered.")
                    return
                for subscribableService_ in self.subscribableServiceList:
                    if serviceId == subscribableService_.second:
                        serviceName = subscribableService_.first
                        break

                for subscribedServices_ in self.subscribedServicesList:
                    if serviceId == subscribedServices_.second:
                        print('The user has already subscribed to the chosen service.')
                        return

        url = self.__baseUrl + '/subscriptions/' + serviceId
        requestBody = ""

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            subscribedService = Vector(serviceName, serviceId)
            self.subscribedServicesList.append(subscribedService)
            print('[OK] Mobile Edge Service Subscription.')
        else:
            print('[NG] Mobile Edge Service Subscription.')

# Do Mobile Edge Subscriptions Update(-x)
    def subscriptionsUpdate(self):
        procedure = 'Subscriptions Update Request'
        url = self.__baseUrl + '/subscriptions'
        method = "PUT"
        contentType = "application/json"
        self.serviceDiscovery(False)
        request = {"services":[]}
        serviceId = {"serviceId":"serviceId"}
        subServicesList = []
        if not self.subscribableServiceList:
            print ("There are no subscribable services for the use.")
            return
        if self.__subscription:
            for subscribableService_ in self.subscribableServiceList:
                if self.__subscription == subscribableService_.first:
                    subServicesList.append(subscribableService_)
                    serviceId['serviceId'] = subscribableService_.second
                    request['services'].append(serviceId)
                    request['services'] = json.dumps(request['services'])
                    request['services'] = json.loads(request['services'])
                    break
            if not serviceId['serviceId']:
                print("The subscription specified on the command line is not found.")
                return
        else:
            if not self.subscribedServicesList:
                print ("No service has been subscribed to.")
                return        
            # get list of available services
            subServicesList = self.updateSubscribeServicesList(self.subscribedServicesList, self.subscribableServiceList)
            if not subServicesList:
                print("No serial number was entered.")
                return        

            for subService_ in subServicesList:
                serviceId['serviceId'] = subService_.second
                request['services'].append(serviceId)
                request['services'] = json.dumps(request['services'])
                request['services'] = json.loads(request['services'])

        requestBody = request
        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            self.subscribedServicesList = subServicesList
            print('[OK] Mobile Edge Subscriptions Update.')
        else:
            print('[NG] Mobile Edge Subscriptions Update.')

    def updateSubscribeServicesList(self, subscribedServicesList, subscribableServiceList):
        userSelectList = []
        if not subscribedServicesList or None == subscribedServicesList:
            return userSelectList
        else:
            # print list of services
            print("Subscribed Service List")
            self.printSelectedList(subscribedServicesList)

            print("Subscribable Service List")
            self.printSelectedList(subscribableServiceList)
        # Waiting for user input
        max = len(subscribedServicesList)
        self.arrServiceID = 0
        while 1:
            str = raw_input('>>>>>>Please enter a serial number within the range [1-{}] that you want removed:'.format(max))
            self.arrServiceID = str.split()
            if not str:
                self.arrServiceID = 0
                break
            elif len(self.arrServiceID) > 1:
                print('Input contains multiple characters.')
            elif not re.search(r'^[\d\s]*$', str):
                print('Input contains non-numeric characters.')
            elif int(self.arrServiceID[0]) > max or int(self.arrServiceID[0]) < 1:
                print('No.{} is out of range.'.format(int(self.arrServiceID[0])))
            else:
                break

        max = len(subscribableServiceList)
        newID = 0
        while 1:
            str2 = raw_input('>>>>>>Please enter a serial number within the range [1-{}] that you want added:'.format(max))
            newID = str2.split()
            if not str2:
                newID = 0
                break
            elif len(newID) > 1:
                print('Input contains multiple characters.')
            elif not re.search(r'^[\d\s]*$', str2):
                print('Input contains non-numeric characters.')
            elif int(newID[0]) > max or int(newID[0]) < 1:
                print('No.{} is out of range.'.format(int(newID[0])))
            else:
                break

        for subscribedService in subscribedServicesList:
            userSelectList.append(subscribedService)
      
        if (0 != self.arrServiceID) and (0 != newID):
            userSelectList.pop(int(self.arrServiceID[0])-1)
            serviceName = subscribableServiceList[int(newID[0])-1].first
            serviceId = subscribableServiceList[int(newID[0])-1].second
            userSelect = Vector(serviceName, serviceId)
            userSelectList.append(userSelect)
        elif (0 != self.arrServiceID) and (0 == newID):
            userSelectList.pop(int(self.arrServiceID[0])-1)
        elif (0 == self.arrServiceID) and (0 != newID):
            serviceName = subscribableServiceList[int(newID[0])-1].first
            serviceId = subscribableServiceList[int(newID[0])-1].second
            userSelect = Vector(serviceName, serviceId)
            userSelectList.append(userSelect)
        else:
            userSelectList = []
        return userSelectList
# Do Mobile Edge Service Unsubscription(-u)
    def serviceUnsubscription(self, serviceId = ""):
        procedure = 'Service Unsubscription Request'
        method = "DELETE"
        contentType = "application/json"
        requestBody = ""
        if not self.subscribedServicesList:
            print("There are no subscribed services.")
            return
        if not serviceId:
            if self.__subscription:
                for subscribedService_ in self.subscribedServicesList:
                    if self.__subscription == subscribedService_.first:
                        serviceId = subscribedService_.second
                        str = '1'
                        self.arrServiceID = str.split()
                        break
                if not serviceId:
                    print("The subscription specified on the command line is not found.")
                    return   
            else:
                serviceId = self.getServicesFromUser(self.subscribedServicesList).second
                if not serviceId:
                    print("No serial number was entered.")
                    return

        url = self.__baseUrl + '/subscriptions/' + serviceId

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            self.subscribedServicesList.pop(int(self.arrServiceID[0])-1)
            print('[OK] Mobile Edge Service Unsubscription.')
        else:
            print('[NG] Mobile Edge Service Unsubscription.')

# Do Mobile Edge Subscriptions Reset(-u)
    def subscriptionsReset(self, serviceId = ""):
        procedure = 'Subscriptions Reset Request'
        method = "DELETE"
        contentType = "application/json"
        requestBody = ""
        if not self.subscribedServicesList:
            print("There are no subscribed services.")
            return
        url = self.__baseUrl + '/subscriptions'
        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            del self.subscribedServicesList[:]
            print('[OK] Mobile Edge Subscriptions Reset Request.')
        else:
            print('[NG] Mobile Edge Subscriptions Reset Request.')

# Do Mobile Edge Traffic Rules Control(Create: -t, Remove: -r, Update: -f)
    def trafficRuleCreation(self):
        procedure = 'Traffic Rule Creation Request'
        url = self.__baseUrl + '/traffic'
        method = "POST"
        contentType = "application/json"
        jsonPath = self.__baseJsonPath + 'trafficRule/'
        requestBody = ""
        if not os.path.exists(jsonPath):
            print("[NG] The directory \"{}\" cannot be found.".format(jsonPath))
            return

        for parent,dirnames,filenames in os.walk(jsonPath):
            if not filenames:
                print "There are no traffic rule files found on the specified path."
                return
            del self.trafficRuleList[:]
            if self.__trafficName:
                __trafficName = self.__trafficName + ".json"
                for filename in filenames:
                    if __trafficName == filename:
                        requestBody = self.loadJsonFile(os.path.join(parent,filename))
                        createdFileName = filename
                        break;
                if not requestBody:
                    print("The traffic rule file name specified on the command line is not found.")
                    return
            else:
                for filename in filenames:
                    fileCon = self.loadJsonFile(os.path.join(parent,filename))
                    found = False
                    for trafficRule_ in self.trafficRuleList:
                        if filename == trafficRule_.first:
                            found = True
                            break
                    if not found:
                        trafficRule = Vector(filename, fileCon)
                        self.trafficRuleList.append(trafficRule)            
                userSelect = self.getServicesFromUser(self.trafficRuleList)
                if not userSelect.second:
                    print("No serial number was entered.")
                    return
                createdFileName = userSelect.first
                requestBody = userSelect.second

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            respDic = json.loads(content)
            trafficRuleId = respDic['trafficRuleId']
            createdTrafficRule = Vector(createdFileName, trafficRuleId)
            self.createdTrafficRuleList.append(createdTrafficRule)
            print('[OK] Mobile Edge Traffic Rule Creation.')
        else:
            print('[NG] Mobile Edge Traffic Rule Creation.')

    def trafficRuleUpdate(self):
        procedure = 'Traffic Rule Update Request'
        method = "PUT"
        contentType = "application/json"

        trafficRuleId = ""
        requestBody = ""
        if not self.createdTrafficRuleList:
            print("There are no created traffic rule(s).")
            return
        if self.__updatetraffic and self.__trafficName:
            jsonPath = self.__baseJsonPath + 'trafficRule/'

            __trafficName = self.__trafficName + ".json"
            for createdTrafficRule_ in self.createdTrafficRuleList:
                if __trafficName == createdTrafficRule_.first:
                    trafficRuleId = createdTrafficRule_.second
                    str = '1'
                    self.arrServiceID = str.split()
                    break;
            if not trafficRuleId:
                print("The traffic rule file name specified on the command line is not found.")
                return
            if not os.path.exists(jsonPath):
                print("[NG] The directory \"{}\" cannot be found.".format(jsonPath))
                return
            for parent,dirnames,filenames in os.walk(jsonPath):
                if not filenames:
                    print "There are no traffic files found on the specified path."
                    return
                __trafficName = self.__updatetraffic + ".json"
                for filename_ in filenames:
                    if __trafficName == filename_:
                        requestBody = self.loadJsonFile(os.path.join(parent,filename_))
                        fileName = filename_
                        break;
                if not requestBody:
                    print("The traffic rule file name specified on the command line is not found.")
                    return
        else:
            if not self.trafficRuleList:
                print("There are no traffic rule(s) specified.")
                return
            result, fileName = self.updateTrafficeRule(self.trafficRuleList, self.createdTrafficRuleList)
            if not result:
                print("No serial number was entered.")
                return
            trafficRuleId = result.first
            requestBody = result.second
        url = self.__baseUrl + '/traffic/' + trafficRuleId
        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            self.createdTrafficRuleList.pop(int(self.arrServiceID[0])-1)
            createdTrafficRule = Vector(fileName, trafficRuleId)
            self.createdTrafficRuleList.append(createdTrafficRule)
            print('[OK] Mobile Edge Traffic Rule Update.')
        else:
            print('[NG] Mobile Edge Traffic Rule Update.')

    def updateTrafficeRule(self, trafficRuleList, createdTrafficRuleList):
        userSelect = []
        fileName = ""
        if not createdTrafficRuleList or None == createdTrafficRuleList:
            return userSelect, fileName
        else:
            # print list of services
            print("Created TrafficRule List")
            self.printSelectedList(createdTrafficRuleList)

            print("TrafficRule List")
            self.printSelectedList(trafficRuleList)
        # Waiting for user input
        max = len(createdTrafficRuleList)
        while 1:
            str = raw_input('>>>>>>Please enter a serial number within the range [1-{}] that you want removed:'.format(max))
            self.arrServiceID = str.split()
            if not str:
                self.arrServiceID = 0
                return userSelect, fileName
            elif len(self.arrServiceID) > 1:
                print('Input contains multiple characters.')
            elif not re.search(r'^[\d\s]*$', str):
                print('Input contains non-numeric characters.')
            elif int(self.arrServiceID[0]) > max or int(self.arrServiceID[0]) < 1:
                print('No.{} is out of range.'.format(int(self.arrServiceID[0])))
            else:
                break

        max = len(trafficRuleList)
        newID = 0
        while 1:
            str = raw_input('>>>>>>Please enter a serial number within the range [1-{}] that you want added:'.format(max))
            newID = str.split()
            if not str:
                newID = 0
                return userSelect, fileName
            elif len(newID) > 1:
                print('Input contains multiple characters.')
            elif not re.search(r'^[\d\s]*$', str):
                print('Input contains non-numeric characters.')
            elif int(newID[0]) > max or int(newID[0]) < 1:
                print('No.{} is out of range.'.format(int(newID[0])))
            else:
                break
        # create list of services to subscribe to

        trafficeRuleId_ = createdTrafficRuleList[int(self.arrServiceID[0])-1].second
        trafficeRuleInfo = trafficRuleList[int(newID[0])-1].second
        fileName = trafficRuleList[int(newID[0])-1].first
        userSelect = Vector(trafficeRuleId_, trafficeRuleInfo)
        return userSelect, fileName

    def trafficRuleRemoval(self):
        procedure = 'Traffic Rule Removal Request'
        method = "DELETE"
        contentType = "application/json"

        if not self.createdTrafficRuleList:
            print("There are no existing traffic rules.")
            return
        trafficRuleId = ""
        if self.__trafficName:
            __trafficName = self.__trafficName + ".json"
            for createdTrafficRule_ in self.createdTrafficRuleList:
                if __trafficName == createdTrafficRule_.first:
                    trafficRuleId = createdTrafficRule_.second
                    str = '1'
                    self.arrServiceID = str.split()
                    break;
            if not trafficRuleId:
                print("The traffic rule file name specified on the command line is not found.")
                return
        else:            
            userSelect = self.getServicesFromUser(self.createdTrafficRuleList)
            if not userSelect.second:
                print("No serial number was entered.")
                return
            trafficRuleId = userSelect.second
        url = self.__baseUrl + '/traffic/' + trafficRuleId

        requestBody = ""

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            self.createdTrafficRuleList.pop(int(self.arrServiceID[0])-1)
            print('[OK] Mobile Edge Traffic Rule Removal.')
        else:
            print('[NG] Mobile Edge Traffic Rule Removal.')

# result check
    def checkResult(self, resp, content):
        if not 'status' in resp:
            print "http server is not running!"
            return False
        try:
            respDic = json.loads(content)
            if respDic['result'] == "OK" or (
                respDic['result'] == "AlreadySubscribed" or
                respDic['result'] == "TrafficRuleExist" or
                respDic['result'] == "AppidAuthenticated"):
                return True
            else:
                print('result:{}'.format(respDic['result']))
                return False
        except ValueError:
            print "http server is not running!"
            return False
# Returns the selected content according to the user's choice
    def getServicesFromUser(self, selectedList):
        userSelect = Vector("","")
        if not selectedList or None == selectedList:
            return userSelect
        else:
            self.printSelectedList(selectedList)
        # Waiting for user input
        max = len(selectedList)
        while 1:
            str = raw_input('>>>>>>Please enter a serial number within the range [1-{}] :'.format(max))
            self.arrServiceID = str.split()
            if not str:
                return userSelect
            elif len(self.arrServiceID) > 1:
                print('Input contains multiple characters.')
            elif not re.search(r'^[\d\s]*$', str):
                print('Input contains non-numeric characters.')
            elif int(self.arrServiceID[0]) > max or int(self.arrServiceID[0]) < 1:
                print('No.{} is out of range.'.format(int(self.arrServiceID[0])))
            else:
                break

        userSelect = selectedList[int(self.arrServiceID[0])-1]
        return userSelect
# print list of selected items
    def printSelectedList(self, selectedList):
        count = 0
        print('No.    itemName')
        for sub in selectedList:
            count += 1
            print(' {}     {}'.format(count, sub.first, indent=2))
# read data from json file
    def loadJsonFile(self, path):
        fp = open(path, 'r')
        jsonData = json.load(fp)
        fp.close()

        return jsonData

# output request log
    def reqLogout(self, data):
        if data['Body']:
            data['Body'] = json.dumps(data['Body'], sort_keys=True, indent=4)
        MEAPP_LOG.info('')
        MEAPP_LOG.info("{}".format(data['Tip']))
        MEAPP_LOG.info('')
        MEAPP_LOG.info("Request Header")
        MEAPP_LOG.info("  URL        : {}".format(data['URL']))
        MEAPP_LOG.info("  Method     : {}".format(data['Method']))
        MEAPP_LOG.info("  ContentType: {}".format(data['ContentType']))
        MEAPP_LOG.info("  Cookie     : {}".format(data['Cookie']))
        MEAPP_LOG.info('')
        MEAPP_LOG.info("Request Body")
        MEAPP_LOG.info('{}'.format(data['Body']))
        MEAPP_LOG.info('')

# output response log
    def respLogout(self, data):
        data['Resp'] = json.dumps(data['Resp'], sort_keys=True, indent=4)
        if "result" in data['Content']:
            data['Content'] = json.dumps(json.loads(data['Content']), sort_keys=True, indent=4)
        MEAPP_LOG.info('')
        MEAPP_LOG.info("{}".format(data['Tip']))
        MEAPP_LOG.info('')
        MEAPP_LOG.info("Response Header")
        MEAPP_LOG.info('{}'.format(data['Resp']))
        MEAPP_LOG.info('')
        MEAPP_LOG.info("Response Body")
        MEAPP_LOG.info('{}'.format(data['Content']))
        MEAPP_LOG.info('')

    def setJsonPath(self, path):
        self.__baseJsonPath = path
    def setCookie(self, cookie):
        self.__cookie=cookie
    def setTrafficName(self, name):
        self.__trafficName = name
    def setUpdateTrafficName(self, name):
        self.__updatetraffic = name
    def setSubscription(self, name):
        self.__subscription=name
# python parameter specification
def usage(name):
    global gLevel
    print ""
    if 'L1' == gLevel:
        print "[ {} ] Demonstrate NEV SDK API ".format("n")
        print "[ {} ] Enable Log ".format("o")
        print "[ {} ] Exit".format("q")
    elif 'L2' == gLevel:
        print "[ {} ] Demonstrate Multi-Procedure Combinations ".format("m")
        print "[ {} ] Demonstrate Single Procedures ".format("s")
        print "[ {} ] Back".format("q")
    elif 'L3.1' == gLevel:
        print "[ {} ] Start Using Services on ME Platform".format("s")
        print "[ {} ] Stop Using Services on ME Platform".format("t")
        print "[ {} ] Back".format("q")
    elif 'L3.2' == gLevel:
        print "[ {} ] Do Application Live Indicator".format("z")
        print "[ {} ] Do Application Termination Indicator".format("m")
        print "[ {} ] Do Application Connection Establishment".format("l")
        print "[ {} ] Do Service Discovery".format("c")
        print "[ {} ] Do Service Subscription".format("s")
        print "[ {} ] Do Subscriptions Update".format("x")
        print "[ {} ] Do Service Unsubscription".format("u")
        print "[ {} ] Do Subscriptions Reset".format("b")
        print "[ {} ] Do Traffic Rules Creation".format("t")
        print "[ {} ] Do Traffic Rules Update".format("f")
        print "[ {} ] Do Traffic Rules Removal".format("r")
        print "[ {} ] Back".format("q")
    else:
        pass

def levelOne(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        print "exit program"
        sys.exit(0)
    if dictOpts['nevSdk'] in opts:
        gLevel = 'L2'
        usage(sys.argv[0] + ': ' + gLevel)

def levelTwo(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        gLevel = 'L1'
        usage(sys.argv[0] + ': ' + gLevel)
        return
    if dictOpts['multiPro'] in opts:
        gLevel = 'L3.1'
        usage(sys.argv[0] + ': ' + gLevel)
        return
    if dictOpts['singlePro'] in opts:
        gLevel = 'L3.2'
        usage(sys.argv[0] + ': ' + gLevel)
        return

def levelThrOne(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        gLevel = 'L2'
        usage(sys.argv[0] + ': ' + gLevel)
        return
    if dictOpts['startUsingServices'] in opts:
        meapp.liveIndicator()
        meapp.connectionEstablishment()
        meapp.serviceDiscovery(True)
        if meapp.subscribableServiceList:
            for service in meapp.subscribableServiceList:
                meapp.serviceSubscription(service.first, service.second)
                break
        return
    if dictOpts['stopUsingServices'] in opts:
        if meapp.subscribedServicesList:
            for service in meapp.subscribedServicesList:
                str = '1'
                meapp.arrServiceID = str.split()
                meapp.serviceUnsubscription(service.second)
                break
        meapp.terminationIndicator()
        return

def levelThrTwo(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        gLevel = 'L2'
        usage(sys.argv[0] + ': ' + gLevel)
        return
    for subOpts in opts:
        if dictOpts['liveindicator'] == subOpts:
            meapp.liveIndicator()
        elif dictOpts['terminationindicator'] == subOpts:
            meapp.terminationIndicator()
        elif dictOpts['connectionestablishment'] == subOpts:
            meapp.connectionEstablishment()
        elif dictOpts['servicediscovery'] == subOpts:
            meapp.serviceDiscovery(subOpts)
        elif dictOpts['servicesubscription'] == subOpts:
            meapp.serviceSubscription()
        elif dictOpts['subscriptionsupdate'] == subOpts:
            meapp.subscriptionsUpdate()
        elif dictOpts['serviceunsubscription'] == subOpts:
            meapp.serviceUnsubscription()
        elif dictOpts['subscriptionsreset'] == subOpts:
            meapp.subscriptionsReset()
        elif dictOpts['trafficrulecreation'] == subOpts:
            meapp.trafficRuleCreation()
        elif dictOpts['trafficruleupdate'] == subOpts:
            meapp.trafficRuleUpdate()
        elif dictOpts['trafficruleremoval'] == subOpts:
            meapp.trafficRuleRemoval()
        else:
            pass

levelFunc = {'L1': levelOne, 'L2': levelTwo, 'L3.1': levelThrOne, 'L3.2': levelThrTwo}

# Module execution control
def modulePerforms(opts):
    global gLevel
    if not opts:
        usage(sys.argv[0] + ': ' + gLevel)
        return

    if dictOpts['logOut'] in opts:
        # turn on debug log output switch
        meapp.logFlagForDebug = True
        opts.remove(dictOpts['logOut'])
    levelFunc.get(gLevel)(opts)

# convert string into opts
def stringToOpts(data):
    global gLevel
    opts = []
    dataTemp = re.findall('[A-Za-z]+', data)
    dataTemp = list('.'.join(dataTemp))
    for sep in dataTemp:
        if sep in COMMANDS[gLevel]:
            opts.append(sep)
    return opts


if __name__ == '__main__':
    outputLog()
    meapp = Meapp()
    actioncontinue = ""
    if len(sys.argv) > 1:
        try:
            opts, args = getopt.getopt(sys.argv[1:], "t:p:n:c:f:s:e:", ["actioncontinue=","path=","noninteractive=","cookie=","traffic=","subscription=","updatetraffic="])
        except getopt.GetoptError:
            print sys.argv[0], " [-t <actioncontinue>] [-p <json path>] [-n <commands>] [-c <cookie>] [-f <traffic>] [-s <subscription>] [-e <updatetraffic>]"
            sys.exit(1)

        commands = ""
        JsonPath = ""
        cookie = ""

        for opt, arg in opts:
            if opt in ("-p", "--path"):
                JsonPath=arg
                if not JsonPath or not os.path.exists(JsonPath):
                    print("The directory \"{}\" cannot be found.".format(JsonPath))
                    print "exit program"
                    sys.exit(0)
                meapp.setJsonPath(JsonPath)
            if opt in ("-f","--traffic"):
                trafficName=arg
                meapp.setTrafficName(trafficName)
            if opt in ("-e","--updatetraffic"):
                updatetraffic=arg
                meapp.setUpdateTrafficName(updatetraffic)
            if opt in ("-s","--subscription"):
                subscription=arg
                meapp.setSubscription(subscription)
            if opt in ("-t", "--actioncontinue"):
                actioncontinue = arg
            if opt in ("-n", "--noninteractive"):
                commands=arg
            elif opt in ("-c", "--cookie"):
                cookie=arg
                meapp.setCookie(arg)

        if commands:
            for arg in commands.split():
                modulePerforms(stringToOpts(arg))
            if actioncontinue != "True":
                sys.exit(0)
        elif cookie:
            print sys.argv[0], " [-t <actioncontinue>] [-p <json path>] [-n <commands>] [-c <cookie>] [-f <traffic>] [-s <subscription>] [-e <updatetraffic>]"
            sys.exit(1)
        elif not JsonPath:
            print sys.argv[0], " [-t <actioncontinue>] [-p <json path>] [-n <commands>] [-c <cookie>] [-f <traffic>] [-s <subscription>] [-e <updatetraffic>]"
            sys.exit(1)
    if actioncontinue != "True":
        usage(sys.argv[0] + ': ' + gLevel)
    while True:
        command = raw_input('\n>>>Please enter a command:')
        opts = stringToOpts(command)
        modulePerforms(opts)
        time.sleep(0.5)
