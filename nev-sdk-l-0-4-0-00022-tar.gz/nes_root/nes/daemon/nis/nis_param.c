/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
#include "nis/nis_param.h"
#include "nis/nis_acl.h"
#include "nes_common.h"

int nis_param_init(nes_acl_ctx_t *ctx)
{
    return nis_acl_lookup_init(ctx);
}

void nis_param_ctx_dtor(nes_acl_ctx_t *ctx)
{
    nis_acl_lookup_dtor(ctx);
}

int nis_param_rab_set(nes_acl_ctx_t *ctx, nis_param_pkt_flow_t *flow, nis_param_rab_t *rab_params)
{
    return nis_acl_lookup_add(ctx, flow, rab_params);
}

int nis_param_rab_get(nes_acl_ctx_t *ctx, nis_param_pkt_flow_t *flow, nis_param_rab_t ** param_rab)
{
    return nis_acl_lookup_find(ctx, flow, param_rab);
}

int nis_param_rab_del(nes_acl_ctx_t *ctx, nis_param_pkt_flow_t *flow)
{
    return nis_acl_lookup_del(ctx, flow);
}
