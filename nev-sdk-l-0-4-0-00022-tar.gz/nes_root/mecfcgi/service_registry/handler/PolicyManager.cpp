/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file     PolicyManager.cpp
* @brief    ME App/ME App Service Policy Management handlers implementations.
*/

#include "PolicyManager.h"
#include "PasswordHash.h"
#include "Exception.h"
#include "DbManager.h"
#include "HandlerCommon.h"
#include "Log.h"
#include "RawRequest.h"

void AuthenticateMeApp::execute(Json::Value &request, Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    try {
        string appid = request.get("appid", "Nil").asString();
        // Parameter Check
        if (0 == appid.compare("Nil")) {
            MECFCGI_LOG(ERR, "[appid] is not found in request.\n");
            throw Exception(Exception::INVALID_APPID);
        }

        // Authentication takes place
        string secret = request.get("secret", "Nil").asString();
        if (0 == secret.compare("Nil")) {
            MECFCGI_LOG(ERR,  "[secret] is not found in request.\n");
            throw Exception(Exception::INVALID_SECRET);
        }

        bool isFound = false;
        string result = "";
        DbManager::getMeAppSecret(isFound, result, appid);
        if (!isFound) {
            response["result"] = "NoPermission";
        } else {
            if (!PasswordHash::verify(result, secret)) {
                response["result"] = "SecretWrong";
            } else {
                response["result"] = "OK";
            }
        }
        headers["Status"] = HTTP_SC_OK;
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void RetrievePermittedServiceOps::execute(Json::Value &request,
                                            Json::Value &response,
                                            map<string, string> &headers,
                                            map<string, string> &cookies)
{
    try {
        string appid = request.get("appid", "Nil").asString();
        string serviceName = request.get("serviceName", "Nil").asString();

        // Parameter Check
        if (0 == appid.compare("Nil")) {
            MECFCGI_LOG(ERR, "[appid] is not found in request.\n");
            throw Exception(Exception::INVALID_APPID);
        }
        if (0 == serviceName.compare("Nil")) {
            MECFCGI_LOG(ERR, "Service name is not found in request.\n");
            throw Exception(Exception::INVALID_SERVICE_NAME);
        }

        string isDeactivationPermited;
        bool isFound = false;
        DbManager::getServicePermittedOps(isFound, isDeactivationPermited,
                                          appid, serviceName);
        if (isFound){
            response["isDeactivationPermited"] = isDeactivationPermited;
            response["result"] = "OK";

        } else {
            response["result"] = "NoPermission";
        }
        headers["Status"] = HTTP_SC_OK;

    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void RetrieveSubscribableServices::execute(map<string, string> params,
                                            Json::Value &response,
                                            map<string, string> &headers,
                                            map<string, string> &cookies)
{
    try {
        string appid = params["UUID"];

        // Parameter Check
        if (0 == appid.compare("")) {
            MECFCGI_LOG(ERR, "[appid] is not found in request.\n");
            throw Exception(Exception::INVALID_APPID);
        }

        // Get subscribable services info from database.
        DbManager::StringArrayType subscriptionServiceList;
        DbManager::getSubscribableServicesByAppid(subscriptionServiceList,
                                                    appid);
        Json::Value serviceList = Json::Value(Json::arrayValue);
        if (subscriptionServiceList.size() > 0) {
            for (string &subscriptionService_ : subscriptionServiceList) {
                Json::Value service;
                string providerAppid = "";
                string serviceName = "";

                string required = "";
                string isUnsubscriptionPermitted = "";
                DbManager::getSubscribableServicePermittedOps(required,
                                            isUnsubscriptionPermitted,
                                            subscriptionService_);

                service["required"] = required;
                service["isUnsubscriptionPermitted"] =
                    isUnsubscriptionPermitted;

                istringstream ssSubscriptionService(subscriptionService_);
                getline(ssSubscriptionService, serviceName, SPLIT_MARK);
                getline(ssSubscriptionService, serviceName, SPLIT_MARK);
                getline(ssSubscriptionService, serviceName, SPLIT_MARK);
                getline(ssSubscriptionService, providerAppid, SPLIT_MARK);
                service["serviceName"] = serviceName;
                service["providerAppId"] = providerAppid;
                serviceList.append(service);
            }
        }

        response["result"] = "OK";
        response["services"] = serviceList;
        headers["Status"] = HTTP_SC_OK;

    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void RetrieveAuthorizedPotentialSubscribers::execute(Json::Value &request,
                                                Json::Value &response,
                                                map<string, string> &headers,
                                                map<string, string> &cookies)
{
    try {
        string providerAppid = request.get("providerAppid", "Nil").asString();
        string serviceName = request.get("serviceName", "Nil").asString();

        // Parameter Check
        if (0 == providerAppid.compare("Nil")) {
            MECFCGI_LOG(ERR, "[providerAppid] is not found in request.\n");
            throw Exception(Exception::INVALID_APPID);
        }
        if (0 == serviceName.compare("Nil")) {
            MECFCGI_LOG(ERR, "Service name is not found in request.\n");
            throw Exception(Exception::INVALID_SERVICE_NAME);
        }

        // Retrieves all the ME Apps that may subscribe to a particular Service
        // from database.
        DbManager::StringArrayType subscriptionServiceList;
        DbManager::getSubscribableServicesByServiceName(subscriptionServiceList,
                                                        serviceName,
                                                        providerAppid);

        Json::Value appids = Json::Value(Json::arrayValue);
        if (subscriptionServiceList.size() > 0) {
            for (string &subscriptionService_ : subscriptionServiceList) {
                Json::Value subscribableAppids;
                string subscribableAppid = "";

                istringstream ssSubscriptionService(subscriptionService_);

                getline(ssSubscriptionService, subscribableAppid, SPLIT_MARK);
                getline(ssSubscriptionService, subscribableAppid, SPLIT_MARK);
                subscribableAppids["appid"] = subscribableAppid;

                appids.append(subscribableAppids);
            }
        }

        response["result"] = "OK";
        response["appids"] = appids;
        headers["Status"] = HTTP_SC_OK;

    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void RetrievePermittedTrafficRuleOps::execute(Json::Value &request,
                                                Json::Value &response,
                                                map<string, string> &headers,
                                                map<string, string> &cookies)
{
    string result = "";
    try {
        string appid = request.get("appid", "Nil").asString();

        // Parameter Check
        if (0 == appid.compare("Nil")) {
            MECFCGI_LOG(ERR, "[appid] is not found in request.\n");
            throw Exception(Exception::INVALID_APPID);
        }

        HandlerCommon::checkTrafficRuleFormat(result, request);
        if (0 != result.compare("OK")) {
            MECFCGI_LOG(ERR, "Traffic rule is invalid: %s.\n", result.c_str());
            throw Exception(Exception::INVALID_TRAFFIC_RULE);
        }

        response["result"] = "NoPermission";
        DbManager::StringArrayType settableTrafficRules;
        DbManager::getSettableTrafficRules(settableTrafficRules, appid);
        if (settableTrafficRules.size() > 0) {
            for (string &settableTrafficRule_ : settableTrafficRules) {
                string sSettableTrafficRule;

                istringstream ssSettableTrafficRule(settableTrafficRule_);
                getline(ssSettableTrafficRule, sSettableTrafficRule,
                    SPLIT_MARK); //SRMEATR
                getline(ssSettableTrafficRule, sSettableTrafficRule,
                    SPLIT_MARK); //appid
                getline(ssSettableTrafficRule, sSettableTrafficRule);

                Json::Reader reader;
                Json::Value settableTrafficRule;
                reader.parse(sSettableTrafficRule,settableTrafficRule);
                bool match = false;
                HandlerCommon::compareTrafficRule(match, settableTrafficRule,
                    request);
                if (match){
                    string isUpdatePermitted = "";
                    string isRemovalPermitted = "";
                    DbManager::getTrafficRulePermittedOps(isUpdatePermitted,
                        isRemovalPermitted, settableTrafficRule_);
                    response["isUpdatePermitted"] = isUpdatePermitted;
                    response["isRemovalPermitted"] = isRemovalPermitted;
                    response["result"] = "OK";
                    break;
                }
            }
        }
        headers["Status"] = HTTP_SC_OK;
    }
    catch (Exception &e) {
        if (e.code == Exception::INVALID_TRAFFIC_RULE) {
            headers["Status"] = HTTP_SC_BAD_REQUEST;
            response["result"] = result;
        } else {
            string res;
            string statusCode;
            Exception::handlerException(e, res, statusCode);
            headers["Status"] = statusCode;
            response["result"] = res;
        }
    }
}
