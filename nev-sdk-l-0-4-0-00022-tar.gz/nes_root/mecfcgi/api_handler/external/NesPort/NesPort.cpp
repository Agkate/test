/*******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ******************************************************************************/
/**
 * @file  NesPort.cpp
 * @brief nes wrapper
 */

#include "NesPort.h"
#include "NesPortFactory.h"
#include "Redis.h"
#include "Exception.h"
#include "DbManager.h"
#include "Log.h"

using namespace std;

const char SPLIT_MARK = ':';

#define NES_CONN_IP_ADDR_DEFAULT "0.0.0.0"
#define NES_CONN_PORT_NUMBER_DEFAULT 6666
static void nesPortWatcherWorker(NesPort *self)
{
    while (NesPort::STATE_RUNNING == self->state) {
        if (NesPort::STATE_NOTCONNECT == self->trfficCtrConn_state) {
            if (NES_SUCCESS == nes_conn_init(&self->trfficCtrConn, 
                                            (char *)NES_CONN_IP_ADDR_DEFAULT, 
                                            NES_CONN_PORT_NUMBER_DEFAULT)) {
                self->trfficCtrConn_state = NesPort::STATE_CONNECT;
            } else {
                sleep(1);
            }
        }
        if ((NesPort::STATE_CONNECT == self->trfficCtrConn_state)&&
            (0 == (INIT_NTS_FLAG & self->initNes_state))) {
            if (NesPort::INIT_NES_SUCCESS == self->initTrafficRulesInfo()) {
                self->initNes_state |= INIT_NTS_FLAG;
                break;
            } else {
                sleep(1);
            }
        }    
    }
}

NesPort::NesPort():
trfficCtrConn_state(STATE_NOTCONNECT),
initNes_state(0)
{
    memset(&trfficCtrConn, 0, sizeof(nes_remote_t));
}

NesPort::~NesPort()
{

}

void NesPort::startNesPortWatcher()
{
    if (STATE_STOPPED == state) {
        state = STATE_RUNNING;
        worker = thread(nesPortWatcherWorker, this);
    }
}

void NesPort::stopNesPortWatcher()
{
    if (STATE_STOPPED != state) {
        state = STATE_STOPPED;
    }
}

void NesPort::addRoute(AddRoute &params)
{
    struct ether_addr *mecaddr = ether_aton(params.macAddr.c_str());
    if (NULL == mecaddr) {
        throw Exception(Exception::TRAFFIC_RULE_ERR, 
            "Pointer of mecaddr is NULL");
    }
    if (NES_SUCCESS != nes_route_add(&trfficCtrConn, *mecaddr, 
                                    (char *)params.lookupKeys.c_str(), 
                                    params.vmId)) {
        throw Exception(Exception::TRAFFIC_RULE_ERR, "Add route");
    }
}

void NesPort::removeRoute(RemoveRoute &params)
{
    if (NES_SUCCESS != nes_route_remove(&trfficCtrConn, 
                                        (char *)params.lookupKeys.c_str())) {
        throw Exception(Exception::TRAFFIC_RULE_ERR, "Remove route");
    }
}

int NesPort::initTrafficRulesInfo()
{
    if (NES_SUCCESS != nes_route_clear_all(&trfficCtrConn)) {
        MECFCGI_LOG(WARNING, "Traffic rule clearance failed.\n");
        return INIT_NES_FAILED;
    }

    DbManager::StringArrayType trafficRuleIdList;
    try {
        DbManager::getTrafficRuleIdList(trafficRuleIdList);
    }
    catch (Exception &e) {
        MECFCGI_LOG(WARNING, 
            "Traffic rule init failed: Error in getting traffic rule(%d:%s) \n", 
            e.code, e.err.c_str());
        return INIT_NES_FAILED;
    }
    if (trafficRuleIdList.size() > 0) {
        for (string &trafficRuleId_ : trafficRuleIdList) {
            istringstream ssTrafficRuleId(trafficRuleId_);
            getline(ssTrafficRuleId, trafficRuleId_, SPLIT_MARK);
            getline(ssTrafficRuleId, trafficRuleId_);
            string lookupKeys;
            string macAddress;
            string vmId;
            try {
                DbManager::getTrafficRuleLookupByRuleId(lookupKeys,
                                                        trafficRuleId_);
                DbManager::getTrafficRuleMacAddressByRuleId(macAddress,
                                                            trafficRuleId_);
                DbManager::getTrafficRuleVmIdByRuleId(vmId, trafficRuleId_);
                struct ether_addr *mecaddr = ether_aton(macAddress.c_str());
                if (NULL == mecaddr) {
                    MECFCGI_LOG(WARNING, 
                        "Traffic rule init failed: Error in Database. \n");
                    DbManager::delTrafficRulesInfo(trafficRuleId_);
                    return INIT_NES_FAILED;
                }
                if (NES_SUCCESS != nes_route_add(&trfficCtrConn, *mecaddr, 
                                        (char *)lookupKeys.c_str(),
                                        uint32_t(atoi((char *)vmId.c_str())))) {
                    MECFCGI_LOG(WARNING, 
                        "Traffic rule init failed: NTS returned error.\n");
                    return INIT_NES_FAILED;
                }
            }
            catch (Exception &e) {
                MECFCGI_LOG(WARNING, 
                    "Traffic rule init failed: Error in Database(%d:%s) \n", 
                    e.code, e.err.c_str());
                DbManager::delTrafficRulesInfo(trafficRuleId_);
                return INIT_NES_FAILED;
            }
        }
    }
    return INIT_NES_SUCCESS;
}

