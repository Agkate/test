#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

export ENDPOINT="a3m975cmytkj0x.iot.eu-central-1.amazonaws.com"
export CORE_ARN="arn:aws:iot:eu-central-1:605267303357:thing/AWSCLI-test-Core"

# variables for device 1
export DEV1_IP="192.168.100.130"
export DEV1_USER="int26"
export DEV1_PASSWORD="int26"

# variables for device 2
export DEV2_IP="192.168.100.131"
export DEV2_USER="int26"
export DEV2_PASSWORD="int26"

export DST_SAMPLES_DIR="gg_samples"
export SRC_SAMPLES_DIR="../../samples/greengrass/tools"


export GG_HELLO_PUB_NAME="HelloWorld_Publisher"
export GG_HELLO_SUB_NAME="HelloWorld_Subscriber"
export GG_SHADOW_PUB_NAME="ShadowPublisher"
export GG_SHADOW_SUB_NAME="ShadowSubscriber"
export IOT_SDK_URL="https://github.com/aws/aws-iot-device-sdk-python/archive/v1.3.1.tar.gz"

export GG_CORE1="192.168.1.5"
export NES_DEV_IP="192.168.200.1"

. functions.sh

# check if all device resources are present
check_dev_res ${GG_HELLO_PUB_NAME} || exit 1
check_dev_res ${GG_HELLO_SUB_NAME} || exit 1
check_dev_res ${GG_SHADOW_PUB_NAME} || exit 1
check_dev_res ${GG_SHADOW_SUB_NAME} || exit 1

ping ${NES_DEV_IP} > /dev/null 2>&1 &

# copy ssh keys to devices
copy_sshkey_to_remote "${DEV1_IP}" "${DEV1_USER}" "${DEV1_PASSWORD}"
copy_sshkey_to_remote "${DEV2_IP}" "${DEV2_USER}" "${DEV2_PASSWORD}"

exec_on_remote "${DEV1_IP}" "${DEV1_USER}" "rm -rf ${DST_SAMPLES_DIR}; mkdir -p ${DST_SAMPLES_DIR}"
exec_on_remote "${DEV2_IP}" "${DEV2_USER}" "rm -rf ${DST_SAMPLES_DIR}; mkdir -p ${DST_SAMPLES_DIR}"
scp -r ${SRC_SAMPLES_DIR}/* ${DEV1_USER}@${DEV1_IP}:${DST_SAMPLES_DIR}/
scp -r ${SRC_SAMPLES_DIR}/* ${DEV2_USER}@${DEV2_IP}:${DST_SAMPLES_DIR}/

exec_on_remote "${DEV1_IP}" "${DEV1_USER}" "cd ${DST_SAMPLES_DIR}; wget -c ${IOT_SDK_URL} \
    -O iot_sdk.tar.gz; tar xf iot_sdk.tar.gz --overwrite"
exec_on_remote "${DEV2_IP}" "${DEV2_USER}" "cd ${DST_SAMPLES_DIR}; wget -c ${IOT_SDK_URL} \
    -O iot_sdk.tar.gz; tar xf iot_sdk.tar.gz --overwrite"

declare -a test_cases=("tc_1" "tc_2" "tc_3" "tc_4" "tc_5" "tc_6" "tc_7" "tc_8" "tc_9")
test_cases_len=${#test_cases[@]}

test_counter=0
success_counter=0
failed_counter=0

if [ $# -eq 0 ]; then
    for testcase in "${test_cases[@]}"
    do
        echo "##################################"
        echo "Executing $testcase"

        if ${testcase}/run_test.sh ; then
            success_counter=$((success_counter+1))
            echo "[OK] TEST ${testcase} success"
        else
            failed_counter=$((failed_counter+1))
            echo "[FAIL] TEST ${testcase} failed"
        fi

        test_counter=$((test_counter+1))
        sleep 2
    done
else
    testcase=$1

    echo '##################################'
    echo "Executing $testcase"

    if ${testcase}/run_test.sh ; then
        success_counter=$((success_counter+1))
        echo "[OK] TEST ${testcase} success"
    else
        failed_counter=$((failed_counter+1))
        echo "[FAIL] TEST ${testcase} failed"
    fi
fi

trap 'kill $(jobs -p)' EXIT

rem_sshkey_in_remote "${DEV1_IP}" "${DEV1_USER}"
rem_sshkey_in_remote "${DEV2_IP}" "${DEV2_USER}"

if [ $# -eq 0 ]; then
    echo "Test count: $test_counter"
    echo "Success: $success_counter"
    echo "Failed: $failed_counter"
fi
