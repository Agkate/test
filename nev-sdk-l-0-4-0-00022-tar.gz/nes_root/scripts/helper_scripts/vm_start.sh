#!/bin/sh
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

#Start forwarder on VM
NAMESPACE=$(ip netns | grep -m 1 qdhcp)
IP=$(nova show ${VM1_NAME} | grep ${MGMT_NET} |grep -oE "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b")

#cat ~/.ssh/id_rsa.pub | ip netns exec $NAMESPACE  ssh root@$IP "mkdir -p ~/.ssh && cat >>  ~/.ssh/authorized_keys"

ip netns exec $NAMESPACE ssh -o StrictHostKeyChecking=no root@$IP "/root/dpdk-1.7.1/examples/l2fwd/doit.sh &>l2fwd_vm.log  &"

exit 0
