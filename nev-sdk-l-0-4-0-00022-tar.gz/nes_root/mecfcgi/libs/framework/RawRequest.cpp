/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file RawRequest.cpp
 * @brief Implementation of RawRequest
*/

#include "RawRequest.h"
#include "Exception.h"
#include <sstream>
#include <boost/algorithm/string.hpp>
#include "Log.h"

using namespace boost::algorithm;
using namespace std;


RawRequest::RawRequest(string &&baseURI)
  : baseURI(baseURI)
{
//This is a constructor
}

void RawRequest::printHeaders(map<string, string> &headers)
{
    map<string, string>::iterator iter = headers.find("Status");
    if(headers.end() == iter) {
        cout << "Status: 200 OK\r\nContent-type: application/json\r\n";
    } else {
        cout <<"Content-type: application/json\r\n";
    }

    if (headers.size() > 0) {
        for (pair<string, string> header : headers) {
           cout << header.first << ": " << header.second << "\r\n";
        }
    }
    cout << "\r\n";
}

void RawRequest::postRequest(const string &action,
                             FCGX_Request &request,
                             map<string, string> &cookies,
                             PostRequestDispatcher &dispatcher)
{
    Json::Value requestJson;
    cin >> requestJson;

    Json::Value responseJson;
    map<string, string> headers;
    dispatcher.dispatchRequest(action, requestJson, responseJson, headers, cookies);
    printHeaders(headers);
    cout << responseJson;
}

void RawRequest::getRequest(const string &action,
                            FCGX_Request &request,
                            map<string, string> &cookies,
                            GetRequestDispatcher &dispatcher)
{
    istringstream queryString(FCGX_GetParam("QUERY_STRING", request.envp));

    string key, val;
    map<string, string> params;
    while (getline(queryString, key, '=') && getline(queryString, val, '&')) {
        params[key] = val;
    }

    Json::Value responseJson;
    map<string, string> headers;
    dispatcher.dispatchRequest(action, params, responseJson, headers, cookies);
    printHeaders(headers);
    cout << responseJson;
}

void RawRequest::putRequest(const string &action,
                             FCGX_Request &request,
                             map<string, string> &cookies,
                             PutRequestDispatcher &dispatcher)
{
    Json::Value requestJson;
    cin >> requestJson;

    Json::Value responseJson;
    map<string, string> headers;
    dispatcher.dispatchRequest(action, requestJson, responseJson, headers, cookies);
    printHeaders(headers);
    cout << responseJson;
}

void RawRequest::delRequest(const string &action,
                             FCGX_Request &request,
                             map<string, string> &cookies,
                             DelRequestDispatcher &dispatcher)
{
    istringstream queryString(FCGX_GetParam("QUERY_STRING", request.envp));

    string key, val;
    map<string, string> params;
    while (getline(queryString, key, '=') && getline(queryString, val, '&')) {
        params[key] = val;
    }

    Json::Value responseJson;
    map<string, string> headers;
    dispatcher.dispatchRequest(action, params, responseJson, headers, cookies);
    printHeaders(headers);
    cout << responseJson;
}

void RawRequest::dispatch(FCGX_Request &request)
{
    const string me_manager_client_ip = "127.0.0.1";
    const std::array<string, 2> me_manager_uris = {"/appliance/v1/configuration", "/appliance/v1/terminate"};

    string contentType(FCGX_GetParam("CONTENT_TYPE", request.envp));
    string requestMethod(FCGX_GetParam("REQUEST_METHOD", request.envp));
    string documentURI = FCGX_GetParam("DOCUMENT_URI", request.envp);
    istringstream cookies(FCGX_GetParam("HTTP_COOKIE", request.envp) ? FCGX_GetParam("HTTP_COOKIE", request.envp) : "");
    string source_ip(FCGX_GetParam("REMOTE_ADDR", request.envp));

    // disable the usage of memanager from outside
    if (source_ip != me_manager_client_ip &&
        std::find(me_manager_uris.begin(), me_manager_uris.end(), documentURI) != std::end(me_manager_uris)) {
            MECFCGI_LOG(ERR, "Not allowed to use MeManager from %s\n", source_ip.c_str());
            throw Exception(Exception::DISPATCH_NOTYPE, "Unauthorized MeManager usage");
    }

    string key, val;
    map<string, string> cookieParams;
    while (getline(cookies, key, '=') && getline(cookies, val, ';')) {
        trim(val);
        trim(key);
        cookieParams[key] = val;
    }

    if ((0 == requestMethod.compare("POST")) && (0 == contentType.compare("application/json"))) {
        RawRequest::postRequest(documentURI.substr(baseURI.length()), request, cookieParams, postDispatcher);
    } else if (0 == requestMethod.compare("GET")) {
        RawRequest::getRequest(documentURI.substr(baseURI.length()), request, cookieParams, getDispatcher);
    } else if ((0 == requestMethod.compare("PUT")) && (0 == contentType.compare("application/json"))) {
        RawRequest::putRequest(documentURI.substr(baseURI.length()), request, cookieParams, putDispatcher);
    } else if (0 == requestMethod.compare("DELETE")) {
        RawRequest::delRequest(documentURI.substr(baseURI.length()), request, cookieParams, delDispatcher);
    } else {
        stringstream ss;
        ss << "Method: " << requestMethod << "Content type: " << contentType << " not supported";
        MECFCGI_LOG(ERR, "%s .\n", ss.str().c_str());
        throw Exception(Exception::DISPATCH_NOTYPE, ss.str());
    }
}
