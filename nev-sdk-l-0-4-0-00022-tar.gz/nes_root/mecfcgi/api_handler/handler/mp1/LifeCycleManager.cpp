/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  LifeCycleManager.cpp
* @brief Mobile Edge Application Live Indicator And Termination Indicator
*/

#include "LifeCycleManager.h"
#include "ServiceRegistryPort.h"
#include "SessionManager.h"
#include "Exception.h"
#include "HandlerCommon.h"
#include "DbManager.h"
#include "Log.h"
#include "RawRequest.h"
#include "NesPortFactory.h"
#include "LifeCycleSupport.h"
#include "WebSocketServer.h"

void AppLiveIndicator::execute(Json::Value &request, Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    string appid = request.get("appid", "Nil").asString();
    string secret = request.get("secret", "Nil").asString();
    string type = request.get("type", "Nil").asString();

    string token = "";
    try {
        // Check for empty fields and invalid app types.
        if (0 == appid.compare("Nil")) {
            MECFCGI_LOG(ERR, "[appid] is not found.\n");
            throw Exception(Exception::INVALID_APPID);
        }
        if (0 == secret.compare("Nil")) {
            MECFCGI_LOG(ERR,  "[secret] is not found.\n");
            throw Exception(Exception::INVALID_SECRET);
        }
        if (0 != type.compare(MEAPP_TYPE_MEAPP) &&
            0 != type.compare(MEAPP_TYPE_MEAPPSERVICE) &&
            0 != type.compare(MEAPP_TYPE_CHILDAPP) &&
            0 != type.compare(MEAPP_TYPE_PFPRODUCERAPP)) {
            MECFCGI_LOG(ERR, "[type:%s] is not recognized.\n", type.c_str());
            throw Exception(Exception::INVALID_TYPE);
        }

        // Authenticate registrant app against service registry records.
        string result = "";
        ServiceRegistryPort::checkPolicyForMeApp(result, appid, secret, type);
        if (0 != result.compare("OK")) {
            if (0 == result.compare("NoPermission")) {
                MECFCGI_LOG(ERR, "ME App[%s]:No Permission.\n", appid.c_str());
                throw Exception(Exception::NO_PERMISSION);
            } else if (0 == result.compare("SecretWrong")) {
                MECFCGI_LOG(ERR, "ME App[%s]:Secret wrong.\n", appid.c_str());
                throw Exception(Exception::SECRET_WRONG);
            } else {
                MECFCGI_LOG(ERR, "ME App[%s]:Unkown error.\n", appid.c_str());
                throw Exception(Exception::UNKOWN_ERROR);
            }
        }

        // Generate token on authentication success.
        bool isFound = false;
        DbManager::checkAndGetTokenByAppid(isFound, token, appid);
        if (isFound) {
            headers["Set-Cookie"] = "SESSID=" + token;
            MECFCGI_LOG(WARNING, "Appid[%s] is already authenticated.\n",
                appid.c_str());
            throw Exception(Exception::DUPLICATE_APPID);
        }
        SessionManager::createSession(token, appid, secret);

        // Save application ID, application type, and token to database and
        // return response.
        DbManager::saveMeAppInfo(appid, type, token);
        headers["Set-Cookie"] = "SESSID=" + token;
        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
        MECFCGI_LOG(INFO, "Service Registry responded with OK.\n");
    }
    catch (Exception &e)
    {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void AppTerminationIndicator::execute(map<string, string> params,
                                        Json::Value &response,
                                        map<string, string> &headers,
                                        map<string, string> &cookies)
{
    try {
        string appid = "";
        string token = "";
        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);
        
        // Clear ME App/ME App Service information from database.
        HandlerCommon::delMeAppInformation(appid);

        // Check if there is timeout checker for its termination: 
        //  if there is one, the termination request is sent in response to a 
        //      termination notification;
        //  otherwise it is a app-initiated termination indicator.
        bool isFound = false;
        TimeoutChecker::getInstance().findAppTimeoutStatus(isFound, appid);
        if(isFound) {
            TimeoutChecker::getInstance().cleanAppTimeoutValue(appid);
            Json::Value message;
            message["id"] = "TerminationNotification";
            message["data"] = appid;
            Json::FastWriter writer;
            string sMessage = writer.write(message);
            getWebServer()->pushData("memanager", "TerminationNotification", sMessage);
        }

        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}
