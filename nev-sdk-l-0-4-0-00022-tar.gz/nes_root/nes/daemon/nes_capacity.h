/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file nes_capacity.h
* @brief NES daemon capacity limitations
*/

#ifndef _NES_CAPACITY_H_ 
#define _NES_CAPACITY_H_ 
 
#ifdef __cplusplus 
extern "C" { 
#endif 

#define NES_MAX_CELLS       (48)
#define NES_MAX_UE_PER_CELL (1000)
#define NES_MAX_UE          (NES_MAX_CELLS * NES_MAX_UE_PER_CELL)

#define NES_MAX_RB_PER_UE (4)
#define NES_MAX_RB        (NES_MAX_UE * NES_MAX_RB_PER_UE)

#define NES_MAX_MEC_APPS          (4)

#define NES_MAX_ROUTING_RULES_PER_MEC_APP (1024)
#define NES_MAX_ROUTING_RULES             (NES_MAX_MEC_APPS * NES_MAX_ROUTING_RULES_PER_MEC_APP)

#define NES_MAX_SERVICES_PER_MEC_APP (64)
#define NES_MAX_SERVICES             (NES_MAX_MEC_APPS * NES_MAX_SERVICES_PER_MEC_APP)

#ifdef __cplusplus 
} 
#endif /* extern "C" */ 
 
#endif /* _NES_CAPACITY_H_ */
