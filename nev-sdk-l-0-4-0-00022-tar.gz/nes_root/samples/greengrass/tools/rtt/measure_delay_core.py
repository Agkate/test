#!/usr/bin/env python

###################################################################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
###################################################################################################

# Standard library imports:
import itertools
import json
import os
import signal
import sys
import time

# GG/MEC imports:
sys.path.append("../")
from ggmec import make_thing_parser, setup_logger, setup_mqtt_shadow_client, retrieve_ggc_conf

GROUP_PATH = "./groupCA"
def shadow_update(options, client, handler, stats_file):
    stats = {
        "delay_max": 0,
        "delay_min": 9999999999,
        "delay_sum": 0,
        "sample_cnt": 0}

    stats_file.write("Current[ms];Min[ms];Max[ms];Avg[ms]\n")

    def shadow_update_cb(payload, responseStatus, token):
        if responseStatus == "timeout":
            _LOG.info("Update request {0:s} time out".format(token))
        elif responseStatus == "accepted":
            data = json.loads(payload)

            _LOG.info(payload)

            data = json.loads(payload)
            delay = (time.time() - data['state']['desired']['ts'] ) * 1000
            stats["delay_max"] = max(stats["delay_max"], delay)
            stats["delay_min"] = min(stats["delay_min"], delay)
            stats["delay_sum"] += delay
            stats["sample_cnt"] += 1

            delay_avg = stats["delay_sum"]/stats["sample_cnt"]

            _LOG.info(
                "RTT for core: {0}, min={1}, max={2}, avg={3}"
                "".format(delay, stats["delay_min"], stats["delay_max"], delay_avg))

            stats_file.write(
                "{0};{1};{2};{3}\n"
                "".format(delay, stats["delay_min"], stats["delay_max"], delay_avg))

        elif responseStatus == "rejected":
            _LOG.info("Update request {0:s} rejected".format(token))

    return shadow_update_cb

#This function callback is used only on first iteration of RTT measurement to fix average time measurement, as first request takes significantly more time
def first_update_cb(payload, responseStatus, token):
    _LOG.debug("First shadow update dummy callback checkpoint")

def main(options):

    ggc_conf = retrieve_ggc_conf(options)

    if ggc_conf is None:
        _LOG.critical("Failed to retrieve GG Core address")
        return 1

    ggc_addr = ggc_conf['host']
    ca_path = ggc_conf['path']
    shadow_client = setup_mqtt_shadow_client(options, ggc_addr, ca_path)
    if not shadow_client.connect():
        _LOG.critical("AWS IoT connection failed")
        return 1
    else:
        _LOG.debug("AWS IoT connection established successfully")

    handler = shadow_client.createShadowHandlerWithName(options.thing_name, True)

    stats_file = open("core.csv", "w")

    shadow_update_cb = shadow_update(options, shadow_client, handler, stats_file)

    def __int_cb(signal, frame):
        _LOG.debug("Closing the stats file")
        stats_file.close()
        sys.exit(0)
    signal.signal(signal.SIGINT, __int_cb)

    seq_num = 0
    states = ["State #1", "State #2", "State #3", "State #4"]
    for state in itertools.cycle(states):
        timestamp = time.time()
        data = {
            "state": {
                "desired": {
                    "property": "{0:s}   loop count: {1:d}".format(state, seq_num),
                    "ts": timestamp
                }
            }
        }

        if not seq_num:
            handler.shadowUpdate(json.dumps(data), first_update_cb, 1)
        else:
            handler.shadowUpdate(json.dumps(data), shadow_update_cb, 1)

        seq_num += 1
        time.sleep(1)

if __name__ == '__main__':
    options = make_thing_parser().parse_args()
    _LOG = setup_logger(options)
    sys.exit(main(options))
