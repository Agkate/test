/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file nes_dev.h
* @brief Header file for nes device. Includes declarations for nes_dev_eth and nes_dev_vhost
*/
#ifndef _NES_DEV_H_ 
#define _NES_DEV_H_ 
 
#ifdef __cplusplus 
extern "C" { 
#endif 

#include <sys/param.h>
    
#include <rte_pci.h>
#include <rte_ether.h>
#include <rte_ip_frag.h>

  
#include "nes_common.h"
#include "nes_ring.h"
    
#define ENB_RX_RINGS_CNT 5
#define EPC_RX_RINGS_CNT 5

#define RESEND_TIMEOUT_US 500  
    
#define MAX_TROUGHPUT (1E10 / 8) // B/s for 10Gb NIC
#define MAX_BYTES_ETH_STATS 0xFFFFFFFFF // There is 36 bit a register in tested NICs for bytes stats
#define STATS_REFRESH_TIME ((uint64_t)(MAX_BYTES_ETH_STATS / MAX_TROUGHPUT) - 2) // 2 is to prevent stats overflow
#define MAX_PORTS UINT8_MAX
#define CHECK_INTERVAL 100 /* 100ms */
#define MAX_CHECK_TIME 90 /* 9s (90 * 100ms) in total */

#define LBP_RX_RING_NAME "NTS_LBP_ANY"
#define LBP_TX_RING_NAME "LBP_IO_ANY"
#define AVP_RX_RING_NAME "NTS_AVP_ANY"
#define AVP_TX_RING_NAME "AVP_IO_ANY"
    
#define TX_BUFFER_SIZE (2 * MAX(MAX_BURST_SIZE, RTE_LIBRTE_IP_FRAG_MAX_FRAG))

extern struct rte_mempool *nes_main_pktmbuf_pool;
extern struct rte_mempool *nes_main_indir_pktmbuf_pool;
struct nes_ctrl_dev_s; 

/**
* Ethernet type device distinctive parameters
*/
typedef struct nes_dev_id_eth_s { 
    int port_id; 
    int queue_id; 
} nes_dev_id_eth_t; 

/**
* VHOST device state
*/
typedef enum {
    VHOST_NOT_READY,
    VHOST_READY
} nes_dev_vhost_status;

/**
* VHOST type device distinctive parameters
*/
typedef struct nes_dev_id_vhost_s { 
    int vm_id; 
    volatile nes_dev_vhost_status status;
} __rte_cache_aligned nes_dev_id_vhost_t; 
 
/**
* NES device type
*/
typedef union nes_dev_id_s { 
    nes_dev_id_eth_t  eth;
    nes_dev_id_vhost_t vhost;
} nes_dev_id_t; 

typedef enum {
    ETH = 0,
    VHOST
} nes_dev_id_type;
   

typedef enum {
    TT_IP = 0,
    TT_LTE,
    TT_MIXED,
} nes_dev_traffic_type;

typedef enum {
    TD_UPSTREAM = 0,
    TD_DOWNSTREAM,
    TD_BOTH,
    TD_LBP,
    TD_AVP
} nes_dev_traffic_dir;

typedef struct egress_port_s
{
    struct src {
        nes_ring_t  *ring;
        int         from_config;    /* determine if this ring could be overwritten by learning */
    }src;
    struct dst {
        nes_ring_t  *ring;
    }dst;
    nes_dev_traffic_dir  direction;
} egress_port_t;

/**
* NES Device class
* Instance can be of Ethernet or VHOST type
*/
typedef struct nes_dev_s { 
    nes_dev_id_t dev; 
    nes_dev_id_type dev_type;
     
    nes_ring_t **rx_rings; 
    int rx_ring_cnt; 
  
    nes_ring_t *rx_default_ring;
    nes_ring_t *tx_ring; 
   
    struct rte_mbuf *rx_pkts[MAX_BURST_SIZE]; 
    int rx_cnt; 
   
    struct rte_mbuf *tx_buffer[TX_BUFFER_SIZE]; 
    int tx_buffer_cnt;
    uint64_t retry_send_start;
    uint64_t retry_timeout_cycles;

    struct ether_addr mac_address;
    
    nes_dev_traffic_type traffic_type;
    nes_dev_traffic_dir traffic_dir;
    int egres_port;
    char *name;
    uint8_t nes_port_id;
    uint8_t remove;
    struct rte_ip_frag_tbl *frag_tbl;
    struct rte_ip_frag_death_row death_row;
    uint16_t MTU;
    
    struct nes_ctrl_dev_s *dev_stats;
    int (*ctor)(struct nes_dev_s *self, void *data); 
    int (*dtor)(struct nes_dev_s *self, void *data); 
    int (*recv)(struct nes_dev_s *self, void *data); 
    int (*send)(struct nes_dev_s *self, void *data); 
    int (*scatter)(struct nes_dev_s *self, void *data); 
   
} nes_dev_t; 

extern nes_lookup_table_t *egress_port_table;
 /**
 * Early initialization for vhost
 * Mempool initialization, CUSE driver registration and starting session
 *
 * @return
 *   NES_SUCCESS on success or NES_FAIL on error
 */
int nes_dev_vhost_early_init(void);

int nes_dev_eth_mac_addr_get(uint8_t port_id, struct ether_addr *addr);

int nes_dev_eth_pci_addr_get(uint8_t port_id, struct rte_pci_addr *addr);

void nes_dev_eth_start_stats_timer(void);

int count_port_devices(void);

int is_lbp_enabled(void);

char *get_lbp_port_name(void);

int is_avp_enabled(void);

int nes_dev_port_new_device(void);

void nes_dev_port_dtor(void);

int init_eth_port(uint8_t port_num, uint8_t queue_num);

int recv_eth(struct nes_dev_s *self, __attribute__((unused)) void *data);

int send_eth(struct nes_dev_s *self, __attribute__((unused)) void *data);

int send_eth_mtu(struct nes_dev_s *self, __attribute__((unused)) void *data);

void check_eth_port_link_status(uint8_t portid);

int nes_dev_eth_find_port_id_by_pci(struct rte_pci_addr *pci_addr, uint8_t *port_id);

#ifdef __cplusplus 
} 
#endif /* extern "C" */ 
 
#endif /* _NES_DEV_H_ */

