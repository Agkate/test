/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file nes_arp.h
 * @brief Header file for nes_arp
 *
 */

#ifndef NES_ARP_H
#define	NES_ARP_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <rte_ether.h>

#define ARP_REQUEST 1
#define ARP_REPLY 2
#define HTYPE_ETHER 1

typedef struct arp_header_ipv4_s {
    uint16_t htype;
    uint16_t ptype;
    uint8_t hlen;
    uint8_t plen;
    uint16_t oper;
    struct ether_addr sha;
    uint32_t spa;
    struct ether_addr tha;
    uint32_t tpa;
} __attribute__((__packed__))arp_header_ipv4_t;

int nes_arp_response(struct rte_mbuf *m, struct ether_addr eth_addr);

#ifdef	__cplusplus
}
#endif

#endif	/* NES_ARP_H */

