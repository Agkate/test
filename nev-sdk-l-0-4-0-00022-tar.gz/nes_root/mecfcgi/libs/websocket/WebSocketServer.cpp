/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/** 
 * @file     WebSocketServer.cpp 
 * @brief    Implementation of WebSocketServer.
 */

#include <stdio.h>
#include "WebSocketServer.h"
#include "Defs.h"
#include <pthread.h>
#include "Log.h"

const uint32_t MAX_L_NUMBER = 20;
static string hostIp;
static int websocketPort;
static CWebSocket g_ws;
static pthread_t worker;

CWebSocket *getWebServer()
{
    return &g_ws;
}

static void* webSocketServerProc(void *param)
{
    g_ws.initSocket(hostIp, websocketPort, MAX_L_NUMBER);
    g_ws.startListenThread();
    return NULL;
}

int startWebSocketServer(string ip, int port)
{
    int err;
    hostIp = ip;
    websocketPort = port;
    err = pthread_create(&worker, 0, webSocketServerProc, NULL);
    if (0 != err) {
        MECFCGI_LOG(ERR, "Thread cannot be created: %s\n", strerror(err));
        return -1;
    }
    return 0;
}
