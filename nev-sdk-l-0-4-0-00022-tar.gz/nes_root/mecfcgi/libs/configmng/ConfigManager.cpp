/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
 * @file     ConfigManager.cpp
 * @brief    Implementation for reading a configuration file.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "rte_cfgfile.h"
#include "ConfigManager.h"

struct rte_cfgfile * ConfigManager::mecfcgi_cfgfile = NULL;

int ConfigManager::openConfigFile(string cfgFilePath)
{
    int ret = CFGFILE_FAIL;

    int flags = 0; /* No flags */

    mecfcgi_cfgfile = rte_cfgfile_load(cfgFilePath.c_str(), flags);

    ret =  (NULL == mecfcgi_cfgfile) ? CFGFILE_FAIL : CFGFILE_SUCCESS;

    return ret;
}

int ConfigManager::getConfigData(string section, string entry, string &value)
{
    int ret = CFGFILE_FAIL;
    assert(mecfcgi_cfgfile);
    const char *val;
    val = rte_cfgfile_get_entry(mecfcgi_cfgfile, section.c_str(), entry.c_str());
    if (NULL == val) {
        value = "";
        ret = CFGFILE_FAIL;
    } else{
        value = val;
        ret = CFGFILE_SUCCESS;
    }
    return ret;
}

void ConfigManager::closeConfigFile(void)
{
    rte_cfgfile_close(mecfcgi_cfgfile);
    mecfcgi_cfgfile = NULL;
}