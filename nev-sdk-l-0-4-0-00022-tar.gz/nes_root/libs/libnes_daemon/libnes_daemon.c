/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file libnes_daemon.c
* @brief Implementation of nes library for application daemonization
*/
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <syslog.h>
#include <string.h>

#include "libnes_daemon.h"

static int pid_file;

#define PID_STR_LEN 10

static int
open_pid_file(void)
{
    char pid_str[PID_STR_LEN];
    pid_file = open(PID_FILE_PATH, O_RDWR|O_CREAT, 0600);
    if (pid_file == -1) {
            daemon_log("Unable to open PID file");
            return -1;
    }

    if (lockf(pid_file, F_TLOCK, 0) == -1) {
            daemon_log("Unable to lock PID file");
            return -1;
    }

    snprintf(pid_str,PID_STR_LEN, "%d\n", getpid());
    write(pid_file, pid_str, strlen(pid_str));
    return 0;
}

int
daemonize(void) 
{
    pid_t fpid;
    int dev_null_file;

    openlog(DAEMON_NAME, LOG_PID, LOG_DAEMON);
    fpid = fork();
    if (fpid < 0) {
            daemon_log("Unable to fork first process");
            return -1;
    }
    if (fpid > 0)
            exit(EXIT_SUCCESS);

    if (setsid() < 0) {
            daemon_log("Unable to set session id");
            return -1;
    }

    fpid = fork();	
    if (fpid < 0) {
            daemon_log("Unable to fork second process");
            return -1;
    }

    if (fpid > 0)
            exit(EXIT_SUCCESS);

    umask(0);
    if (chdir(DAEMON_WORKING_DIR) < 0) {
            daemon_log("Unable to change directory to "DAEMON_WORKING_DIR);
            return -1;
    }

    dev_null_file = open("/dev/null", O_RDWR);
    if (dev_null_file == -1)  {
            daemon_log("Unable to open /dev/null for stream redirection");
            return -1;
    }

    dup2(dev_null_file, STDIN_FILENO);	
    dup2(dev_null_file, STDOUT_FILENO);
    dup2(dev_null_file, STDERR_FILENO);
    close(dev_null_file);

    return open_pid_file();
}

void 
daemon_log(const char* msg)
{
    syslog(LOG_INFO, "%s", msg);
}

void
daemon_cleanup(void)
{
    close(pid_file);
    closelog();
}
