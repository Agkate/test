#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

export SAMPLE_PATH_1="${DST_SAMPLES_DIR}/shadow_pub"
export SCRIPT_NAME_1="shadow_publish.py"
export DEVICE_ID_1=${GG_SHADOW_SUB_NAME}
export CLIENT_ID_1=${GG_SHADOW_PUB_NAME}

export SAMPLE_PATH_2="${DST_SAMPLES_DIR}/shadow_sub"
export SCRIPT_NAME_2="shadow_subscribe.py"
export DEVICE_ID_2=${GG_SHADOW_SUB_NAME}
export CLIENT_ID_2=${GG_SHADOW_SUB_NAME}

export ROUTE_ADD_PATH="${DST_SAMPLES_DIR}/route_config"
export ROUTE_ADD_NAME="route_config.py"
export ROUTE_ADD_DEVICE_ID=${GG_HELLO_PUB_NAME}
export ROUTE_ADD_TOPIC="mec/route/trigger"
export ROUTE_ADD_MODE="--subscribe --publish"
export ROUTE_ADD_ACTION="add"

. functions.sh

export KEY_1=$(get_key_prefix "${CLIENT_ID_1}")
export KEY_2=$(get_key_prefix "${DEVICE_ID_2}")
export ROUTE_ADD_KEY=$(get_key_prefix "${ROUTE_ADD_DEVICE_ID}")

# remove old cert and keys
exec_on_remote "${DEV1_IP}" "${DEV1_USER}" "rm -rf ${SAMPLE_PATH_1}/*cert.pem ${SAMPLE_PATH_1}/*.key"
exec_on_remote "${DEV2_IP}" "${DEV2_USER}" "rm -rf ${SAMPLE_PATH_2}/*cert.pem ${SAMPLE_PATH_2}/*.key"
exec_on_remote "${DEV1_IP}" "${DEV1_USER}" "rm -rf ${ROUTE_ADD_PATH}/*cert.pem ${ROUTE_ADD_PATH}/*.key"

# copy new cert and keys
copy_to_remote "${CLIENT_ID_1}/*" "${DEV1_IP}" "${DEV1_USER}" "${SAMPLE_PATH_1}"
copy_to_remote "${DEVICE_ID_2}/*" "${DEV2_IP}" "${DEV2_USER}" "${SAMPLE_PATH_2}"
copy_to_remote "${ROUTE_ADD_DEVICE_ID}/*" "${DEV1_IP}" "${DEV1_USER}" "${ROUTE_ADD_PATH}"

echo "Running TC_6:"
./tc_6/dev_1.sh &
DEV1_PID=$!
./tc_6/dev_2.sh || exit 1
wait ${DEV1_PID} || exit 1
