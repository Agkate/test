/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  ServiceDataManager.cpp
* @brief Mobile Edge Service Data Update and Publication
*/

#include "ServiceDataManager.h"
#include "SessionManager.h"
#include "ServiceManager.h"
#include "Exception.h"
#include "HandlerCommon.h"
#include "Log.h"
#include "DbManager.h"
#include <sstream>
#include "RawRequest.h"
#include "WebSocketServer.h"

/**
 * @brief       Publishes service data to subscribers.
 * @param[in]   serviceId      Service ID.
 * @param[in]   serviceData    Data structure used for data update and 
 *                             publication.
 * @return       void
 */
static void publishServiceData(string serviceId, Json::Value serviceData);

/**
 * @brief       Creates a data key to store the service data.
 * @param[out]  dataKeys    A key that identifies a service data entry in
 *                          database
 * @param[in]   serviceId   Service ID.
 * @param[in]   keyfields   Data structure in service data.
 * @return      void
 */
static void createDataKeysForUpdate(string &dataKeys, string serviceId,
                                    Json::Value keyfields);

/**
 * @brief       Checks whether a service ID exists and belongs to the ME App.
 * @param[out]  isFound     Indication of whether a serviceId is found.
 * @param[in]   token       ME App's token (reference ID).
 * @param[in]   serviceId   Service ID.
 * @return      void
 */
static void checkServiceId(bool &isFound, string serviceId, string token);

/**
 * @brief       Creates service data based on dataSchema.
 * @param[in]   serviceId       Service ID.
 * @param[in]   serviceData     Data structure used for data update and 
 *                              publication.
 * @return      void
 */
static bool checkServiceBasedSchema(string serviceId, Json::Value serviceData);

void ServiceDataUpdate::execute(Json::Value &request, Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    try {
        // Check cookies.
        string token;
        SessionManager::checkSession(cookies, token);

        // Check service.
        string serviceId = request.get("serviceId","Nil").asString();
        if (0 == serviceId.compare("Nil")) {
            MECFCGI_LOG(ERR,"Service Id is invalid.\n");
            throw Exception(Exception::INVALID_SERVICEID);
        }
        //Check serviceId's existence.
        bool isFound = false;
        checkServiceId(isFound, serviceId, token);
        if (!isFound) {
            MECFCGI_LOG(ERR, "Service does not exist.\n");
            throw Exception(Exception::SERVICE_NOT_EXIST);
        }

        Json::Value serviceData = request.get("serviceData","Nil");
        if (0 == serviceData.compare("Nil")) {
            MECFCGI_LOG(ERR,"Service data does not exist.\n");
            throw Exception(Exception::SERVICE_DATA_NOT_EXIST);
        }

        Json::Value keyfields = serviceData.get ("keyFields","Nil");
        Json::Value data = serviceData.get ("data","Nil");
        if (0 == data.compare("Nil")) {
            MECFCGI_LOG(ERR,"Update data does not exist.\n");
            throw Exception(Exception::UPDATE_DATA_NOT_EXIST);
        }

        string serviceType;
        DbManager::getActivatedServiceServiceType(serviceId, serviceType);
        if (0 == serviceType.compare(ME_SERVICE_TYPE_3)) {
            MECFCGI_LOG(ERR,
                "The service type is not supported in this operation.\n");
            throw Exception(Exception::UNSUPPORTED_SERVICE_TYPE);
        }

        // Check service data according to data schema.
        if(!checkServiceBasedSchema(serviceId, serviceData)) {
            throw Exception(Exception::INVALID_SERVICE_DATA);
        }

        // Save data to Database.
        // If the service type is type-1 or type-4, the data will be stored in
        // the database,  if it is type-2, then it will be directly published
        // to the ME Apps.
        if (0 == serviceType.compare(ME_SERVICE_TYPE_1) ||
            0 == serviceType.compare(ME_SERVICE_TYPE_4)) {
            //Create keys.
            //E.g:
            //ServiceId:cellid<12>enbUeId<12>enodeid<12>
            string dataKeys = "";
            createDataKeysForUpdate(dataKeys, serviceId, keyfields);
            Json::FastWriter writer;
            string sData = writer.write(data);
            string dataOrg;
            DbManager::getServiceData(dataKeys, dataOrg);
            if (0 != dataOrg.compare(sData)) {
                DbManager::saveServiceData(dataKeys, sData);
            }
        }

        publishServiceData(serviceId, serviceData);

        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void publishServiceData(string serviceId, Json::Value serviceData)
{
    Json::Value message;
    message["id"] = "Update";
    message["data"] = serviceData;
    Json::FastWriter writer;
    string sMessage = writer.write(message);
    // Push service data to subscribers.
    DbManager::StringArrayType subscriberList;
    DbManager::getSubscriberByServiceId(subscriberList, serviceId);
    for (string &subscriber_ : subscriberList) {
        string subscriberToken;
        istringstream ssSubscriber(subscriber_);
        // MEASS:token:serviceId
        getline(ssSubscriber, subscriberToken, SPLIT_MARK);     //MEASS
        getline(ssSubscriber, subscriberToken, SPLIT_MARK);     //token
        getWebServer()->pushData(subscriberToken, "Update", sMessage);
    }
}

void createDataKeysForUpdate(string &dataKeys, string serviceId,
                             Json::Value keyfields)
{
    dataKeys = serviceId;;
    if (0 != keyfields.compare("Nil")) {
        dataKeys += SPLIT_MARK;
        Json::Value::Members keyfieldMembers = keyfields.getMemberNames();
        for (Json::Value::Members::iterator iter = keyfieldMembers.begin();
             iter != keyfieldMembers.end(); iter++) {
            string fieldName = *iter;
            uint32_t fieldValue = keyfields[fieldName].asUInt();
            stringstream ssFieldValue;
            ssFieldValue << fieldValue;
            dataKeys += fieldName + SPLIT_MARKL + ssFieldValue.str() +
                SPLIT_MARKR;
        }
    }
}

void checkServiceId(bool &isFound, string serviceId, string token)
{
    isFound = false;
    string activatedServiceToken = "";
    DbManager::getActivatedServiceToken(serviceId, activatedServiceToken);
    if (0 == activatedServiceToken.compare(token)){
        isFound = true;
    }
}

static bool checkIntegerData(string memberName, Json::Value data,
                             Json::Value schema)
{
    if (Json::intValue != data[memberName].type()) {
        MECFCGI_LOG(ERR, "Member %s is of wrong type, it should be an integer.",
            memberName.c_str());
        return false;
    }
    if (schema["properties"][memberName].isMember("minimum")) {
        int minValue = schema["properties"][memberName]["minimum"].asInt();
        int value = data[memberName].asInt();
        if (value < minValue) {
            MECFCGI_LOG(ERR,
                "Member %s's value(%d) does not reach minValue(%d).",
                memberName.c_str(), value, minValue);
            return false;
        }
    }
    if (schema["properties"][memberName].isMember("maximum")) {
        int maxValue = schema["properties"][memberName]["maximum"].asInt();
        int value = data[memberName].asInt();
        if (value > maxValue) {
            MECFCGI_LOG(ERR, "Member %s's value(%d) exceeds maxValue(%d).",
                memberName.c_str(), value, maxValue);
            return false;
        }
    }
    return true;
}

static bool checkMemberBasedSchema(Json::Value data, Json::Value schema)
{
    int schemaSize = 0;
    int dataSize = data.size();
    Json::Value::Members dataMember = schema["properties"].getMemberNames();
    for(Json::Value::Members::iterator iter = dataMember.begin();
        iter!=dataMember.end(); ++iter) {
        string memberName = *iter;
        schemaSize++;
        string dataType = schema["properties"][memberName]["type"].asString();
        if(data.isMember(memberName)){
            if(0 == dataType.compare("integer")){
                if(!checkIntegerData(memberName, data, schema)) {
                    return false;
                }
            } else if(0 == dataType.compare("string")){
                if (Json::stringValue != data[memberName].type()) {
                    MECFCGI_LOG(ERR,
                    "Member %s is of wrong data type, it should be a string.",
                    memberName.c_str());
                    return false;
                }
            } else if(0 == dataType.compare("object")){
                if (Json::objectValue != data[memberName].type()) {
                    MECFCGI_LOG(ERR,
                    "Member %s is of wrong data type, it should be a object.",
                    memberName.c_str());
                    return false;
                }
            }
        } else {
            MECFCGI_LOG(ERR, "Member %s is missing from data of serviceData.",
                memberName.c_str());
            return false;
        }
    }
    if(schemaSize != dataSize){
        MECFCGI_LOG(ERR,
        "One or more members in data are not specified in schema.");
        return false;
    }
    return true;
}

bool checkServiceBasedSchema(string serviceId, Json::Value serviceData)
{
    string dataSchemaCvt;
    DbManager::getActivatedServiceDataSchemaCvt(serviceId, dataSchemaCvt);

    Json::Reader reader;
    Json::Value serviceDataSchema;
    reader.parse(dataSchemaCvt, serviceDataSchema);

    Json::Value keyFields, data, keyFieldsSchema, dataSchema;
    keyFields = serviceData["keyFields"];
    data = serviceData["data"];
    keyFieldsSchema = serviceDataSchema["properties"]["keyFields"];
    dataSchema = serviceDataSchema["properties"]["data"];

    bool ret;
    ret = checkMemberBasedSchema(keyFields, keyFieldsSchema);
    if (!ret) {
        MECFCGI_LOG(ERR, "Service keyFields is invalid.");
        return ret;
    }
    ret = checkMemberBasedSchema(data, dataSchema);
    if (!ret) {
        MECFCGI_LOG(ERR, "Service data is invalid.");
        return ret;
    }
    return ret;
}
