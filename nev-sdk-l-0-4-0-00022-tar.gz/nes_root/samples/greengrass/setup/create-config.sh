#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

set -e

# checking if "jq" package is installed
type jq > /dev/null 2>&1 || \
{
    echo "No \"jq\" package found"
    echo "Try to install with \"yum install jq\" command"
    exit
}

BASE_DIR=$(pwd)
CONFIG_FILE="config.json"
GGC_DEPLOYMENT=$(jq -r ".ProjectName" ${CONFIG_FILE})
LAMBDA_NAME=$(jq -r ".Lambda.Name" ${CONFIG_FILE})
LAMBDA_FILENAME=$(jq -r ".Lambda.Package" ${CONFIG_FILE})
RESOURCE_NAME=$(jq -r ".Resource.Name" ${CONFIG_FILE})
RESOURCE_PATH=$(jq -r ".Resource.Path" ${CONFIG_FILE})

IOTHOST=`aws iot describe-endpoint | jq -r ".endpointAddress"`
GGREGION=`aws configure get region`

#$1 Name
#$2 Name of variable in which Thing JSON will be stored
#$3 Name of variable in which cert JSON will be stored
function create_thing_cert_policy()
{
    local POLICY_NAME=${1}-Policy
    local THING_JSON=$(aws iot create-thing --thing-name "${1}")
    eval "$2='${THING_JSON}'"
    # create GGC certificates
    local CERT_JSON=$(aws iot create-keys-and-certificate --set-as-active)
    eval "$3='${CERT_JSON}'"
    local CERT_ARN=$(echo ${CERT_JSON} | jq -r ".certificateArn")

    # remove previous thing directory
    rm -rf ${1}
    mkdir -p ${1}

    # copy new keys and certificate
    echo ${CERT_JSON} | jq -r ".certificatePem" > ${1}/${1}.cert.pem
    echo ${CERT_JSON} | jq -r ".keyPair.PrivateKey" > ${1}/${1}.private.key
    echo ${CERT_JSON} | jq -r ".keyPair.PublicKey" > ${1}/${1}.public.key

    # create a policy with permissions for the thing
    local POLICY_JSON=$(aws iot create-policy --policy-name "${POLICY_NAME}" \
        --policy-document "{ \"Version\": \"2012-10-17\", \
            \"Statement\": \
            [{ \
                \"Effect\":\"Allow\", \
                \"Action\": [ \
                    \"iot:Publish\", \
                    \"iot:Subscribe\", \
                    \"iot:Connect\", \
                    \"iot:Receive\", \
                    \"greengrass:*\" \
                ], \
                \"Resource\":\"*\" \
            }]}")

    # attach policy to certificate
    aws iot attach-principal-policy --policy-name ${POLICY_NAME} --principal ${CERT_ARN}

    # attach the certificate to the thing
    aws iot attach-thing-principal --thing-name ${1} --principal ${CERT_ARN}

    # get root-ca.pem certificate
    wget https://www.symantec.com/content/en/us/enterprise/verisign/roots/VeriSign-Class%203-Public-Primary-Certification-Authority-G5.pem -O ${1}/root-ca.pem > /dev/null 2>&1

    echo "AWS thing \"${1}\" created"
}

#$1 Name of device
#$2 SyncShadow
#$3 JSON content from previously created device (empty string if this is the first device)
#$4 Name of variable in which device description JSON will be stored
function create_new_device()
{
    local GGC_DEV_THING=""
    local GGC_DEV_CERT=""
    create_thing_cert_policy "$1" GGC_DEV_THING GGC_DEV_CERT
    GGC_DEV_THING_ARN=$(echo ${GGC_DEV_THING} | jq -r ".thingArn" )
    GGC_DEV_CERT_ARN=$(echo ${GGC_DEV_CERT} | jq -r ".certificateArn" )

    if [ -z "${3}" ]; then
        JSON="["
    else
        JSON="${3%]*},"
    fi
    eval "$4='${JSON}{\
        \"CertificateArn\": \"${GGC_DEV_CERT_ARN}\", \
        \"Id\": \"${1}-1\", \
        \"SyncShadow\": ${2}, \
        \"ThingArn\": \"${GGC_DEV_THING_ARN}\" }]'"
}

#$1 Projectname
#$2 JSON with devices description
#$3 Name of variable in which device definition version ARN will be stored
function create_device_definition()
{
    # create a devices definition
    local GGC_DEV_DEF=$(aws greengrass create-device-definition --name "$1-devices")
    local GGC_DEV_DEF_ID=$(echo ${GGC_DEV_DEF} | jq -r ".Id")
    GGC_DEV_DEF_VER=$(aws greengrass create-device-definition-version \
        --device-definition-id ${GGC_DEV_DEF_ID} \
        --devices "${2}")
    GGC_DEV_DEF_VER_ARN=$(echo ${GGC_DEV_DEF_VER} | jq -r ".Arn")
    eval "$3='${GGC_DEV_DEF_VER_ARN}'"
}


#$1 subject
#$2 Type of the source object (cloud, device, lambda, shadow)
#$3 Name of the source object
#$4 Type of the destination object (cloud, device, lambda, shadow)
#$5 Name of the destination object
#$6 JSON content from previously created subscription (empty string if this is the first subscription)
#$7 Name of variable in which subscription description JSON will be stored
function create_new_subscription()
{
    local JSON=""
    local SRC_ARN=""
    local DST_ARN=""
    if [ "${2}" == "lambda" ]; then
        SRC_ARN=$(aws lambda get-alias --function-name "${3%-alias*}" --name "${3}" | jq -r ".AliasArn")
    elif [ "${2}" == "device" ]; then
        SRC_ARN=$(aws iot describe-thing --thing-name "$3" | jq -r ".thingArn")
    elif [ "${2}" == "cloud" ]; then
        SRC_ARN="cloud"
    elif [ "${2}" == "shadow" ]; then
        SRC_ARN="GGShadowService"
    fi
    if [ "${4}" == "lambda" ]; then
        DST_ARN=$(aws lambda get-alias --function-name "${5%-alias*}" --name "${5}" | jq -r ".AliasArn")
    elif [ "${4}" == "device" ]; then
        DST_ARN=$(aws iot describe-thing --thing-name "$5" | jq -r ".thingArn")
    elif [ "${4}" == "cloud" ]; then
        DST_ARN="cloud"
    elif [ "${4}" == "shadow" ]; then
        DST_ARN="GGShadowService"
    fi
    if [ -z "${6}" ]; then
        JSON="["
    else
        JSON="${6%]*},"
    fi

    eval "$7='${JSON}{\
        \"Id\": \"${8}\", \
        \"Source\": \"${SRC_ARN}\", \
        \"Subject\": \"${1}\", \
        \"Target\": \"${DST_ARN}\" }]'"
}

set -e

GGC_CORE_NAME=${GGC_DEPLOYMENT}-Core

# create GG group
GGC_GROUP_JSON=$(aws greengrass create-group --name "${GGC_DEPLOYMENT}-Group")
echo "AWS Group \"${GGC_DEPLOYMENT}-Group\" created"

GGC_GROUPID=$(echo ${GGC_GROUP_JSON} | jq -r ".Id")
GGC_GROUPARN=$(echo ${GGC_GROUP_JSON} | jq -r ".Arn")
GGC_GROUPNAME=$(echo ${GGC_GROUP_JSON} | jq -r ".Name")

# create GG thing, keys and certificate
create_thing_cert_policy "${GGC_CORE_NAME}" GGC_THING GGC_CERT

GGC_CERT_ARN=$(echo ${GGC_CERT} | jq -r ".certificateArn" )
GGC_THING_ARN=$(echo ${GGC_THING} | jq -r ".thingArn" )

# create GG Core configuration file
echo "{
    \"coreThing\": {
        \"caPath\": \"root-ca.pem\",
        \"certPath\": \"${GGC_CORE_NAME}.cert.pem\",
        \"keyPath\": \"${GGC_CORE_NAME}.private.key\",
        \"thingArn\": \"${GGC_THING_ARN}\",
        \"iotHost\": \"${IOTHOST}\",
        \"ggHost\": \"greengrass.iot.${GGREGION}.amazonaws.com\",
        \"keepAlive\": 600
    },
    \"runtime\": {
        \"cgroup\": {
                \"useSystemd\": \"no\"
        }
    }
}" > ${GGC_CORE_NAME}/config.json

GGC_DEF_JSON=$(aws greengrass create-core-definition --name "${GGC_CORE_NAME}")
GGC_COREID=$(echo ${GGC_DEF_JSON} | jq -r ".Id")


GGC_DEF_VER_JSON=$(aws greengrass create-core-definition-version \
    --core-definition-id "${GGC_COREID}" \
    --cores "[{ \"CertificateArn\": \"${GGC_CERT_ARN}\", \
        \"Id\": \"${GGC_DEPLOYMENT}-1\", \
        \"SyncShadow\": true, \
        \"ThingArn\": \"${GGC_THING_ARN}\" }]")
GGC_COREVERSION=$(echo ${GGC_DEF_VER_JSON} | jq -r ".Arn")
echo "AWS GG Core \"${GGC_CORE_NAME}\" created"

# create a resource
GGC_RES_DEF=$(aws greengrass create-resource-definition --name "${RESOURCE_NAME}")
GGC_RES_ID=$(echo ${GGC_RES_DEF} | jq -r ".Id")

GGC_RES_DEF_VER=$(aws greengrass create-resource-definition-version --resource-definition-id "${GGC_RES_ID}" \
    --resources "[{ \"Id\": \"data-volume\", \
        \"Name\": \"${RESOURCE_NAME}\", \
        \"ResourceDataContainer\": { \
            \"LocalVolumeResourceData\": { \
                \"SourcePath\": \"${RESOURCE_PATH}\", \
                \"DestinationPath\": \"${RESOURCE_PATH}\", \
                \"GroupOwnerSetting\": { \
                    \"AutoAddGroupOwner\": true, \
                    \"GroupOwner\": \"\" \
                } \
            } \
        } \
}]")
GGC_RES_DEF_VER_ARN=$(echo ${GGC_RES_DEF_VER} | jq -r ".Arn")
echo "AWS resource for Lambda function created"

# create Lambda function
GGC_ROLELAMBDA=$(aws iam list-roles | jq -r '.Roles[] | select (..|.Service? | contains("lambda")?) | .Arn' | head -1)
[ -z "${GGC_ROLELAMBDA}" ] && ( echo "STOP: you must create a role that can be used by lambda functions."; return 1 )

GGC_LAMBDA_JSON=$(aws lambda create-function \
    --region ${GGREGION} \
    --function-name ${LAMBDA_NAME} \
    --zip-file fileb://${LAMBDA_FILENAME} \
    --role ${GGC_ROLELAMBDA} \
    --handler mec_route.function_handler \
    --runtime python2.7)

GGC_LAMBDA_ARN=$(echo ${GGC_LAMBDA_JSON} | jq -r ".FunctionArn")

# publish new version of Lambda function and create an alias
GGC_LAMBDA_PUB_VER=$(aws lambda publish-version --function-name ${GGC_LAMBDA_ARN})
GGC_LAMBDA_HWVERSNAME=$(echo ${GGC_LAMBDA_PUB_VER} | jq -r ".FunctionName")
GGC_LAMBDA_HWVERSION=$(echo ${GGC_LAMBDA_PUB_VER} | jq -r ".Version")

GGC_LAMBDA_ALIAS_JSON=$(aws lambda create-alias \
    --function-name ${GGC_LAMBDA_HWVERSNAME} \
    --name ${LAMBDA_NAME}-alias \
    --function-version ${GGC_LAMBDA_HWVERSION})
GGC_LAMBDA_ALIAS_ARN=$(echo ${GGC_LAMBDA_ALIAS_JSON} | jq -r ".AliasArn")

# create lambda version
GGC_LAMBDA_HANDLER=$(aws lambda get-function --function-name ${GGC_LAMBDA_ARN} | jq -r ".Configuration.Handler")
GGC_LAMBDA_DEF=$(aws greengrass create-function-definition --name "${LAMBDA_NAME}")
GGC_LAMBDA_ID=$(echo ${GGC_LAMBDA_DEF} | jq -r ".Id")

GGC_LAMBDA_DEF_VER=$(aws greengrass create-function-definition-version \
    --function-definition-id "${GGC_LAMBDA_ID}" \
    --functions "[{ \"Id\": \"uptime-lambda\", \
        \"FunctionArn\": \"${GGC_LAMBDA_ALIAS_ARN}\", \
        \"FunctionConfiguration\": { \
            \"Environment\": { \
                \"AccessSysfs\": false, \
                \"ResourceAccessPolicies\": [ \
                { \
                    \"Permission\": \"ro\", \
                    \"ResourceId\": \"data-volume\" \
                }] \
            }, \
            \"MemorySize\": 32768, \
            \"Pinned\": false, \
            \"Timeout\": 3 \
        } \
}]")
GGC_LAMBDA_DEF_VER_ARN=$(echo ${GGC_LAMBDA_DEF_VER} | jq -r ".Arn")
echo "AWS Lambda function \"${LAMBDA_NAME}\" created"

# create devices
DEVICES_JSON=""
while read -r line;
    do
        eval "$line"
        create_new_device "${name}" "${sync}" "${DEVICES_JSON}" DEVICES_JSON
    done < <(jq -r '.Devices[] | @sh "name=\(.Name) sync=\(.SyncShadow)"' ${CONFIG_FILE})

create_device_definition "${GGC_DEPLOYMENT}" "${DEVICES_JSON}" GGC_DEV_DEF_VER_ARN
echo "AWS GG devices created"

# create subscriptions
GGC_SUB_DEF=$(aws greengrass create-subscription-definition --name "${GGC_DEPLOYMENT}-Sub")
GGC_SUB_DEF_ID=$(echo ${GGC_SUB_DEF} | jq -r ".Id")

SUBS_JSON=""
SUB_ID=0
while read -r line;
    do
        eval "$line"
        let SUB_ID=SUB_ID+1
        create_new_subscription "${subject}" "${srcobj}" "${src}" "${dstobj}" "${dst}" "${SUBS_JSON}" SUBS_JSON "${SUB_ID}"
    done < <(jq -r '.Subscriptions[] | @sh "subject=\(.Subject) srcobj=\(.SrcObj) src=\(.Src) dstobj=\(.DstObj) dst=\(.Dst)"' ${CONFIG_FILE})

GGC_SUB_DEF_VER=$(aws greengrass create-subscription-definition-version \
    --subscription-definition-id "${GGC_SUB_DEF_ID}" \
    --subscriptions "${SUBS_JSON}")
GGC_SUB_DEF_VER_ARN=$(echo ${GGC_SUB_DEF_VER} | jq -r ".Arn")
echo "AWS GG Subscriptions created"

GGC_GROUP_VERSION=$(aws greengrass create-group-version --group-id "${GGC_GROUPID}" \
    --core-definition-version-arn "${GGC_COREVERSION}" \
    --function-definition-version-arn "${GGC_LAMBDA_DEF_VER_ARN}" \
    --resource-definition-version-arn "${GGC_RES_DEF_VER_ARN}" \
    --subscription-definition-version-arn "${GGC_SUB_DEF_VER_ARN}" \
    --device-definition-version-arn "${GGC_DEV_DEF_VER_ARN}")
echo "AWS GG group updated"
GGC_GROUPIDVERSION=$(echo $GGC_GROUP_VERSION | jq -r ".Version")

echo "All files needed to run GG core are in directory: \"${GGC_CORE_NAME}\""
echo "Copy \"${GGC_CORE_NAME}.cert.pem\", \"${GGC_CORE_NAME}.private.key\" and \"root_ca.pem\" from directory \"${GGC_CORE_NAME}\" to \"greengrass/certs\" directory"
echo "Copy \"config.json\" from directory \"${GGC_CORE_NAME}\" to \"greengrass/config\" directory"
echo "Now restart greengrass core"
echo "To get create a deployment run:"
echo "aws greengrass create-deployment --deployment-type NewDeployment --group-id \"${GGC_GROUPID}\" --group-version-id \"${GGC_GROUPIDVERSION}\""

# Below is an example how to do deployment using AWSCLI
#aws greengrass create-deployment --deployment-type NewDeployment \
#       --group-id "${GGC_GROUPID}" --group-version-id "${GGC_GROUPIDVERSION}" > tmp-ggc-deployment.json
#GGC_DEPLOYID=`jq -r ".DeploymentId" tmp-ggc-deployment.json`
#sleep 2
#watch -n 1 aws greengrass get-deployment-status --deployment-id "${GGC_DEPLOYID}" --group-id "${GGC_GROUPID}"
