/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file Exception.cpp
 * @brief Implementation of Redis
*/

#include "Redis.h"
#include "Exception.h"
#include "Log.h"
int Redis::connectionPoolTop = 0;
redisContext *Redis::redis[REDIS_MAX_CONNECTION_POOL] = {};
boost::mutex Redis::mutex;
Redis::redis_info_t Redis::redisInfo;


Redis::Redis()
{
    boost::mutex::scoped_lock scoped_lock(mutex);
    if (connectionPoolTop >= REDIS_MAX_CONNECTION_POOL) {
        MECFCGI_LOG(ERR, "Redis connection pool exhausted, connectionPoolTop = %d.\n", connectionPoolTop);
        throw Exception(Exception::REDIS_CONNECTIONPOOL, "Redis connection pool exhausted");
    }

    if (!redis[connectionPoolTop] || ! (redis[connectionPoolTop]->flags & REDIS_CONNECTED)) {
        redis[connectionPoolTop] = redisConnect(redisInfo.redis_ip.c_str(), redisInfo.redis_port);
        if (redis[connectionPoolTop]->err) {
            MECFCGI_LOG(ERR, "Cannot connect to database.\n");
            throw Exception(Exception::REDIS_CONNECT_FAILD, "Cannot connect to database");
        }
    }

    if (HAS_PASSWORD == redisInfo.redis_haspassword) {
        redisReply *reply = (redisReply *)redisCommand(redis[connectionPoolTop], "AUTH %s", redisInfo.redis_password.c_str());
        if (NULL == reply) {
            MECFCGI_LOG(ERR, "Pointer(reply) is NULL.\n");
            throw Exception(Exception::REDIS_CONNECT_FAILD, "Authentication failed");
        }
        if (REDIS_REPLY_ERROR == reply->type) {
            MECFCGI_LOG(ERR, "Authentication failed.\n");
            throw Exception(Exception::REDIS_CONNECT_FAILD, "Authentication failed");
        }

        freeReplyObject(reply);
    }

    connectionIndex = connectionPoolTop;
    ++connectionPoolTop;
}

Redis::~Redis()
{
    boost::mutex::scoped_lock scoped_lock(mutex);
    if (connectionPoolTop <= 0) {
        MECFCGI_LOG(ERR, "Redis connection pool has BUG.\n");
        throw Exception(Exception::REDIS_CONNECTIONPOOL, "Redis connection pool has BUG");
    }
    --connectionPoolTop;
}

void Redis::checkReply(redisReply *reply, int type)
{
    if (!reply) {
        MECFCGI_LOG(ERR, "Redis no reply returned.\n");
        throw Exception(Exception::REDIS_NO_REPLY, "Redis no reply returned");
    } else if (REDIS_REPLY_ERROR == reply->type) {
        MECFCGI_LOG(ERR, "REDIS_REPLY_ERROR, reply->str: %s.\n", reply->str);
        throw Exception(Exception::REDIS_COMMAND_ERROR, reply->str);
    } else if (REDIS_REPLY_NIL == reply->type) {
        throw Exception(Exception::REDIS_NO_RESULT, "No result returned by database");
    } else if (reply->type != type) {
        MECFCGI_LOG(ERR, "Reply type mismatch, reply->type: %d.\n", reply->type);
        throw Exception(Exception::REDIS_TYPE_MISMATCH, "Reply type mismatch");
    }
}

void Redis::asString(string &res, const string command, ...)
{
    va_list args;
    va_start (args, command);
    redisReply *reply = (redisReply *) redisvCommand(redis[connectionIndex], command.c_str(), args);
    va_end (args);
    try {
        checkReply(reply, REDIS_REPLY_STRING);
    }
    catch (Exception &e) {
        freeReplyObject(reply);
        throw;
    }
    res = reply->str;
    freeReplyObject(reply);
}

void Redis::asInt(int &res, const string command, ...)
{
    va_list args;
    va_start (args, command);
    redisReply *reply = (redisReply *) redisvCommand(redis[connectionIndex], command.c_str(), args);
    va_end (args);
    try {
        checkReply(reply, REDIS_REPLY_INTEGER);
    }
    catch (Exception &e) {
        freeReplyObject(reply);
        throw;
    }
    res = static_cast<int> (reply->integer);
    freeReplyObject(reply);
}

void Redis::asStatus(string &res, const string command, ...)
{
    va_list args;
    va_start (args, command);
    redisReply *reply = (redisReply *) redisvCommand(redis[connectionIndex], command.c_str(), args);
    va_end (args);
    try {
        checkReply(reply, REDIS_REPLY_STATUS);
    }
    catch (Exception &e) {
        freeReplyObject(reply);
        throw;
    }
    res = reply->str;
    freeReplyObject(reply);
}

void Redis::asArray(StringArrayType &array, const string command, ...)
{
    va_list args;
    va_start (args, command);
    redisReply *reply = (redisReply *) redisvCommand(redis[connectionIndex], command.c_str(), args);
    va_end (args);
    try {
        checkReply(reply, REDIS_REPLY_ARRAY);
        for (size_t i = 0; i < reply->elements; i++) {
            switch (reply->element[i]->type) {
            case REDIS_REPLY_STRING:
                array.push_back(reply->element[i]->str);
                break;
            default:
                MECFCGI_LOG(ERR, "Array element type mismatch, reply->element[%lu]->type: %d.\n", i, reply->element[i]->type);
                throw Exception(Exception::REDIS_ARRAY_ELE_TYPE_MISMATCH, "Array element type mismatch");
            }
        }
    }
    catch (Exception &e) {
        freeReplyObject(reply);
        throw;
    }
    freeReplyObject(reply);
}

void Redis::setRedisInfo(string redis_ip, uint16_t redis_port, string redis_password)
{
    redisInfo.redis_ip = redis_ip;
    redisInfo.redis_port = redis_port;
    redisInfo.redis_password = redis_password;
    if (0 == redis_password.compare("")){
        redisInfo.redis_haspassword = NOT_HAS_PASSWORD;
    } else {
        redisInfo.redis_haspassword = HAS_PASSWORD;
    }
}
