/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file nes_dns_config.h
 * @brief Header file for nes_dns_config
 */

#ifndef NES_DNS_CONFIG_H
#define	NES_DNS_CONFIG_H

#ifdef	__cplusplus
extern "C" {
#endif

#define DNS_AGENT_SECTION "DNS"
#define DNS_AGENT_TAP_DEV_NAME "dns_agent_tap"    

enum {
    DNS_FORWARD_OFF,
    DNS_FORWARD_ON
};
/**
 * @brief Get local dns tap device mac address from config file
 *
 * @param[in] mac_entry - entry in config file, DNS_AGENT_SECTION section
 * @param[out] mac - mac address from config file
 * @return NES_SUCCESS on success and NES_FAIL on fail.
 */
int nes_dns_mac_from_cfg(const char *mac_entry, struct ether_addr *mac);

/**
 * @brief Get ip address from config file, DNS_AGENT_SECTION section
 *
 * @param[in] ip_entry - entry in config file DNS_AGENT_SECTION section
 * @param[out] ip - ip address from config file
 * @return NES_SUCCESS on success and NES_FAIL on fail.
 */
int nes_dns_ip_from_cfg(const char *ip_entry, uint32_t *ip) ;

/**
 * @brief Set up dns tap device
 *
 * @param[in] name - tap device name
 * @param[in] mac_addr - tap device mac address
 * @param[in] ip_addr - tap device ip address
 * @param[in] non_block - if set read from tap device is going to be non-blocking
 * @return NES_SUCCESS on success and NES_FAIL on fail.
 */
int nes_dns_tap_create(const char* name, struct ether_addr *mac_addr, uint32_t *ip_addr, uint8_t non_block);

/**
 * @brief Check if forwarding of unresolved queries is turned on in config file
 *
 * @param[in] forward_unresolved_entry - entry in config file DNS_AGENT_SECTION section
 * @param[out] forward - set to 1 if forwarding is on
 * @return NES_SUCCESS on success and NES_FAIL on fail.
 */
int nes_dns_check_forward_unresolved(const char *forward_unresolved_entry, uint8_t *forward);

#ifdef	__cplusplus
}
#endif

#endif	/* NES_DNS_CONFIG_H */

