/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/

/**
 * @file libnes_cfgfile.h
 * @brief Header file for libnes_cfgfile
 */
#ifndef _LIBNES_CFGFILE_H_
#define _LIBNES_CFGFILE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "rte_cfgfile.h"
#include <rte_string_fns.h>

#define CFG_FILE_VALUE_LEN CFG_VALUE_LEN
#define CFG_FILE_NAME_LEN CFG_NAME_LEN
#define NES_MAX_LOOKUP_ENTRY_LEN 220
#define MAX_LOOKUP_ENTRIES 10

struct cfg_lookup_entry {
    char name[CFG_FILE_NAME_LEN];
    char value[CFG_FILE_VALUE_LEN];
};

/**
 * @brief Load configuration file content
 *
 * @param[in] filename - configuration file path
 * @return NES_SUCCESS on success and NES_FAIL on fail
 */
int nes_cfgfile_load(char *filename);

/**
 * @brief Get configuration entry
 *
 * @param[in] section - configuration section
 * @param[in] entry - configuration field
 * @param[out] value - configuration field value
 * @return NES_SUCCESS on success and NES_FAIL on fail
 */
int nes_cfgfile_entry(const char *section, const char *entry, const char **value);

/**
 * @brief Check if configuration section exists
 *
 * @param[in] section - configuration section
 * @return NES_SUCCESS when configuration section exists and NES_FAIL when it does not
 */
int nes_cfgfile_has_section(const char *section);

/**
 * @brief Close previously opened configuration file
 *
 * @return NES_SUCCESS on success and NES_FAIL on fail
 */
void nes_cfgfile_close(void);

/**
 * @brief Get all configuration entries from specified section
 *
 * @param[in] sectionname - configuration section
 * @param[out] entries - configuration entries
 * @param[in] max_entries - max number of entries to get
 * @return NES_SUCCESS on success and NES_FAIL on fail
 */
int nes_cfgfile_get_entries(const char *sectionname, struct rte_cfgfile_entry  *entries, int max_entries);

/**
 * @brief Get lookup entries from specified lookup string
 *
 * @param[in] lookup_str - lookup string
 * @param[out] entries - lookup entries
 * @param[in] max_entries - max number of entries to get
 * @return NES_SUCCESS on success and NES_FAIL on fail
 */
int nes_cfgfile_get_lookup_entries(const char *lookup_str, struct cfg_lookup_entry *entries, int max_entries);

/**
 * @brief Get the number of lookup entries specified in lookup string
 *
 * @param[in] lookup_str - lookup string
 * @return number of lookup entries
 */
int nes_cfgfile_num_lookup_entries(const char *lookup_str);

/**
 * @brief Get the number of entries in configuration section
 *
 * @param[in] sectionname - configuration section
 * @return number of configuration entries
 */
int nes_cfgfile_section_num_entries(const char *sectionname);

#ifdef __cplusplus
}
#endif

#endif /* _LIBNES_CFGFILE_H_ */
