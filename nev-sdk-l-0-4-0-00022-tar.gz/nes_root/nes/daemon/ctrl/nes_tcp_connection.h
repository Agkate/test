/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file nes_tcp_connection.h
* @brief Header file for tcp server connection
*/
#ifndef _NES_TCP_CONNECTION_H_
#define _NES_TCP_CONNECTION_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <netinet/in.h>
#include <stdint.h>

/*typedef enum tcp_connection_state_e
{
    eTerminated = 0,
    eReadyToListen = 1,
    eListening = 2,
    eConnected = 3,
    eDisconnected = 4,
    eInvalid = 255
} tcp_connection_state;
*/
typedef struct one_client_conn_s
{
    int client_id;
    int tcp_sock;
    struct cmdline *cmdline;
} one_client_conn_t;

typedef struct tcp_connection_s
{
    int listen_sock;
    socklen_t addr_len;
    int tcp_sock;

    struct sockaddr_in remote_addr;
    struct sockaddr_in local_addr;
    struct sockaddr_un local_un_addr;
} tcp_connection_t;

#ifdef EXT_CTRL_SOCKET
int nes_connection_setup(const char *ip_addr, uint16_t port_nr, tcp_connection_t *conn);
#endif
int nes_connection_un_setup(const char *socket_path, tcp_connection_t *conn);

#ifdef __cplusplus
}
#endif
#endif /* _NES_TCP_CONNECTION_H_ */
