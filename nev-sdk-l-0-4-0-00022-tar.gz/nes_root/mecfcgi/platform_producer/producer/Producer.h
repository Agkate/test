/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file     Producer.h
* @brief    This class is primarily responsible for the communication of the
*           Producer with the ME Platform, the start-up of the Producer, the
*           activation of services, and the update of data.
*/

#ifndef _PRODUCER_H_
#define _PRODUCER_H_

#include <string>
#include "IProducer.h"
#include <json/json.h>

using namespace std;

class Producer : public IProducer
{
public:
    Producer();
    ~Producer();

    /**
    * @brief            Sends REST API Requests for activating a ME Service.
    * @param[in]        serviceInfo     JSON-formatted service info.
    * @return           true on success and false on fail.
    */
    virtual bool activateMobileEdgeService(string serviceInfo);

    /**
    * @brief            Sends REST API requests for publishing messages.
    * @param[in]        data            JSON formatted service data.
    * @return           void.
    */
    virtual void doNotifyData(string data);

    /**
    * @brief            Indicates the ME Platform that ME Platform producer is
    *                   up and running
    * @param[in]        appid     Platform producer appid.
    * @param[in]        secret    Platform producer secret.
    * @return           true on success and false on fail.
    */
    bool producerLiveIndicator(string appid, string secret);

private:
    static map<string, string> serviceIds;
};

#endif
