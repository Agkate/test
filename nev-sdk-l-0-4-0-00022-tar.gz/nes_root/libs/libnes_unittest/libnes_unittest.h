/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file libnes_unittest.h
* @brief Header file for unit tests
*/
#ifndef _LIBNES_UNITTEST_H_
#define _LIBNES_UNITTEST_H_

#ifdef __cplusplus
extern "C" {
#endif

static size_t _subtests = 0, _tests = 0, _subtests_failed = 0, _tests_failed = 0;

#define START_TEST_CASE     int ret=0
#define RUN_TEST(x, y)      { _tests++; if(!x()) { printf("Test %s passed\n", y); } else { printf("Test %s failed\n", y); _tests_failed++; } }
#define SHOULD_BE(x)        { _subtests++; if(!(x)) { _subtests_failed++; ret++; printf("Line %d fails\n", __LINE__); } }
#define END_TEST_CASE       return ret
#define RAPORT_OF_TESTS     { printf("Report:\n"); \
                              printf("Main tests=%zu, failed=%zu(%.1f%%)\n", _tests, _tests_failed, ((float)_tests_failed*100)/(float)_tests); \
                              printf("Subtests=%zu, failed=%zu(%.1f%%)\n", _subtests, _subtests_failed, ((float)_subtests_failed*100)/(float)_subtests); \
                            }


#ifdef __cplusplus
}
#endif

#endif /* _LIBNES_UNITTEST_H_ */

