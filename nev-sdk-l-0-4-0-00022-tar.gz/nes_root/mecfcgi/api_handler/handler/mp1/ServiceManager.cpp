/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  ServiceManager.cpp
* @brief Mobile Edge Service Activation, Deactivation And Discovery
*/

#include "ServiceManager.h"
#include "SessionManager.h"
#include "Exception.h"
#include "HandlerCommon.h"
#include "DbManager.h"
#include "Log.h"
#include "RawRequest.h"
#include "HashUtil.h"
#include "ServiceRegistryPort.h"
#include "WebSocketServer.h"

/**
 * @brief       Checks whether a service exists.
 * @param[in]   token       ME App's token (reference ID).
 * @param[in]   serviceName Name representing the service provided by an
 *                          ME App Service.
 * @return      void
 */
static void checkServiceExist(bool &isFound, string token, string serviceName, 
                                string &serviceId);

/**
 * @brief       Creates a unique ID for a service based on an ME App's
 *              token and service name.
 * @param[out]  serviceId   Service ID.
 * @param[in]   token       ME App's token (reference ID).
 * @param[in]   serviceName Name representing the service provided by an
 *                          ME App Service.
 * @return      void
 */
static void createServiceId(string &serviceId, string token, string serviceName);

/**
 * @brief       Checks whether a service ID exists and belongs to the ME App.
 * @param[out]  isFound     Indication of whether a serviceId is found.
 * @param[in]   token       ME App's token (reference ID).
 * @param[in]   serviceId   Service ID.
 * @return      void
 */
static void checkServiceId(bool &isFound, string serviceId, string token);

/**
 * @brief       Validates dataSchema and converts it to a string.
 * @param[out]  dataSchemaCvt   A dataSchema of the string type.
 * @param[in]   dataSchema      JSON Schema specifying the format of service data.
 * @return      void
 */
static void checkAndConvertServiceDataSchema(Json::Value dataSchema,
                                             string &dataSchemaCvt);
/**
 * @brief       Gets list all of activated services from database.
 * @param[out]  serviceIdList   List of activated services.
 * @return      void
 */
static void getActivatedService(Json::Value &serviceIdList);

void ServiceActivation::execute(Json::Value &request, Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    string serviceName = request.get("serviceName","Nil").asString();
    string version = request.get("version","Nil").asString();
    string endPoint = request.get("endPoint","Nil").asString();
    string serviceType = request.get("serviceType","Nil").asString();
    Json::Value dataSchemaOrg = request.get("dataSchema","Nil");

    try {
        string token = "";
        string appid= "";
        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);
        if (0 == serviceName.compare("Nil")) {
            MECFCGI_LOG(ERR, "[serviceName] is not found in request.\n");
            throw Exception(Exception::NO_SERVICE_NAME);
        }
        if (0 == version.compare("Nil")) {
            MECFCGI_LOG(ERR,  "[version] is not found in request.\n");
            throw Exception(Exception::NO_SERVICE_VERSION);
        }
        if (0 == endPoint.compare("Nil")) {
            MECFCGI_LOG(ERR,  "[endPoint] is not found in request.\n");
            throw Exception(Exception::NO_SERVICE_ENDPOINT);
        }
        if (0 == serviceType.compare("Nil")) {
            MECFCGI_LOG(ERR,  "[serviceType] is not found in request.\n");
            throw Exception(Exception::NO_SERVICE_TYPE);
        }
        if (0 != serviceType.compare(ME_SERVICE_TYPE_1) &&
            0 != serviceType.compare(ME_SERVICE_TYPE_2) &&
            0 != serviceType.compare(ME_SERVICE_TYPE_3) &&
            0 != serviceType.compare(ME_SERVICE_TYPE_4)) {
            MECFCGI_LOG(ERR, "Service type(%s) is not recognized.\n",
                serviceType.c_str());
            throw Exception(Exception::INVALID_SERVICE_TYPE);
        }
        if ((!request.isMember("dataSchema")) &&
            (0 != serviceType.compare(ME_SERVICE_TYPE_3))) {
            MECFCGI_LOG(ERR,  "[dataSchema] is not found in request.\n");
            throw Exception(Exception::NO_SERVICE_DATASCHEMA);
        }
        string serviceId;
        bool isFound = false;
        checkServiceExist(isFound, token, serviceName, serviceId);
        if (isFound) {
            response["serviceId"] = serviceId;
            MECFCGI_LOG(INFO, "Service already exists.\n");
            throw Exception(Exception::SERVICE_EXIST);
        }
        string result = "";
        ServiceRegistryPort::checkPolicyForService(result,
                                ServiceRegistryPort::ACTION_ACTIVATION_SERVICE,
                                appid, serviceName);
        if (0 != result.compare("OK")) {
            MECFCGI_LOG(ERR,
                "ME App[%s] is not permitted to activate specified service.\n",
                appid.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        createServiceId(serviceId, token, serviceName);
        string dataSchemaCvt = "";
        if (0 != serviceType.compare(ME_SERVICE_TYPE_3)) {
            string serviceNameInSchema = dataSchemaOrg.get("serviceName","Nil").asString();
            if (0 == serviceNameInSchema.compare("Nil")) {
                MECFCGI_LOG(ERR, "[serviceName] is not found in data schema.\n");
                throw Exception(Exception::INVALID_DATA_SCHEMA);
            }
            if (0 != serviceNameInSchema.compare(serviceName)) {
                MECFCGI_LOG(ERR, "[serviceName] is error in data schema.\n");
                throw Exception(Exception::INVALID_DATA_SCHEMA);
            }
            checkAndConvertServiceDataSchema(dataSchemaOrg, dataSchemaCvt);
        }
        Json::FastWriter writer;
        DbManager::addActivatedService(token, serviceName, serviceId, endPoint, 
                                        version, serviceType, 
                                        dataSchemaCvt, 
                                        writer.write(dataSchemaOrg));

        //Send New service announcement notifications to subscriber.
        Json::Value subscriberAppidList;
        ServiceRegistryPort::getAppidListFromServiceRegistry(
            subscriberAppidList, serviceName, appid);
        Json::Value serviceInfo;
        serviceInfo["serviceName"] = serviceName;
        serviceInfo["serviceId"] = serviceId;
        serviceInfo["version"] = version;
        serviceInfo["endPoint"] = endPoint;
        serviceInfo["serviceType"] = serviceType;
        
        Json::Value message;
        message["id"] = "NewServiceAnnouncement";
        message["data"] = serviceInfo;
        string sMessage = writer.write(message);
        int size = subscriberAppidList.size();
        for (int i = 0; i < size; i++) {
            string subscriberAppid_ = subscriberAppidList[i].get(
                "appid", "Nil").asString();
            try {
                string subscriberToken;
                DbManager::getSessionByAppid(subscriberToken,
                    subscriberAppid_);

                getWebServer()->pushData(subscriberToken, "NewServiceAnnouncement",
                                    sMessage);
            } catch (Exception &e) {
                if (e.code != Exception::APPID_NOT_EXIST) {
                    MECFCGI_LOG(ERR, "Database error.\n");
                    throw;
                }
            }
        }

        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
        response["serviceId"] = serviceId;
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void createServiceId(string &serviceId, string token, string serviceName)
{
    stringstream ssTmp;
    ssTmp << token << serviceName << time(NULL);
    serviceId = HashUtil::sha256(ssTmp.str());
}

void checkServiceExist(bool &isFound, string token, string serviceName, 
                        string &serviceId)
{
    isFound = false;
    DbManager::StringArrayType activatedServiceIdList;
    DbManager::getActivatedServiceIdList(activatedServiceIdList);
    if (activatedServiceIdList.size() > 0) {
        for (string &activatedServiceId_ : activatedServiceIdList) {
            string activatedServiceId = "";
            string activatedServiceName = "";
            string activatedServiceToken = "";
            istringstream ssActivatedService(activatedServiceId_);
            getline(ssActivatedService, activatedServiceId, SPLIT_MARK);
            getline(ssActivatedService, activatedServiceId);
            DbManager::getActivatedServiceName(activatedServiceId,
                activatedServiceName);
            DbManager::getActivatedServiceToken(activatedServiceId,
                activatedServiceToken);
            if (0 == activatedServiceName.compare(serviceName) &&
                0 == activatedServiceToken.compare(token)){
                isFound = true;
                serviceId = activatedServiceId;
                break;
            }
        }
    }
}

int parseIntegerData(Json::Value &dataSchema, Json::Value dataSchemaOrg, int i,
                        string name, string loc)
{
    if (dataSchemaOrg["fields"][i].isMember("min")) {
        if (Json::intValue != dataSchemaOrg["fields"][i]["min"].type()) {
            MECFCGI_LOG(ERR, "Fields[%d] min is of wrong data type.\n", i);
            return 0;
        }
        int min = dataSchemaOrg["fields"][i].get("min", "").asInt();
        dataSchema["properties"][loc]["properties"][name]["minimum"] = min;
        if (dataSchemaOrg["fields"][i].isMember("max")) {
            if (Json::intValue != dataSchemaOrg["fields"][i]["max"].type()) {
                MECFCGI_LOG(ERR, "Schema fields max is of wrong data type.\n");
                return 0;
            }
            int max = dataSchemaOrg["fields"][i].get("max", "").asInt();
            dataSchema["properties"][loc]["properties"][name]["maximum"] = max;
            if (min > max) {
                MECFCGI_LOG(ERR, "Schema fields min exeeds max.\n");
                return 0;
            }
        }
    } else if (dataSchemaOrg["fields"][i].isMember("max")) {
        if (Json::intValue != dataSchemaOrg["fields"][i]["max"].type()) {
            MECFCGI_LOG(ERR, "Schema fields min is of wrong data type.\n");
            return 0;
        }
        int max = dataSchemaOrg["fields"][i].get("max", "").asInt();
        dataSchema["properties"][loc]["properties"][name]["maximum"] = max;
    }
    return 1;
}

void checkAndConvertServiceDataSchema(Json::Value dataSchemaOrg,
                                      string &dataSchemaCvt)
{
    Json::Value dataSchema;
    dataSchema["type"] = "object";
    dataSchema["properties"]["serviceName"]["type"] = "string";
    dataSchema["properties"]["keyFields"]["type"] = "object";
    dataSchema["properties"]["data"]["type"] = "object";
    int size = dataSchemaOrg["fields"].size();
    int keyFieldsReqNo = 0;
    int dataReqNo = 0;
    for (int i = 0; i < size; i++) {
        string type = dataSchemaOrg["fields"][i].get("type", "Nil").asString();
        string name = dataSchemaOrg["fields"][i].get("name", "Nil").asString();
        string key = dataSchemaOrg["fields"][i].get("key", "Nil").asString();
        if (0 == name.compare("Nil")) {
            MECFCGI_LOG(ERR, "[field][name] is not found in fields[%d].\n", i);
            throw Exception(Exception::INVALID_DATA_SCHEMA);
        }
        if (0 == type.compare("Nil")) {
            MECFCGI_LOG(ERR,
                "[field][type] is not found in fields[%d], for name:%s.\n",
                i, name.c_str());
            throw Exception(Exception::INVALID_DATA_SCHEMA);
        }
        if ((0 == type.compare("integer")) || (0 == type.compare("string"))) {
            if (0 == key.compare("YES")) {
                dataSchema["properties"]["keyFields"]["properties"][name]["type"] = type;
                dataSchema["properties"]["keyFields"]["required"][keyFieldsReqNo] = name;
                keyFieldsReqNo++;
                if (0 == type.compare("integer")) {
                    string loc = SCHEMA_KEYFIELDS;
                    if(0 == parseIntegerData(dataSchema, dataSchemaOrg, i,
                        name, loc)) {
                        throw Exception(Exception::INVALID_DATA_SCHEMA);
                    }
                }
            } else if ((0 == key.compare("NO")) || (0 == key.compare("Nil"))) {
                dataSchema["properties"]["data"]["properties"][name]["type"] = type;
                dataSchema["properties"]["data"]["required"][dataReqNo] = name;
                dataReqNo++;
                if (0 == type.compare("integer")) {
                    string loc = SCHEMA_DATA;
                    if(0 == parseIntegerData(dataSchema, dataSchemaOrg, i,
                        name, loc)) {
                        throw Exception(Exception::INVALID_DATA_SCHEMA);
                    }
                }
            }
        } else if ((0 == type.compare("object"))) {
            if (0 == key.compare("YES")) {
                MECFCGI_LOG(ERR,
                    "Schema key is of wrong type: not an integer or string.\n");
                throw Exception(Exception::INVALID_DATA_SCHEMA);
            }
            dataSchema["properties"]["data"]["properties"][name]["type"] = type;
            dataSchema["properties"]["data"]["required"][dataReqNo] = name;
            dataReqNo++;
        } else {
            MECFCGI_LOG(ERR, "Schema type is not recognized.\n");
            throw Exception(Exception::INVALID_DATA_SCHEMA);
        }
    }
    if (0 == dataReqNo) {
        throw Exception(Exception::INVALID_DATA_SCHEMA);
    }
    Json::FastWriter writer;
    dataSchemaCvt = writer.write(dataSchema);
}

void ServiceDeactivation::execute(map<string, string> params,
                                    Json::Value &response,
                                    map<string, string> &headers,
                                    map<string, string> &cookies)
{
    try {
        string serviceName, token, appid;
        string serviceId = params["UUID"];

        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);

        //Check serviceId's existence.
        bool isFound = false;
        checkServiceId(isFound, serviceId, token);
        if (!isFound) {
            MECFCGI_LOG(ERR, "Service does not exist.\n");
            throw Exception(Exception::SERVICE_NOT_EXIST);
        }
        DbManager::getActivatedServiceName(serviceId, serviceName);
        string result = "";
        ServiceRegistryPort::checkPolicyForService(result,
                            ServiceRegistryPort::ACTION_DEACTIVATION_SERVICE,
                            appid, serviceName);
        if (0 != result.compare("OK")) {
            MECFCGI_LOG(ERR,
                "ME App[%s] is not permitted to deactive the specified service.\n",
                appid.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        // Send Service Availability change notification to ME apps that can
        // subscribe to this service .
        Json::Value subscriberAppidList;
        ServiceRegistryPort::getAppidListFromServiceRegistry(
            subscriberAppidList, serviceName, appid);
        string version, endPoint, serviceType;
        DbManager::getActivatedServiceVersion(serviceId, version);
        DbManager::getActivatedServiceEndPoint(serviceId, endPoint);
        DbManager::getActivatedServiceServiceType(serviceId, serviceType);
        Json::Value serviceInfo;
        serviceInfo["serviceId"] = serviceId;
        serviceInfo["serviceName"] = serviceName;                
        serviceInfo["version"] = version;
        serviceInfo["endPoint"] = endPoint;
        serviceInfo["serviceType"] = serviceType;

        Json::Value message;
        message["id"] = "ServiceAvailabilityChange";
        message["data"] = serviceInfo;                                
        Json::FastWriter writer;
        string sMessage = writer.write(message);

        int size = subscriberAppidList.size();
        for (int i = 0; i < size; i++) {
            string subscriberAppid_ = subscriberAppidList[i].get(
                "appid", "Nil").asString();
            try {
                string subscriberToken;
                DbManager::getSessionByAppid(subscriberToken,
                    subscriberAppid_);
                getWebServer()->pushData(subscriberToken, "ServiceAvailabilityChange",
                                sMessage);
            } catch (Exception &e) {
                if (e.code != Exception::APPID_NOT_EXIST) {
                    MECFCGI_LOG(ERR, "Database error.\n");
                    throw;
                }
            }
        }
        // Delete activated service list.
        DbManager::delActivatedServiceByServiceId(serviceId);

        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void checkServiceId(bool &isFound, string serviceId, string token)
{
    isFound = false;
    string activatedServiceToken = "";
    DbManager::getActivatedServiceToken(serviceId, activatedServiceToken);
    if (0 == activatedServiceToken.compare(token)){
        isFound = true;
    }
}

void ServiceDiscovery::execute(map<string, string> params,
                                Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    try {
        string token, appid;
        SessionManager::checkSession(cookies, token);

        // Get service list from database.
        Json::Value serviceIdList;
        getActivatedService(serviceIdList);

        SessionManager::getAppidBySession(token, appid);
        Json::Value subscriptionServiceList;
        ServiceRegistryPort::getSubscriptionServiceListFromServiceRegistry(
            subscriptionServiceList, appid);

        Json::Value serviceList;
        serviceList = Json::Value(Json::arrayValue);
        int m = 0;
        if (serviceIdList.size() > 0 && subscriptionServiceList.size() > 0) {
            for (int i = 0; i < int(serviceIdList.size()); i++) {
                string serviceId_ = serviceIdList[i]["serviceId"].asString();
                string serviceName_;
                string providerAppToken_, providerAppId_;
                DbManager::getActivatedServiceName(serviceId_, serviceName_);
                DbManager::getActivatedServiceToken(serviceId_,
                    providerAppToken_);
                SessionManager::getAppidBySession(providerAppToken_,
                    providerAppId_);
                bool match = false;
                for (int j = 0; j < int(subscriptionServiceList.size()); j++) {
                    string serviceName = subscriptionServiceList[j].get(
                        "serviceName", "Nil").asString();
                    string providerAppId = subscriptionServiceList[j].get(
                        "providerAppId", "Nil").asString();
                    if (0 == serviceName.compare(serviceName_) &&
                        (0 == providerAppId.compare(providerAppId_))) {
                        match = true;
                        break;
                    }
                }
                if (match) {
                    serviceList[m]["serviceId"] = serviceId_;
                    serviceList[m]["serviceName"] = serviceName_;
                    serviceList[m]["providerAppId"] = providerAppId_;
                    string version, endPoint;
                    DbManager::getActivatedServiceVersion(serviceId_, version);
                    DbManager::getActivatedServiceEndPoint(serviceId_, endPoint);
                    serviceList[m]["version"] = version;
                    serviceList[m]["endPoint"] = endPoint;
                    m++;
                }
            }
        }

        response["result"] = "OK";
        headers["Status"] = HTTP_SC_OK;
        response["services"] = serviceList;
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void getActivatedService(Json::Value &serviceIdList)
{
    DbManager::StringArrayType activatedServiceId;
    DbManager::getActivatedServiceIdList(activatedServiceId);
    if (activatedServiceId.size() > 0) {
        serviceIdList = Json::Value(Json::arrayValue);
        for (string &activatedServiceId_ : activatedServiceId) {
            Json::Value service;
            string serviceId;
            istringstream ssActivatedServiceId(activatedServiceId_);
            // MeAPS:serviceId
            getline(ssActivatedServiceId, serviceId, SPLIT_MARK);     //MeAPS
            getline(ssActivatedServiceId, serviceId);     //serviceId

            service["serviceId"] = serviceId;
            serviceIdList.append(service);
        }
    }
}