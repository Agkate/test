/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  TrafficManager.cpp
* @brief Mobile Edge Traffic Rules Control
*/

#include "TrafficManager.h"
#include "SessionManager.h"
#include "Exception.h"
#include "DbManager.h"
#include "HandlerCommon.h"
#include "NesPortFactory.h"
#include "Log.h"
#include "RawRequest.h"
#include "ServiceRegistryPort.h"
#include "HashUtil.h"
#include <sstream>

/**
 * @brief        Gets traffic rule information for an ME App from request.
 * @param[in]    request       JSON-formatted request data.
 * @param[out]   lookupKeys    Set of look-up keys associated with one or more
 *                             traffic rules.
 * @param[out]   macAddress    Virtual machine's M.A.C. address.
 * @param[out]   vmId          Virtual machine's ID.
 * @throw        Exception     Thrown on failure.
 * @return       void
 */
static void getTrafficRuleParameters(string &lookupKeys, string &macAddress,
                                     uint32_t &vmId, Json::Value request);

void CreateTrafficRule::execute(Json::Value &request, Json::Value &response,
                    map<string, string> &headers, map<string, string> &cookies)
{
    try {
        string token = "";
        string appid= "";
        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);

        // Check request body and get parameter for nes.
        string lookupKeys = "";
        string macAddr = "";
        uint32_t vmId = 0;
        getTrafficRuleParameters(lookupKeys, macAddr, vmId, request);

        // Check policy for update new traffic rule.
        bool isPass = false;
        ServiceRegistryPort::checkPolicyForTrafficRule(isPass,
                                ServiceRegistryPort::ACTION_CREATE_TRAFFIC_RULE,
                                appid, request);
        if (!isPass) {
            MECFCGI_LOG(ERR,
                "ME App[%s] is not permitted to create this traffic rule.\n",
                appid.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        // Check if the rule is already in the database.
        DbManager::StringArrayType trafficRuleIdList;
        DbManager::getTrafficRuleIdList(trafficRuleIdList);
        if (trafficRuleIdList.size() > 0) {
            for (string &trafficRuleId_ : trafficRuleIdList) {
                string trafficRuleToken;
                istringstream ssTrafficRuleId(trafficRuleId_);
                getline(ssTrafficRuleId, trafficRuleId_, SPLIT_MARK);
                getline(ssTrafficRuleId, trafficRuleId_);
                DbManager::getTrafficRuleTokenByRuleId(trafficRuleToken,
                    trafficRuleId_);
                if(0 == trafficRuleToken.compare(token)){
                    string trafficRule_ = "";
                    Json::FastWriter writer;
                    DbManager::getTrafficRuleInfoByTrafficRuleId(trafficRuleId_,
                                                                trafficRule_);
                    if(0 == trafficRule_.compare(writer.write(request))) {
                        MECFCGI_LOG(ERR, "Rule is already in the database.\n");
                        response["trafficRuleId"] = trafficRuleId_;
                        throw Exception(Exception::TRAFFIC_RULE_EXIST);
                    }
                }
            }
        }

        // Call NES API to add traffic rule to NTS routing table.
        NesPort::AddRoute trafficRule;
        trafficRule.lookupKeys = lookupKeys;
        trafficRule.macAddr = macAddr;
        trafficRule.vmId = vmId;
        NesPortFactory::getInstance().addRoute (trafficRule);

        // Create Traffic rule Id.
        stringstream ssTrafficRuleId;
        ssTrafficRuleId << token << lookupKeys << macAddr << vmId << time(NULL);
        string trafficRuleId = HashUtil::sha256(ssTrafficRuleId.str());

        // Update database.
        Json::FastWriter writer;
        DbManager::addTrafficRulesInfo(trafficRuleId, token, lookupKeys,
                                        macAddr, vmId, writer.write(request));

        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
        response["trafficRuleId"] = trafficRuleId;

    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}
void UpdateTrafficRule::execute(Json::Value &request, Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    try {
        string token = "";
        string appid= "";
        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);

        // Get old trafficrule info from database.
        string trafficRuleId = request.get("UUID", "Nil").asString();
        if ((0 == trafficRuleId.compare("Nil")) || 
            (0 == trafficRuleId.compare(""))) {
            MECFCGI_LOG(ERR, "[trafficRuleId] is not found in URL.\n");
            throw Exception(Exception::INVALID_TRAFFIC_RULE);
        }

        bool isFound = false;
        string oldLookupKeys = "";
        string oldTrafficRule = "";
        DbManager::getTrafficRuleInfoByTrafficRuleId(isFound, trafficRuleId,
                                                        oldLookupKeys,
                                                        oldTrafficRule);
        if (!isFound) {
            MECFCGI_LOG(ERR,
                "Traffic rule does not exist.\n");
            throw Exception(Exception::TRAFFIC_RULE_AUTHORITY_ERROR);
        }

        // Check policy for removing Traffic rule.
        Json::Reader reader;
        Json::Value jsonTrafficRule;
        reader.parse(oldTrafficRule, jsonTrafficRule);

        bool isPass = false;
        ServiceRegistryPort::checkPolicyForTrafficRule(isPass,
                        ServiceRegistryPort::ACTION_UPDATE_TRAFFIC_RULE,
                        appid, jsonTrafficRule);
        if (!isPass) {
            MECFCGI_LOG(ERR,
                "ME App[%s] is not permitted to update an existing traffic \
                    rule.\n", appid.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        // Check request body and get parameter for NES.
        string lookupKeys = "";
        string macAddr = "";
        uint32_t vmId = 0;
        getTrafficRuleParameters(lookupKeys, macAddr, vmId, request);

        // Check policy for update new traffic rule.
        isPass = false;
        ServiceRegistryPort::checkPolicyForTrafficRule(isPass,
                        ServiceRegistryPort::ACTION_UPDATE_TRAFFIC_RULE,
                        appid, request);

        if (!isPass) {
            MECFCGI_LOG(ERR,
                "ME App[%s] is not permitted to update an existing traffic \
                    rule to a new traffic rule.\n", appid.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        // Call NES API to remove old traffic rule from NES.
        NesPort::RemoveRoute removeRoute;
        removeRoute.lookupKeys = oldLookupKeys;
        NesPortFactory::getInstance().removeRoute (removeRoute);

        // Call NES API to add new traffic rule to NES.
        NesPort::AddRoute trafficRule;
        trafficRule.lookupKeys = lookupKeys;
        trafficRule.macAddr = macAddr;
        trafficRule.vmId = vmId;
        NesPortFactory::getInstance().addRoute (trafficRule);

        // Update database.
        Json::FastWriter writer;
        DbManager::addTrafficRulesInfo(trafficRuleId, token, lookupKeys,
                                        macAddr, vmId, writer.write(request));

        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";

    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void RemoveTrafficRule::execute(map<string, string> params,
                                Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    try {
        string token = "";
        string appid= "";
        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);

        // Get old trafficrule info from database.
        string trafficRuleId = params["UUID"];
        if (0 == trafficRuleId.compare("")) {
            MECFCGI_LOG(ERR, "[trafficRuleId] is not found in URL.\n");
            throw Exception(Exception::INVALID_TRAFFIC_RULE);
        }

        bool isFound = false;
        string lookupKeys = "";
        string trafficRule = "";
        DbManager::getTrafficRuleInfoByTrafficRuleId(isFound, trafficRuleId,
                                                        lookupKeys,
                                                        trafficRule);
        if (!isFound) {
            MECFCGI_LOG(ERR,
                "ME App is not permitted to to remove this traffic rule.\n");
            throw Exception(Exception::TRAFFIC_RULE_AUTHORITY_ERROR);
        }

        // Check policy for traffic rule removal.
        Json::Reader reader;
        Json::Value jsonTrafficRule;
        reader.parse(trafficRule, jsonTrafficRule);

        bool isPass = false;
        ServiceRegistryPort::checkPolicyForTrafficRule(isPass,
                                ServiceRegistryPort::ACTION_REMOVE_TRAFFIC_RULE,
                                appid, jsonTrafficRule);
        if (!isPass) {
            MECFCGI_LOG(ERR,
                "ME App[%s] is not permitted to remove this traffic rule.\n",
                appid.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        // Call NES API to remove old traffic rule from NES.
        NesPort::RemoveRoute removeRoute;
        removeRoute.lookupKeys = lookupKeys;
        NesPortFactory::getInstance().removeRoute (removeRoute);

        // Update database.
        DbManager::delTrafficRulesInfo(trafficRuleId);

        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void getTrafficRuleParameters(string &lookupKeys, string &macAddress,
                                uint32_t &vmId, Json::Value request)
{
    Json::Value trafficRule = request.get("trafficRule","Nil");
    macAddress = request.get("macAddress", "Nil").asString();
    if (0 == trafficRule.compare("Nil")) {
        MECFCGI_LOG(ERR, "[trafficRule] is not found in request.\n");
        throw Exception(Exception::INVALID_TRAFFIC_RULE);
    }
    if (0 == macAddress.compare("Nil")) {
        MECFCGI_LOG(ERR, "[macAddress] is not found in request.\n");
        throw Exception(Exception::INVALID_MAC_ADDRESS);
    }

    // Check vmId.
    if ((!request.isMember("vmId")) || (!request["vmId"].isUInt())) {
        MECFCGI_LOG(ERR, "[vmId] is not found/invalid.\n");
        throw Exception(Exception::INVALID_VM_ID);
    }
    vmId = request.get("vmId","").asUInt();

    // lookupKeys: "prio:" + val["prio"];
    // "prio:99,encap_proto=noencap,srv_ip:192.168.10.11,srv_port:80"
    if (Json::intValue != trafficRule["prio"].type()) {
        MECFCGI_LOG(ERR, "[prio] is of wrong data type.\n");
        throw Exception(Exception::INVALID_TRAFFIC_RULE);
    }
    int prio = trafficRule.get("prio", "").asInt();

    lookupKeys = RULE_FIELD_NAME_PRIO;
    lookupKeys += RULE_FIELD_VALUE_SPLIT_MARK + to_string(prio);
    Json::Value ruleFields = trafficRule.get ("ruleFields","Nil");
    int size = ruleFields.size();
    if (0 == size) {
        MECFCGI_LOG(ERR, "[ruleFields] is not found.\n");
        throw Exception(Exception::INVALID_TRAFFIC_RULE);
    }
    for (int i = 0; i < size; i++){
        string name = ruleFields[i].get ("name","Nil").asString();
        if (0 == name.compare("Nil")){
            MECFCGI_LOG(ERR, "[name] is not found in ruleFields.\n");
            throw Exception(Exception::INVALID_TRAFFIC_RULE);
        }
        if (0 == name.compare(RULE_FIELD_NAME_ENCAP_PROTO)) {
            string value = 
                ruleFields[i].get("value","Nil").asString();
            if ((0 != value.compare("gtpu")) && 
                (0 != value.compare("noencap"))) {
                MECFCGI_LOG(ERR, 
                    "[%s:value] is not found in ruleFields.\n",
                    name.c_str());
                throw Exception(Exception::INVALID_TRAFFIC_RULE);
            }
            lookupKeys += RULE_FIELD_SPLIT_MARK + name +
                            RULE_FIELD_VALUE_SPLIT_MARK + value;
        } else if ((0 == name.compare(RULE_FIELD_NAME_UE_IP)) ||
                    (0 == name.compare(RULE_FIELD_NAME_SRV_IP)) ||
                    (0 == name.compare(RULE_FIELD_NAME_ENB_IP)) ||
                    (0 == name.compare(RULE_FIELD_NAME_EPC_IP))) {
            string ip = ruleFields[i].get ("ip","Nil").asString();
            if (0 == ip.compare("Nil")){
                MECFCGI_LOG(ERR, "[%s:ip] is not found in ruleFields.\n",
                    name.c_str());
                throw Exception(Exception::INVALID_TRAFFIC_RULE);
            }
            lookupKeys += RULE_FIELD_SPLIT_MARK + name +
                            RULE_FIELD_VALUE_SPLIT_MARK + ip;
            if (Json::nullValue != ruleFields[i]["ip_mask"].type()) {
                if (Json::intValue != ruleFields[i]["ip_mask"].type()) {
                    MECFCGI_LOG(ERR, "[ip_mask] is of wrong data type.\n");
                    throw Exception(Exception::INVALID_TRAFFIC_RULE);
                }
                uint32_t ip_mask = ruleFields[i].get("ip_mask", "").asInt();

                if (ip_mask > IP_MASK_MAX) {
                    MECFCGI_LOG(ERR, "[%s:ip_mask] is out of range.\n",
                        name.c_str());
                    throw Exception(Exception::INVALID_TRAFFIC_RULE);
                }
                lookupKeys += RULE_FIELD_IP_MASK_SPLIT_MARK + 
                                to_string(ip_mask);
            }
        } else if ((0 == name.compare(RULE_FIELD_NAME_UE_PORT)) ||
                    (0 == name.compare(RULE_FIELD_NAME_SRV_PORT))){
            if ((!ruleFields[i].isMember("min")) ||
                (!ruleFields[i]["min"].isUInt())) {
                MECFCGI_LOG(ERR, "[%s:min] is not found/invalid.\n",
                    name.c_str());
                throw Exception(Exception::INVALID_TRAFFIC_RULE);
            }
            uint32_t min = ruleFields[i].get("min", "").asUInt();
            uint32_t max = min;
            if (ruleFields[i].isMember("max")) {
                if (!ruleFields[i]["max"].isUInt()) {
                    MECFCGI_LOG(ERR, "[%s:max] is of wrong data type.\n",
                        name.c_str());
                    throw Exception(Exception::INVALID_TRAFFIC_RULE);
                } 
                max = ruleFields[i].get("max", "").asUInt();
            }
            if ((min > max) || (max > PORT_MAX)) {
                MECFCGI_LOG(ERR, "[%s:min / max] is out of range.\n",
                    name.c_str());
                throw Exception(Exception::INVALID_TRAFFIC_RULE);
            }
            lookupKeys += RULE_FIELD_SPLIT_MARK + name +
                            RULE_FIELD_VALUE_SPLIT_MARK + to_string(min);
            lookupKeys += RULE_FIELD_MIN_MIN_SPLIT_MARK + to_string(max);
        } else {
            MECFCGI_LOG(ERR, "RuleField [%s] is illegal.\n", name.c_str());
            throw Exception(Exception::INVALID_TRAFFIC_RULE);
        }
    }
}
