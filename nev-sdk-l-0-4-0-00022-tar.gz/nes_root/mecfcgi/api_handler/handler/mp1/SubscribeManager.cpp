/*******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  SubscribeManager.cpp
* @brief Mobile Edge Service Subscription
*/

#include "SubscribeManager.h"
#include "SessionManager.h"
#include "Exception.h"
#include "DbManager.h"
#include "Exception.h"
#include "ServiceRegistryPort.h"
#include "HandlerCommon.h"
#include "Log.h"
#include "RawRequest.h"

void AddSubscription::execute(map<string, string> params, Json::Value &response,
                              map<string, string> &headers,
                              map<string, string> &cookies)
{
    try {
        string token, appid;
        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);

        string serviceId = params["UUID"];

        if (SERVICE_ID_LENGTH != strlen(serviceId.c_str())){
            MECFCGI_LOG(ERR, "[serviceId] is invalid.\n");
            throw Exception(Exception::INVALID_PARAMETER);
        }

        // Check policy.
        bool isPass = false;
        ServiceRegistryPort::checkPolicyForSubscriber(isPass,
                        ServiceRegistryPort::ACTION_SUBSCRIPTION_SERVICE,
                        appid, serviceId);
        if (!isPass) {
            MECFCGI_LOG(ERR, "ME App[%s] is not permitted to subscribe to the \
                specified service[%s].\n", appid.c_str(), serviceId.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        bool subscribed = false;
        DbManager::getServiceSubscriptionStatus(subscribed, token, serviceId);
        if(subscribed) {
            MECFCGI_LOG(ERR,
                "ME App[%s] has already subscribed to this service[%s].\n",
                appid.c_str(), serviceId.c_str());
            throw Exception(Exception::ALREADY_SUBSCRIBED);
        }

        // Get data schema from database.
        string dataSchema;
        DbManager::getActivatedServiceDataSchema(serviceId, dataSchema);
        Json::Reader reader;
        Json::Value serviceDataSchema;
        reader.parse(dataSchema, serviceDataSchema);
        
        DbManager::addServiceSubscription(token, serviceId);

        response["dataSchema"] = serviceDataSchema;
        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";

    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void UpdateSubscripion::execute(Json::Value &request, Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    try {
        string token, appid;
        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);

        Json::Value serviceList = request.get ("services","Nil");
        
        DbManager::StringArrayType subscribedServiceList;
        DbManager::getServiceSubscriptionListByToken(
            subscribedServiceList, token);
        
        if (subscribedServiceList.size() > 0) {
            for (string &subscribedService_ : subscribedServiceList) {
                string serviceId;
                istringstream ssSubscribedService(subscribedService_);
                getline(ssSubscribedService, serviceId, SPLIT_MARK);
                getline(ssSubscribedService, serviceId, SPLIT_MARK);
                getline(ssSubscribedService, serviceId);
                
                int size = serviceList.size();
                bool isUnsubscribe = true;
                for (int i = 0; i < size; i++){
                    string serviceId_ = serviceList[i].get(
                                        "serviceId", "Nil").asString();                    
                    if (0 == serviceId_.compare(serviceId)) {
                        isUnsubscribe = false;
                        break;
                    }
                }
                if (isUnsubscribe) {
                    bool isPass = false;
                    ServiceRegistryPort::checkPolicyForSubscriber(isPass,
                                    ServiceRegistryPort::ACTION_UNSUBSCRIPTION_SERVICE,
                                    appid, serviceId);
                    if (!isPass) {
                        MECFCGI_LOG(ERR, 
                            "ME App[%s] is not permitted to unsubscribe from the service[%s].\n", 
                            appid.c_str(), serviceId.c_str());
                        throw Exception(Exception::NO_PERMISSION);
                    }
                }
            }
        }
        // Check policy.
        bool isPass = false;
        ServiceRegistryPort::checkPolicyForSubscriber(isPass,
                    ServiceRegistryPort::ACTION_SUBSCRIPTION_SERVICE,
                    appid, serviceList);
        if (!isPass) {
            MECFCGI_LOG(ERR, 
                "ME App[%s] is not permitted to subscribe to the specified service(s).\n", 
                appid.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        int size = serviceList.size();
        for (int i = 0; i < size; i++){
            string serviceId_i = serviceList[i].get(
                "serviceId", "Nil").asString();
            for (int j = i + 1; j < size; j++){
                string serviceId_j = serviceList[j].get(
                    "serviceId", "Nil").asString();
                if (0 == serviceId_i.compare(serviceId_j)){
                    throw Exception(Exception::DUPLICATE_SUBSCRIPTION);   
                }
            }
        }
        for (int i = 0; i < size; i++){
            string serviceId = serviceList[i].get(
                "serviceId", "Nil").asString();
            // Get data schema from database.
            string dataSchema;
            DbManager::getActivatedServiceDataSchema(serviceId, dataSchema);
            Json::Reader reader;
            Json::Value serviceDataSchema;
            reader.parse(dataSchema, serviceDataSchema);
            serviceList[i]["dataSchema"] = serviceDataSchema;
        }
        DbManager::delServiceSubscriptionListByToken(token);
        DbManager::addServiceSubscription(token, serviceList);
        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
        response["services"]= serviceList;

    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }

}

void DelSubscripion::execute(map<string, string> params, Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    try {
        string token, appid;
        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);

        string serviceId = params["UUID"];
        // Check parameter.
        if (SERVICE_ID_LENGTH != strlen(serviceId.c_str())){
            MECFCGI_LOG(ERR, "[serviceId] is invalid.\n");
            throw Exception(Exception::INVALID_SERVICEID);
        }

        // Check policy.
        bool isPass = false;
        ServiceRegistryPort::checkPolicyForSubscriber(isPass,
                        ServiceRegistryPort::ACTION_UNSUBSCRIPTION_SERVICE,
                        appid, serviceId);
        if (!isPass) {
            MECFCGI_LOG(ERR, 
                "ME App[%s] is not permitted to unsubscribe from the service[%s].\n", 
                appid.c_str(), serviceId.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        bool subscribed = false;
        DbManager::getServiceSubscriptionStatus(subscribed, token, serviceId);
        if (!subscribed) {
            MECFCGI_LOG(ERR,
                "ME App[%s] has not subscribed to this service[%s].\n",
                appid.c_str(), serviceId.c_str());
            throw Exception(Exception::MISSING_SUBSCRIPTION);
        }
        DbManager::delSubscribedServiceByTokenAndServiceId(token, serviceId);
        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void ResetSubscripion::execute(map<string, string> params,
                                Json::Value &response,
                                map<string, string> &headers,
                                map<string, string> &cookies)
{
    try {
        string token, appid;
        SessionManager::checkSession(cookies, token);
        SessionManager::getAppidBySession(token, appid);

        // Check policy.
        DbManager::StringArrayType subscribedServiceList;
        DbManager::getServiceSubscriptionListByToken(
            subscribedServiceList, token);
        if(0 == subscribedServiceList.size()) {
            MECFCGI_LOG(ERR, "ME App[%s] has not subscribed to any service.\n",
                appid.c_str());
            throw Exception(Exception::NO_SUBSCRIPTION);
        }
        Json::Value serviceList = Json::Value(Json::arrayValue);
        for (string &subscribedService_ : subscribedServiceList) {
            Json::Value service;
            string serviceId;

            istringstream ssSubscribedService(subscribedService_);
            // MEASS:token:serviceId
            getline(ssSubscribedService, serviceId, SPLIT_MARK);     //MEASS
            getline(ssSubscribedService, serviceId, SPLIT_MARK);     //token
            getline(ssSubscribedService, serviceId);     //serviceId

            service["serviceId"] = serviceId;
            serviceList.append(service);
        }

        bool isPass = false;
        ServiceRegistryPort::checkPolicyForSubscriber(isPass,
                           ServiceRegistryPort::ACTION_UNSUBSCRIPTION_SERVICE,
                        appid, serviceList);
        if (!isPass) {
            MECFCGI_LOG(ERR,
                "ME App[%s] is not permitted to reset subscriptions.\n",
                appid.c_str());
            throw Exception(Exception::NO_PERMISSION);
        }

        DbManager::delServiceSubscriptionListByToken(token);
        headers["Status"] = HTTP_SC_OK;
        response["result"] = "OK";
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

