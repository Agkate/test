/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    LifeCycleSupport.h
 * @brief   Classes of handlers responsible for handling Mobile Edge Application
 *          Configuration and Termination.
 *
 *          <Mobile Edge Application Configuration>
 *          When an ME App/ME App Service is deployed, the ME Manager first
 *          request virtualization resources to instantiate the deployed
 *          application. Then it should send a Configuration Request
 *          containing the application's policy configuration to an ME Platform
 *          so that once the ME App/ME App Service reports to ME the platform
 *          that it is up and running the ME Platform may recognize the
 *          ME App/ME App Service.
 *          The ME Platform validates and stores the configuration information
 *          in the ME Manager�s request and then waits for the ME App
 *          instance�s live indicator.
 *          This is a mandatory API. The ME Manager cannot send an ME
 *          Application's configuration without using this API.
 *
 *          <Mobile Edge Application Termination>
 *          Before requesting the ME Platform to notify an ME App/ME App
 *          Service of termination, the ME Manager needs to have a WebSocket
 *          connection to the ME Platform.
 *          When the ME Manager marks an ME App for termination, the ME Manager
 *          first requests the ME Platform to notify the marked ME App of
 *          imminent termination. The ME Platform notifies the ME App via a
 *          WebSocket message, and then sets a timer. Either upon the ME App
 *          marked for termination sending a Termination Indicator or the timer
 *          expiring, the ME Platform clears the ME App's data and sends
 *          notification to the ME Manager so that it may terminate the ME App.
 *          This is a mandatory API. The ME Manager cannot signal an imminent
 *          termination to an ME Application without using this API.
 */

#ifndef __MECFCGI__LIFECYCLESUPPORT__
#define __MECFCGI__LIFECYCLESUPPORT__

#include "PostRequestHandler.h"
#include "DelRequestHandler.h"
#include <boost/thread.hpp>


class AppConfiguration : public PostRequestHandler
{
public:
    /**
    * @brief            Handles request that carries application's
    *                   policy configuration.
    * @param[in]        request     JSON-formatted request body.
    * @param[out]       response    JSON-formatted response body.
    * @param[out]       headers     Response headers, may contain a token on
    *                               authenticated success.
    * @param[in]        cookies     Not used here.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute (Json::Value &request, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

class AppTermination : public PostRequestHandler
{
public:
    /**
    * @brief            Handles request to inform ME App of imminent 
    *                   termination.
    * @param[in]        request     JSON-formatted request body.
    * @param[out]       response    JSON-formatted response body.
    * @param[out]       headers     Response headers.
    * @param[in]        cookies     Not used here.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute (Json::Value &request, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);

};

using namespace boost;

class TimeoutChecker
{
    thread worker;

public:
    map<string, uint32_t> timeoutMap;
    pthread_mutex_t listLock;
    TimeoutChecker(void);
    ~TimeoutChecker(void);
    typedef enum
    {
        STATE_RUNNING,
        STATE_STOPPED
    } STATE;
    STATE state;
    static TimeoutChecker &getInstance(void);

    /**
    * @brief        Starts a timeout watcher.
    * @return       void
    */
    void startTimeoutWatcher(void);
    
    /**
    * @brief        Gets timeout watcher thread's running status.
    * @return       Watcher thread running's status.
    */
    STATE getTimeoutWatcherStatus(void);
    
    /**
    * @brief        Sets a timeout value for ME App/ME App Service.
    * @param[in]    appid     ME App's ID.
    * @param[in]    timer     Timeout value.
    * @return       void
    */
    void setAppTimeoutValue(string appid, uint32_t timer);
 
    /**
    * @brief        Cleans a timeout value for given ME App/ME App Service.
    * @param[in]    appid     ME App's ID.
    * @return       void
    */
    void cleanAppTimeoutValue(string appid);

    /**
    * @brief        Finds an ME App/ME App Service's timeout status.
    * @param[out]   isFound   Indication of whether an ME App's timer is 
    *                         found.
    * @param[in]    appid     ME App's ID.
    * @return       void
    */
    void findAppTimeoutStatus(bool &isFound, string appid);
};

#endif //__MECFCGI__LIFECYCLESUPPORT__