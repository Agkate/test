/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file nes_dev_addons.c
* @brief Implementation of tabq
*/

#include <rte_config.h>
#include <rte_cycles.h>
#include <rte_ethdev.h>
#include <rte_ip.h>
#include <rte_log.h>
#include <rte_udp.h>
#include <rte_alarm.h>
#include <rte_malloc.h>
#include "ctrl/nes_ctrl.h"
#include "nes_common.h"
#include "nes_dev_addons.h"
#include "nes_io.h"

static nes_tabq_t devices_tab[NES_TABQ_MAX_ELEMENTS];
static nes_queue_t * nes_io_devices;

int nes_dev_tabq_init(void)
{
    memset(devices_tab, 0, sizeof(nes_tabq_t)*NES_TABQ_MAX_ELEMENTS);
    nes_io_dev_queue_get(&nes_io_devices);
    return NES_SUCCESS;
}

nes_dev_t *nes_dev_get_device_by_idx(int idx)
{
    if(NES_TABQ_MAX_ELEMENTS <= idx)
        return NULL;
    return (nes_dev_t *)devices_tab[idx].device;
}

inline nes_ring_t *nes_dev_get_egressring_from_port_idx(int idx)
{
    if(NES_TABQ_MAX_ELEMENTS <= idx)
        return NULL;
    if(unlikely(NULL == devices_tab[idx].device))
        return NULL;
    return (nes_ring_t *)devices_tab[idx].device->rx_default_ring;
}

int nes_dev_add_device(nes_dev_t *device)
{
    if( ETH == device->dev_type ) {
        int port_id = device->dev.eth.port_id;
        if( NES_TABQ_MAX_ELEMENTS <= port_id) {
            return NES_FAIL;
        }
        devices_tab[port_id].device = device;
        int i;
        /* get next valid device */
        for(i = port_id + 1; i < NES_TABQ_MAX_ELEMENTS; i++) {
            if( NULL != devices_tab[i].device ) {
                devices_tab[port_id].next_idx = i;
                break;
            }
        }
        for( i = port_id - 1; i >= 0; i-- ) {
            devices_tab[i].next_idx = port_id;
            if( NULL!=devices_tab[i].device )
                break;
        }
    }
    nes_ctrl_add_device(device, device->name);
    nes_queue_enqueue(nes_io_devices, device);
    return NES_SUCCESS;
}

int nes_dev_del_device(nes_dev_t *device)
{
    int port_id = device->dev.eth.port_id;
    nes_ctrl_del_device(device);
    if( ETH == device->dev_type ) {
        if( NES_TABQ_MAX_ELEMENTS <= port_id) {
            return NES_FAIL;
        }
        int i;
        devices_tab[port_id].device = NULL;
        /* get next valid device */
        for(i = port_id + 1; i < NES_TABQ_MAX_ELEMENTS; i++ ) {
            if( NULL != devices_tab[i].device )
                break;
        }
        if( NES_TABQ_MAX_ELEMENTS!=i ) {
            for( ; port_id >= 0; port_id-- ) {
                devices_tab[port_id].next_idx = i;
                if( NULL!=devices_tab[port_id].device )
                    break;
            }
        }
    }
    return NES_SUCCESS;
}
