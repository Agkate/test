#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

VM0_CFG_MAC="52:54:00:00:00:01"
VM1_CFG_MAC="52:54:00:00:00:02"
VM2_CFG_MAC="52:54:00:00:00:03"
VM3_CFG_MAC="52:54:00:00:00:04"
CURRENT_PATH=${PWD}/script

function is_windriver()
{
    IS_WR=`cat /etc/*-release | grep -c "Wind River Linux"`
    if [ "$IS_WR" -ne 0 ]; then
        #echo "Windriver platform detected"
        return 1
    else
        #echo "SW Only platform detected"
        return 2
    fi
}

function is_running()
{
    is_windriver
    test $? = 1 && {
        nova show vm$1  | grep tenant-mgmt-net |grep -oE "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b"
        test $? = 0 && return 1 || return 2
    } || {
        case $1 in
        "0" ) CFG_MAC=$VM0_CFG_MAC ;;
        "1" ) CFG_MAC=$VM1_CFG_MAC ;;
        "2" ) CFG_MAC=$VM2_CFG_MAC ;;
        "3" ) CFG_MAC=$VM3_CFG_MAC ;;
        *)
        {
            echo "ERROR VM Num:$1"
            exit -1
        }
        ;;
        esac
        ps -ef |grep qemu | grep mac=$CFG_MAC > /dev/null
        test $?x = "0"x && return 1 || return 2
    }
}

function start_vm()
{
    is_windriver
    test $? = 1 && {
        $CURRENT_PATH/start_vm_wr.sh $1 $2
        test $? = 0 && return 1 || return 2
    } || {
        $CURRENT_PATH/start_vm_centos.sh $1 $2
        test $? = 0 && return 1 || return 2
    }
}

function stop_vm()
{
    is_windriver
    test $? = 1 && {
        nova delete vm$1
        test $? = 0 && return 1 || return 2
    } || {
        case $1 in
        "0" ) CFG_MAC=$VM0_CFG_MAC ;;
        "1" ) CFG_MAC=$VM1_CFG_MAC ;;
        "2" ) CFG_MAC=$VM2_CFG_MAC ;;
        "3" ) CFG_MAC=$VM3_CFG_MAC ;;
        *)
        {
            echo "ERROR VM Num:$1"
            exit -1
        }
        ;;
        esac
        VM_PID=$(ps -ef |grep qemu | grep mac=$CFG_MAC | awk '{print $2}')
        kill $VM_PID
        test $?x = "0"x && exit 0 || exit -1
    }
}

case $1 in
"is_wr" ) is_windriver 
        test $? = 1 && exit 0 || exit -1;;
"start_vm" ) start_vm $2 $3
        test $? = 1 && exit 0 || exit -1;;
"stop_vm" ) stop_vm $2
        test $? = 1 && exit 0 || exit -1;;
"is_running" ) is_running $2
        test $? = 1 && exit 0 || exit -1;;
*)
{
    echo "ERROR Command:$1"
    exit -1
}
;;
esac

exit 0