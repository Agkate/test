#!/usr/bin/env python

###################################################################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
###################################################################################################

# Standard library imports:
import argparse
import logging
import os
import socket
import tempfile

# Third party imports:
import AWSIoTPythonSDK.MQTTLib
import AWSIoTPythonSDK.core.greengrass.discovery.providers
import AWSIoTPythonSDK.core.protocol.connection.cores
import AWSIoTPythonSDK.exception.AWSIoTExceptions

_LOG = logging.getLogger('ggmec')

def make_common_parser():
    subscribe_opt = "--subscribe"
    publish_opt = "--publish"

    log_levels = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
    levels_str = "{0:s} or {1:s}".format(", ".join(log_levels[:-1]), log_levels[-1])
    cert_file = "device.crt"
    pkey_file = "device.key"
    root_file = "root-ca-cert.pem"

    parser = argparse.ArgumentParser()
    parser.topic_opt_name = "--topic"
    parser.default_subscribe_topic="mec/route"

    parser.add_argument(
        "-v", "--verbosity", action="store", metavar="LEVEL", dest="verbosity", default="ERROR",
        choices=log_levels,
        help="Application diagnostic output verbosity ({0:s})".format(levels_str))
    parser.add_argument(
        "--certificate", action="store", metavar="PATH", dest="cert_file", default=cert_file,
        help=("End device (local) certificate file PATH to be used for establishment of secure"
              " connection with the IoT Core (default: {0:s})".format(cert_file)))
    parser.add_argument(
        "--private-key", action="store", metavar="PATH", dest="pkey_file", default=pkey_file,
        help=("End device (local) private key file PATH to be used for establishment of secure"
              " connection with the IoT Core (default: {0:s})".format(pkey_file)))
    parser.add_argument(
        "--root-ca", action="store", metavar="PATH", dest="root_ca_path", default=root_file,
        help="Root CA file PATH. This certificate is supposed to verify the IoT core certificate")
    parser.add_argument(
        "--client-id", action="store", metavar="ID", dest="client_id", default="ggmec",
        help="Unique MQTT client id")
    parser.add_argument(
        parser.topic_opt_name, action="store", metavar="ID", dest="topic", default="ggmec",
        help="ID of topic to publish the MQQT payload to")
    parser.add_argument(
        "--core-arn", action="store", metavar="ID", dest="core_arn", default="ggmec_arn",
        help="Core ARN identifier")

    parser.add_argument(
        "-s", subscribe_opt, action="store_true", dest="subscribe_flag", default=False,
        help=(
            "Flag indicating that the script should SUBSCRIBE to the '{0:s}' topic (can be mixed"
            " with {1:s} option)"
            "".format(parser.default_subscribe_topic, publish_opt)))
    parser.add_argument(
        "-p", publish_opt, action="store_true", dest="publish_flag", default=False,
        help=(
            "Flag indicating that the script should PUBLISH to the topic specified by the"
            " {0:s} option (can be mixed with {1:s} option)"
            "".format(parser.topic_opt_name, subscribe_opt)))

    parser.add_argument(
        "endpoint", action="store", metavar="HOST",
        help="IoT Core (local or cloud) HOST name or IP address")
    return parser


def make_thing_parser():
    parser = make_common_parser()
    parser.add_argument(
        "--thing", action="store", metavar="NAME", dest="thing_name", default="Bot",
        help="Targeted thing name")
    return parser


def setup_logger(options):
    log_fmt = "[%(levelname)s] %(module)s(%(lineno)d): %(message)s"
    ts_fmt = "%Y-%m-%dT%H:%M:%S"

    handler = logging.StreamHandler() # Will write to stderr
    handler.setFormatter(
        logging.Formatter(log_fmt, ts_fmt))
    root_logger = logging.getLogger('')
    root_logger.addHandler(handler)
    root_logger.setLevel(options.verbosity)
    return root_logger


def setup_mqtt_client(options):
    client = AWSIoTPythonSDK.MQTTLib.AWSIoTMQTTClient(options.client_id)
    client.configureEndpoint(options.endpoint, 8883)
    client.configureCredentials(options.root_ca_path, options.pkey_file, options.cert_file)
    client.configureAutoReconnectBackoffTime(1, 32, 20)
    client.configureOfflinePublishQueueing(-1)  # infinite
    client.configureDrainingFrequency(2)  # 2 [Hz]
    client.configureConnectDisconnectTimeout(10)  # 10 [s]
    client.configureMQTTOperationTimeout(5)  # 5 [s]
    return client


def setup_mqtt_shadow_client(options, endpoint, root_ca_path):
    client = AWSIoTPythonSDK.MQTTLib.AWSIoTMQTTShadowClient(options.client_id)
    client.configureEndpoint(endpoint, 8883)
    client.configureCredentials(root_ca_path, options.pkey_file, options.cert_file)

    client.configureAutoReconnectBackoffTime(1, 32, 20)
    client.configureConnectDisconnectTimeout(10)  # 10 [s]
    client.configureMQTTOperationTimeout(5)  # 5 [s]
    return client


def discover_ggc(options):
    di_provider = AWSIoTPythonSDK.core.greengrass.discovery.providers.DiscoveryInfoProvider()
    di_provider.configureEndpoint(options.endpoint)
    di_provider.configureCredentials(options.root_ca_path, options.cert_file, options.pkey_file)
    di_provider.configureTimeout(10)

    try:
        discovery_info = di_provider.discover(options.client_id)
    except AWSIoTPythonSDK.exception.AWSIoTExceptions.DiscoveryDataNotFoundException as e:
        _LOG.info(e, "No discovery data found. Check if client ID is correct")
        return None
    except AWSIoTPythonSDK.exception.AWSIoTExceptions.DiscoveryInvalidRequestException as e:
        _LOG.info(e)
        return None
    except BaseException as e:
        _LOG.info(e,"Error in discovery!")
        return None

    group_info = discovery_info.toObjectAtGroupLevel()
    group_id = list(group_info.keys())[0]
    group = group_info[group_id]

    if len(group_info) > 1:
        _LOG.info("Found more than 1 group!")
    else:
        _LOG.info("Found group with ID: {0:s}".format(group_id))

    core = group.getCoreConnectivityInfo(options.core_arn)
    if core == None:
        _LOG.error("Core is not found. Check Core ARN identifier")
        return None

    connectivityInfoList = core.connectivityInfoList

    if len(connectivityInfoList) == 0:
        _LOG.error("No connection info found!")
        return None
    elif len(connectivityInfoList) == 1:
        _LOG.info("Found host: {0:s} : {1:d}".format(connectivityInfoList[0].host, connectivityInfoList[0].port))
    else:
        _LOG.info("Found more than one connectivity info! Using the first one.")
        for connectInfo in connectivityInfoList:
            _LOG.info("Found host: {0:s} : {1:d}".format(connectInfo.host, connectInfo.port))

    return {"host": connectivityInfoList[0].host, "port": connectivityInfoList[0].port, "ca": group.caList}

def retrieve_ggc_conf(options):
    ggc_conf = discover_ggc(options)

    if ggc_conf is not None:

        _LOG.info("Successfully discovered GG Core")

        temp_file = tempfile.NamedTemporaryFile(delete=False)
        with open(temp_file.name, 'w') as f:
            f.write('\n'.join(ggc_conf['ca']))

        ca_file = temp_file.name
        ggc_conf['path'] = ca_file
        return ggc_conf
    else:
        _LOG.critical("Failed to discover GG Core")

        return None



