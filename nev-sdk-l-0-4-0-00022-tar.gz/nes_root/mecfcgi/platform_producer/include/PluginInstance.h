/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  PluginInstance.h
* @brief Abstract parent class of Plug-ins parent class ,instantiates a plugin.
*/

#ifndef __PLUGIN_INSTANCE__
#define __PLUGIN_INSTANCE__

#include "Plugin.h"

using namespace std;
class PluginInstance
{
public:
    explicit PluginInstance(const string &pluginName, IPluginManager* pluginMng);
    virtual ~PluginInstance(void);


    /**
    * @brief        Enables the PluginManager to start start a plug-in.
    * @return       true on success and false on failure.
    */
    virtual bool start() = 0;

    /**
    * @brief        Enables the PluginManager to stop a plug-in
    * @return       true on success and false on failure.
    */
    virtual bool stop() = 0;

    /**
    * @brief        Enables a PluginManager to a plug-in's file name.
    * @return       Plug-in's file name.
    */
    virtual string getFileName() const = 0;

    /**
    * @brief        Enables a PluginManager to get a plug-in's service 
    *               activation information;
    * @return       Plug-in's service activation info.
    */
    virtual string getServiceActivationInfo() const = 0;

private:
    PluginInstance(const PluginInstance &pluginInstance);
    const PluginInstance &operator = (const PluginInstance &pluginInstance);
    IPluginManager* pPluginManager;
};



#endif // __PLUGIN_INSTANCE__