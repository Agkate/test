/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file main.cpp
 * @brief Implementation of Main
*/

#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include "Log.h"
#include "ConfigManager.h"
#include "FcgiBackend.h"
#include "DbManager.h"
#include "NesPortFactory.h"
#include "WebSocketServer.h"
#include "ServiceRegistryPort.h"
#include "RawRequest.h"
#include "LifeCycleManager.h"
#include "ServiceManager.h"
#include "SubscribeManager.h"
#include "ServiceDataManager.h"
#include "TrafficManager.h"
#include "LifeCycleSupport.h"
#include "HttpsMaster.h"

using namespace std;

int init(int argc, char *argv[])
{
    // Init mecfcgi log
    mecfcgiLogInit();

    // Load config file
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::openConfigFile(argv[1])){
        MECFCGI_LOG(ERR, "Could not open config file %s. \n", argv[1]);
        return -1;
    }

    // Init FastCGI backend
    string hostIp;
    string hostPort;
    string fastcgiPass;
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("NGINX", "host_ip", hostIp)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "NGINX", "host_ip");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("NGINX", "host_port", hostPort)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "NGINX", "host_port");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("NGINX", "fastcgi_pass", fastcgiPass)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "NGINX", "fastcgi_pass");
        ConfigManager::closeConfigFile();
        return -1;
    }
    FcgiBackend::setNginxInfo(hostIp, uint16_t(atoi((char *)hostPort.c_str())), fastcgiPass);

    // Init Websocket
    string websocketPort = "";
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("WEB_SOCKET", "websocket_port", websocketPort)){
        MECFCGI_LOG(ERR, "Websocket port not found in config file. \n");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (0 != startWebSocketServer(hostIp, uint16_t(atoi((char *)websocketPort.c_str())))) {
        MECFCGI_LOG(ERR, "WebSocket init failed");
        return -1;
    }

    // Init ServiceRegistry
    string ServiceRegistryIp;
    string ServiceRegistryPort;
    string NginxCrtPath;
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("SERVICE_REGISTRY", "host_ip", ServiceRegistryIp)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "SERVICEREGISTRY", "host_ip");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("SERVICE_REGISTRY", "host_port", ServiceRegistryPort)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "SERVICEREGISTRY", "host_port");
        ConfigManager::closeConfigFile();
        return -1;
    }
    ServiceRegistryPort::setServiceRegistryInfo(ServiceRegistryIp, uint16_t(atoi((char *)ServiceRegistryPort.c_str())));
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("NGINX", "crt_path", NginxCrtPath)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "NGINX", "crt_path");
        ConfigManager::closeConfigFile();
        return -1;
    }
    HttpsMaster::setVerifCertPath(NginxCrtPath);


    // Init redis
    string redisIp = "";
    string redisPort = "";
    string password = "";
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("REDIS", "host_ip", redisIp)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "REDIS", "host_ip");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("REDIS", "host_port", redisPort)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "REDIS", "host_port");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("REDIS", "password", password) ||
        0 == password.compare("")){
        MECFCGI_LOG(ERR, "Redis password not found in config file. \n");
        ConfigManager::closeConfigFile();
        return -1;
    }
    Redis::setRedisInfo(redisIp, uint16_t(atoi((char *)redisPort.c_str())), password);

    // Init Platform producer app
    string appid = "";
    string secret = "";
    if (ConfigManager::CFGFILE_SUCCESS !=
        ConfigManager::getConfigData("PLATFORM_PRODUCER", "appid", appid)){
        MECFCGI_LOG(WARNING, "PLATFORM_PRODUCER appid not found in config file. \n");
    } else {
        if (ConfigManager::CFGFILE_SUCCESS !=
            ConfigManager::getConfigData("PLATFORM_PRODUCER", "secret", secret)){
            MECFCGI_LOG(WARNING, "PLATFORM_PRODUCER appid not found in config file. \n");
            secret = "";
        }
        ServiceRegistryPort::setPlatformProducerAppInfo(appid, secret);
    }
    ConfigManager::closeConfigFile();

    return 0;
}
void registerRESTfulAPI(RawRequest &raw)
{

    // MP1 RESTful API
    AppLiveIndicator appLiveIndicator;
    AppTerminationIndicator appTerminationIndicator;
    ServiceActivation serviceActivation;
    ServiceDeactivation serviceDeactivation;
    ServiceDiscovery serviceDiscovery;
    AddSubscription addSubscribe;
    UpdateSubscripion updateSubscribe;
    DelSubscripion delSubscribe;
    ResetSubscripion delAllSubscribe;
    ServiceDataUpdate serviceDataUpdate;
    CreateTrafficRule createTrafficRule;
    UpdateTrafficRule updateTrafficRule;
    RemoveTrafficRule removeTrafficRule;

    raw.postDispatcher.registerHandler("appliance/v1/live_apps", appLiveIndicator);
    raw.delDispatcher.registerHandler("appliance/v1/live_apps", appTerminationIndicator);
    raw.postDispatcher.registerHandler("appliance/v1/service", serviceActivation);
    raw.delDispatcher.registerHandler("appliance/v1/service/UUID", serviceDeactivation);
    raw.getDispatcher.registerHandler("appliance/v1/service", serviceDiscovery);
    raw.getDispatcher.registerHandler("appliance/v1/subscriptions/UUID", addSubscribe);
    raw.putDispatcher.registerHandler("appliance/v1/subscriptions", updateSubscribe);
    raw.delDispatcher.registerHandler("appliance/v1/subscriptions/UUID", delSubscribe);
    raw.delDispatcher.registerHandler("appliance/v1/subscriptions", delAllSubscribe);
    raw.postDispatcher.registerHandler("appliance/v1/notifications", serviceDataUpdate);
    raw.postDispatcher.registerHandler("appliance/v1/traffic", createTrafficRule);
    raw.putDispatcher.registerHandler("appliance/v1/traffic/UUID", updateTrafficRule);
    raw.delDispatcher.registerHandler("appliance/v1/traffic/UUID", removeTrafficRule);

    // MM5 RESTful API
    AppConfiguration appConfiguration;
    AppTermination appTermination;

    raw.postDispatcher.registerHandler("appliance/v1/configuration", appConfiguration);
    raw.postDispatcher.registerHandler("appliance/v1/termination", appTermination);
}
void handle_signals(int signal) {
    if (SIGTERM == signal) {
        MECFCGI_LOG(INFO, "SIGTERM SIGINT, exiting now\n");
        NesPortFactory::getInstance().stopNesPortWatcher();
        exit(0);
    }
}
int main(int argc, char *argv[])
{
    struct sigaction act;
    act.sa_handler = &handle_signals;
    act.sa_flags = 0;
    act.sa_flags |= SA_RESTART;
    sigfillset(&act.sa_mask);
    if (sigaction(SIGTERM, &act, NULL) == -1) {
        cerr<<"Cannot handle SIGTERM"<<endl;
        return -1;
    }

    if (0 != init(argc, argv)){
        return -1;
    }

    NesPortFactory::getInstance().startNesPortWatcher();

    RawRequest raw ("/");
    registerRESTfulAPI(raw);
    FcgiBackend::run(raw);

    return 0;

}