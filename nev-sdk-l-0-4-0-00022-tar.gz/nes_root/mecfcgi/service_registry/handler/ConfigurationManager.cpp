/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file     MecSubscribe.cpp
* @brief    ME App/ME App Service Configuration Management handlers 
*           implementaitons.
*/

#include "ConfigurationManager.h"
#include "PasswordHash.h"
#include "Exception.h"
#include "DbManager.h"
#include "Log.h"
#include "HandlerCommon.h"
#include "RawRequest.h"

/**
 * @brief       Checks format of providable service list.
 * @param[out]  result                  Status returned by API.
 * @param[in]   providableServices      A set of ME services that an ME App 
 *                                      Service wishes to provide. 
 * @return      void
 */
void checkProvidableServicesFormat(string &result,
                                    Json::Value providableServices);

/**
 * @brief       Checks format of subscribable service list.
 * @param[out]  result                  Status returned by API.
 * @param[in]   subscribableServices    A set of ME services that an ME App
                                        may subscribe to.
 * @return      void
 */
void checkSubscribableServicesFormat(string &result,
                                        Json::Value subscribableServices);

/**
 * @brief       Checks format of settable traffic rule list.
 * @param[out]  result                  Status returned by API.
 * @param[in]   settableTrafficRules    A set of traffic rules that an 
                                        ME App/ME App Service may set.
 * @return      void
 */
void checkSettableTrafficRulesFormat(string &result,
                                        Json::Value settableTrafficRules);

/**
 * @brief       Saves providable service list.
 * @param[out]  appid                   A unique string obtained from the ME 
                                        Manager for the authentication of an 
                                        ME App/ME App Service/ME Child App.
 * @param[in]   providableServices      A set of ME services that an ME App 
                                        Service wishes to provide. 
 * @return      void
 */
void saveProvidableServices(string appid, Json::Value providableServices);
/**
 * @brief       Saves subscribable service list.
 * @param[out]  appid                   A unique string obtained from the ME 
                                        Manager for the authentication of an 
                                        ME App/ME App Service/ME Child App.
 * @param[in]   subscribableServices    A set of ME services that an ME App
                                        may subscribe to.
 * @return      void
 */
void saveSubscribableServices(string appid, Json::Value subscribableServices);
/**
 * @brief       Saves settable traffic rule list.
 * @param[out]  appid                   A unique string obtained from the ME 
                                        Manager for the authentication of an 
                                        ME App/ME App Service/ME Child App.
 * @param[in]   settableTrafficRules    A set of traffic rules that an 
                                        ME App/ME App Service may set.
 * @return      void
 */
void saveSettableTrafficRules(string appid, Json::Value settableTrafficRules);

void SaveMeAppConfiguration::execute(Json::Value &request,
                                        Json::Value &response,
                                        map<string, string> &headers,
                                        map<string, string> &cookies)
{
    string result;
    try {
        string appid = request.get("appid", "Nil").asString();
        string secret = request.get("secret", "Nil").asString();
        string secretHash;
        Json::Value providableServices;
        Json::Value subscribableServices;
        Json::Value settableTrafficRules;

        // Parameter Check
        if (0 == appid.compare("Nil")) {
            MECFCGI_LOG(ERR, "[appid] is not found in request.\n");
            throw Exception(Exception::INVALID_APPID);
        }
        if (0 == secret.compare("Nil")) {
            MECFCGI_LOG(ERR,  "[secret] is not found in request.\n");
            throw Exception(Exception::INVALID_SECRET);
        }

        if (request.isMember("providableServices")) {
            providableServices = request["providableServices"];
            checkProvidableServicesFormat(result, providableServices);
            if (0 != result.compare("OK")) {
                MECFCGI_LOG(ERR,  "Providable service list is invalid.\n");
                throw Exception(Exception::INVALID_PROVIDABLESERVICES);
            }
        }
        if (request.isMember("subscribableServices")) {
            subscribableServices = request["subscribableServices"];
            checkSubscribableServicesFormat(result, subscribableServices);
            if (0 != result.compare("OK")) {
                MECFCGI_LOG(ERR,  "Subscribable service list is invalid.\n");
                throw Exception(Exception::INVALID_SUBSCRIBABLESERVICES);
            }
        }
        if (request.isMember("settableTrafficRules")) {
            settableTrafficRules = request["settableTrafficRules"];
            checkSettableTrafficRulesFormat(result, settableTrafficRules);
            if (0 != result.compare("OK")) {
                MECFCGI_LOG(ERR, "Settable traffic rule list is invalid.\n");
                throw Exception(Exception::INVALID_SETTABLETRAFFICRULES);
            }
        }

        // Save configuration to database.
        DbManager::removeMeAppConfiguration(appid);
        if (!PasswordHash::hash(secret, secretHash)) {
            MECFCGI_LOG(ERR,  "Failed to generate hash for secret\n");
            throw Exception(Exception::INVALID_SECRET);
        }

        DbManager::saveMeAppInfo(appid, secretHash);
        if (request.isMember("providableServices")) {
            saveProvidableServices(appid, providableServices);
        }
        if (request.isMember("subscribableServices")) {
            saveSubscribableServices(appid, subscribableServices);
        }
        if (request.isMember("settableTrafficRules")) {
            saveSettableTrafficRules(appid, settableTrafficRules);
        }

        response["result"] = "OK";
        headers["Status"] = HTTP_SC_OK;
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void RemoveMeAppConfiguration::execute(map<string, string> params,
                                        Json::Value &response,
                                        map<string, string> &headers,
                                        map<string, string> &cookies)
{
    try {
        string appid = params["UUID"];
        // Parameter Check
        if (0 == appid.compare("")) {
            MECFCGI_LOG(ERR, "[appid] is not found in request.\n");
            throw Exception(Exception::INVALID_APPID);
        }
        DbManager::removeMeAppConfiguration(appid);
        response["result"] = "OK";
        headers["Status"] = HTTP_SC_OK;
    }
    catch (Exception &e) {
        string res;
        string statusCode;
        Exception::handlerException(e, res, statusCode);
        headers["Status"] = statusCode;
        response["result"] = res;
    }
}

void checkProvidableServicesFormat(string &result,
                                    Json::Value providableServices)
{
    int size = providableServices.size();
    result = "InvalidProvidableServices";
    for (int i = 0; i < size; i++) {
        // Check field serviceName
        if (!providableServices[i].isMember("serviceName")) {
            MECFCGI_LOG(ERR,
                "Field serviceName is missing from ProvidableServiceList.\n");
            return;
        }
        // Check field isDeactivationPermited
        if (!providableServices[i].isMember("isDeactivationPermited")) {
            MECFCGI_LOG(ERR, "Field isDeactivationPermited is missing from \
                ProvidableServiceList.\n");
            return;
        }
        string isDeactivationPermited =
            providableServices[i]["isDeactivationPermited"].asString();
        if ((0 != isDeactivationPermited.compare("YES")) &&
            (0 != isDeactivationPermited.compare("NO"))) {
            MECFCGI_LOG(ERR,
                "Value of field isDeactivationPermited is incorrect. \n");
            return;
        }
    }
    result = "OK";
}

void checkSubscribableServicesFormat(string &result,
                                        Json::Value subscribableServices)
{
    int size = subscribableServices.size();
    result = "InvalidSubscribableServices";
    for (int i = 0; i < size; i++) {
        // Check field serviceName
        if (!subscribableServices[i].isMember("serviceName")) {
            MECFCGI_LOG(ERR,
                "Field serviceName is missing from SubscribableServiceList.\n");
            return;
        }
        // Check field providerAppId
        if (!subscribableServices[i].isMember("providerAppId")) {
            MECFCGI_LOG(ERR,
              "Field providerAppId is missing from SubscribableServiceList.\n");
            return;
        }
        // Check field required
        if (!subscribableServices[i].isMember("required")) {
            MECFCGI_LOG(ERR,
                "Field required is missing from SubscribableServiceList.\n");
            return;
        }
        string required = subscribableServices[i]["required"].asString();
        if ((0 != required.compare("YES")) && (0 != required.compare("NO"))) {
            MECFCGI_LOG(ERR, "Value of field required is incorrect. \n");
            return;
        }
        // Check field isUnsubscriptionPermitted
        if (!subscribableServices[i].isMember("isUnsubscriptionPermitted")) {
            MECFCGI_LOG(ERR, "Field isUnsubscriptionPermitted is missing from \
                SubscribableServiceList.\n");
            return;
        }
        string isUnsubscriptionPermitted =
            subscribableServices[i]["isUnsubscriptionPermitted"].asString();
        if ((0 != isUnsubscriptionPermitted.compare("YES")) &&
            (0 != isUnsubscriptionPermitted.compare("NO"))) {
            MECFCGI_LOG(ERR,
                "Value of isUnsubscriptionPermitted is incorrect. \n");
            return;
        }
    }
    result = "OK";
}

void checkSettableTrafficRulesFormat(string &result,
                                        Json::Value settableTrafficRules)
{
    int size = settableTrafficRules.size();
    result = "InvalidSettableTrafficRules";
    for (int i = 0; i < size; i++) {
        string res = "";
        HandlerCommon::checkTrafficRuleFormat(res, settableTrafficRules[i]);
        if (0 != res.compare("OK")) {
            return;
        }
        string isUpdatePermitted =
            settableTrafficRules[i]["isUpdatePermitted"].asString();
        if ((0 != isUpdatePermitted.compare("YES")) &&
            (0 != isUpdatePermitted.compare("NO"))) {
            MECFCGI_LOG(ERR,
                "Value of field isRemovalPermitted is incorrect. \n");
            return;
        }
        string isRemovalPermitted =
            settableTrafficRules[i]["isRemovalPermitted"].asString();
        if ((0 != isRemovalPermitted.compare("YES")) &&
            (0 != isRemovalPermitted.compare("NO"))) {
            MECFCGI_LOG(ERR,
                "Value of field isRemovalPermitted is incorrect. \n");
            return;
        }
    }
    result = "OK";
}

void saveProvidableServices(string appid, Json::Value providableServices)
{
    int size = providableServices.size();
    for (int i = 0; i < size; i++) {
        string serviceName = providableServices[i]["serviceName"].asString();
        string isDeactivationPermited =
            providableServices[i]["isDeactivationPermited"].asString();
        DbManager::saveProvidableServices(appid, serviceName,
            isDeactivationPermited);
    }
}

void saveSubscribableServices(string appid, Json::Value subscribableServices)
{
    int size = subscribableServices.size();
    for (int i = 0; i < size; i++) {
        string serviceName = subscribableServices[i]["serviceName"].asString();
        string providerAppId =
            subscribableServices[i]["providerAppId"].asString();
        string required = subscribableServices[i]["required"].asString();
        string isUnsubscriptionPermitted =
            subscribableServices[i]["isUnsubscriptionPermitted"].asString();
        DbManager::saveSubscribableServices(appid, serviceName, providerAppId,
                                            required,
                                            isUnsubscriptionPermitted);
    }
}

void saveSettableTrafficRules(string appid, Json::Value settableTrafficRules)
{
    int size = settableTrafficRules.size();
    for (int i = 0; i < size; i++) {
        Json::FastWriter writer;
        string trafficRule = writer.write(settableTrafficRules[i]);
        string isUpdatePermitted =
            settableTrafficRules[i]["isUpdatePermitted"].asString();
        string isRemovalPermitted =
            settableTrafficRules[i]["isRemovalPermitted"].asString();
        DbManager::saveSettableTrafficRules(appid, trafficRule,
            isUpdatePermitted, isRemovalPermitted);
    }
}
