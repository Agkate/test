/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file nis_routing_data.c
 * @brief Implementation of nis routing data
 */

#include "libnes_lookup.h"
#include "nis_routing_data.h"
#include "nes_capacity.h"

NES_STATIC nes_lookup_table_t *nis_routing_data_table;

int
nis_routing_data_get(const nis_routing_data_key_t *key, nis_routing_data_t **data) {
    assert(nis_routing_data_table);

    if (NULL == key || NULL == data) {
        return NES_FAIL;
    }
    return nes_lookup_entry_find(nis_routing_data_table, key, (void**) data);
}

int
nis_routing_data_init(void) {
    if (NULL != nis_routing_data_table) {
        return NES_FAIL;
    }

    struct nes_lookup_params_s lookup_table_params = {
        .name = "nis_routing_data_table",
        /* Double the exact maximum size to avoid hash conflicts */
        .number_of_entries = 2 * NES_MAX_RB,
        .key_len = sizeof (nis_routing_data_key_t),
        .entry_len = sizeof (nis_routing_data_t)
    };
    nis_routing_data_table = rte_malloc("Routing data lookup table", sizeof (nes_lookup_table_t), 0);
    if (NULL == nis_routing_data_table) {
        NES_LOG(ERR, "Failed to allocate routing data lookup table\n");
        return NES_FAIL;
    }
    if (NES_SUCCESS != nes_lookup_ctor(nis_routing_data_table, &lookup_table_params)) {
        NES_LOG(ERR, "Failed to create routing data lookup table\n");
        return NES_FAIL;
    }
    return NES_SUCCESS;
}

void
nis_routing_data_dtor(void) {
    assert(nis_routing_data_table);

    nes_lookup_dtor(nis_routing_data_table);
    rte_free(nis_routing_data_table);
    nis_routing_data_table = NULL;
}

int
nis_routing_data_add(const nis_routing_data_key_t *key, nis_routing_data_t *data) {
    assert(nis_routing_data_table);

    nis_routing_data_t *entry = NULL;

    if (NULL == key || NULL == data) {
        return NES_FAIL;
    }
    nes_lookup_entry_find(nis_routing_data_table, key, (void**) &entry);
    if (NULL == entry) {
        return nes_lookup_entry_add(nis_routing_data_table, key, data);
    } else {
        rte_memcpy(entry, data, sizeof (nis_routing_data_t));
    }
    return NES_SUCCESS;
}

int
nis_routing_data_del(const nis_routing_data_key_t *key) {
    assert(nis_routing_data_table);
    
    if (NULL == key) {
        return NES_FAIL;
    }
    return nes_lookup_entry_del(nis_routing_data_table, key);
}

