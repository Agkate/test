#!/usr/bin/env python

###################################################################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
###################################################################################################

# Standard library imports:
import itertools
import json
import os
import signal
import sys
import time

# GG/MEC imports:
from ggmec import make_thing_parser, setup_logger, setup_mqtt_shadow_client, retrieve_ggc_conf


def shadow_update_cb(payload, responseStatus, token):
    if responseStatus == "timeout":
        _LOG.info("Update request {0:s} time out".format(token))
    elif responseStatus == "accepted":
        data = json.loads(payload)
        _LOG.info(
            "Update request with token {0:s} accepted (property='{1:s}')"
            "".format(token, data["state"]["desired"]["property"]))
    elif responseStatus == "rejected":
        _LOG.info("Update request {0:s} rejected".format(token))


def main(options):
    ggc_conf = retrieve_ggc_conf(options)

    if ggc_conf is None:
        _LOG.critical("Failed to retrieve GG Core configuration")
        return 1
    else:
        _LOG.info("GG Core address: {0:s}".format(ggc_conf['host']))

    client = setup_mqtt_shadow_client(options, ggc_conf['host'], ggc_conf['path'])

    if not client.connect():
        _LOG.critical("AWS IoT connection failed")
        return 2
    else:
        _LOG.debug("AWS IoT connection established successfully")

    handler = client.createShadowHandlerWithName(options.thing_name, True)

    loop_cnt = 0
    states = ['State #1','State #2','State #3', 'State #4']
    pool = itertools.cycle(states)
    for state in pool:
        data = {
            "state": {
                "desired": {
                    "property": "{0:s}   loop count: {1:d}".format(state, loop_cnt)
                }
            }
        }
        payload = json.dumps(data)

        _LOG.debug("Payload: {0:s}".format(payload))

        handler.shadowUpdate(payload, shadow_update_cb, 5)
        loop_cnt += 1
        time.sleep(1)

    return 0

if __name__ == '__main__':
    options = make_thing_parser().parse_args()
    _LOG = setup_logger(options)
    sys.exit(main(options))
