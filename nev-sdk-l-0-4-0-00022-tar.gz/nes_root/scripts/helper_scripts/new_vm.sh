#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

#Perform Openstack configuration, start NEV, create VM with nova, connect to VM
ssh  root@$COMPUTE_IP "$NES_DIR/nes-daemon-demo &>nes.log &"
#ssh -f root@$COMPUTE_IP "/opt/intel/nev_sdk/nes_root/scripts/nes-daemon-demo &>nes.log &"

#exit 1
echo "Create networks"
neutron net-create --provider:physical_network=${PHYSNET2} --provider:network_type=vlan --provider:segmentation_id=401 ${MGMT_NET}
sleep .5
neutron subnet-create --name ${MGMT_SUBNET} --gateway 192.168.100.1 ${MGMT_NET} 192.168.100.0/24
sleep .5
neutron net-create --provider:physical_network=${PHYSNET1} --provider:network_type=flat  ${TENANT_NET1}
neutron subnet-create --name ${TENANT_SUBNET1} --gateway 192.168.1.1 ${TENANT_NET1} --disable-dhcp 192.168.1.0/24
sleep .5
neutron net-create --provider:physical_network=${PHYSNET2} --provider:network_type=flat ${TENANT_NET2}
neutron subnet-create --name ${TENANT_SUBNET2} --gateway 192.168.2.1 ${TENANT_NET2} --disable-dhcp 192.168.2.0/24
sleep .5
#neutron net-create ${MY_PUBLIC} --router:external=True
#neutron subnet-create ${MY_PUBLIC} 192.168.100.0/24 --name ${MY_PUBLIC_SUB} --enable_dhcp=False --allocation-pool start=192.168.100.99,end=192.168.100.99 --gateway=192.168.100.4

sleep 3

neutron router-create ${PUBLICROUTER}
public_router_UUID=`neutron router-list | grep ${PUBLICROUTER} | awk '{print $2}'`
neutron router-interface-add ${PUBLICROUTER} ${MGMT_SUBNET}
#neutron router-gateway-set ${PUBLICROUTER} ${MY_PUBLIC}

sleep 5

#neutron router-gateway-set ${PUBLICROUTER} ${MY_PUBLIC}
#nova flavor-create m1.l2fwd  201 4096 2 3
export tenant_mgmt_net_UUID=`neutron net-list | grep ${MGMT_NET} | awk '{print $2}'`
export tenant_net1_UUID=`neutron net-list | grep ${TENANT_NET1} | awk '{print $2}'`
export tenant_net2_UUID=`neutron net-list | grep ${TENANT_NET2} | awk '{print $2}'`

sleep 5

#Reset all neutron agents
service neutron-l3-agent reset
service neutron-openvswitch-agent reset
service neutron-dhcp-agent reset
service neutron-metadata-agent reset

sleep 3

neutron agent-list

nova boot --flavor m1.l2fwd --image ${BOOT_IMAGE} --nic net-id=${tenant_mgmt_net_UUID} --nic net-id=${tenant_net2_UUID} --security-group default ${VM1_NAME} --meta vhost=usvhost-1:525400000001 --meta vcpupin=0,0x0,0:1,0x100,0:2,0x200,0


#Checking if VM instance is running
MAX_CNT=20

cnt=$((MAX_CNT*3))
echo "Waiting for VM running state... max ${cnt}s"

state=$(nova list |grep ${VM1_NAME}| awk '{print $10}')

while [ "$state" != "Running" ] && [ $MAX_CNT -ne 0 ]; do
    state=($(nova list |grep ${VM1_NAME}| awk '{print $10}'))
    status=($(nova list |grep ${VM1_NAME}| awk '{print $6}'))

    if [ "$status" == "ERROR" ]; then
    	echo "VM error - ${status} status"
	echo "Script canceled"
	exit 1
    fi

    sleep 3
    ((MAX_CNT--))
done

if [ "$state" != "Running" ]; then
    echo "VM error - ${state} state"
    echo "Script canceled" 
    exit 1
else
    echo "VM ok - ${state} state"
fi

exit 0
