/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  DbManager.cpp
* @brief Database manager for Mobile Edge Applications.
*/

#include "DbManager.h"
#include "Exception.h"
#include "Log.h"


// Components for database queries
const char* DB_SPLIT_MARK = ":";

// Application Information Database Entry Format
//|----------------------|-----------------|
//|   key                |      value      |
//|----------------------|-----------------|
//| _MEC_SRMEAI:{appid}  |    {secret}     |
//|----------------------|-----------------|
// e.g. _MEC_SRMEAI:appid001
const char* DB_ME_APP_INFO_KEY = "_MEC_SRMEAI";

// Providable Service Information Database Entry Format
//|----------------------|--------------------------|-------------|
//|   key                |     field                |  value      |
//|----------------------|--------------------------|-------------|
//| _MEC_SRMEAPS:{appid} |isDeactivationPermited    |  [YES|NO]   |
//| :{service_name}      |                          |  [YES|NO]   |
//|----------------------|--------------------------|-------------|
const char* DB_PROVIDABLE_SERVICE_KEY = "_MEC_SRMEAPS";
const char* DB_PROVIDABLE_SERVICE_FIELD_ISDEACTIVATIONPERMITED = 
                "isDeactivationPermited";

// Subscribable Service Information Database Entry Format
//|----------------------|--------------------------|-------------|
//|   key                |     field                |  value      |
//|----------------------|--------------------------|-------------|
//| _MEC_SRMEASS:        |required                  |  [YES|NO]   |
//| {subscriber_appid}:  |isUnsubscriptionPermitted |  [YES|NO]   |
//| {service_name}:      |                          |             |
//| {provider_appid}     |                          |             |
//|----------------------|--------------------------|-------------|
const char* DB_SUBSCRIBABLE_SERVICE_KEY = "_MEC_SRMEASS";
const char* DB_SUBSCRIBABLE_SERVICE_FIELD_REQUIRED = "required";
const char* DB_SUBSCRIBABLE_SERVICE_FIELD_ISUNSUBSCRIPTIONPERMITTED = 
                "isUnsubscriptionPermitted";

// Settable Traffic Rule Information Database Entry Format
//|----------------------|--------------------------|-------------|
//|   key                |     field                |  value      |
//|----------------------|--------------------------|-------------|
//| _MEC_SRMEATR:{appid} |isUpdatePermitted         |  [YES|NO]   |
//| :{traffic_rule}      |isRemovalPermitted        |  [YES|NO]   |
//|----------------------|--------------------------|-------------|
const char* DB_SETTABLE_TRAFFIC_RULE_KEY = "_MEC_SRMEATR";
const char* DB_SETTABLE_TRAFFIC_RULE_ISUPDATEPERMITTED = "isUpdatePermitted";
const char* DB_SETTABLE_TRAFFIC_RULE_ISREMOVALPERMITTED = "isRemovalPermitted";


void DbManager::saveMeAppInfo(string appid, string secret)
{
    Redis db;
    string res;
    db.asStatus (res, "SET %s%s%s %s",
                 DB_ME_APP_INFO_KEY, DB_SPLIT_MARK, appid.c_str(), 
                 secret.c_str());

}

void DbManager::saveProvidableServices(string appid, string serviceName, 
                                                string isDeactivationPermited)
{
    Redis db;
    string res;
    db.asStatus(res, "HMSET %s%s%s%s%s %s %s", 
                DB_PROVIDABLE_SERVICE_KEY, DB_SPLIT_MARK, appid.c_str(), 
                DB_SPLIT_MARK, serviceName.c_str(), 
                DB_PROVIDABLE_SERVICE_FIELD_ISDEACTIVATIONPERMITED, 
                isDeactivationPermited.c_str());
}

void DbManager::saveSubscribableServices(string appid, string serviceName, 
                                         string providerAppId, string required, 
                                         string isUnsubscriptionPermitted)
{
    Redis db;
    string res;
    db.asStatus(res, "HMSET %s%s%s%s%s%s%s %s %s %s %s", 
                DB_SUBSCRIBABLE_SERVICE_KEY, DB_SPLIT_MARK, 
                appid.c_str(), DB_SPLIT_MARK, 
                serviceName.c_str(), DB_SPLIT_MARK, providerAppId.c_str(),
                DB_SUBSCRIBABLE_SERVICE_FIELD_REQUIRED, required.c_str(),
                DB_SUBSCRIBABLE_SERVICE_FIELD_ISUNSUBSCRIPTIONPERMITTED, 
                isUnsubscriptionPermitted.c_str());
}

void DbManager::saveSettableTrafficRules(string appid, string trafficRule, 
                                         string isUpdatePermitted, 
                                         string isRemovalPermitted)
{
    Redis db;
    string res;
    db.asStatus(res, "HMSET %s%s%s%s%s %s %s %s %s", 
                DB_SETTABLE_TRAFFIC_RULE_KEY, DB_SPLIT_MARK, appid.c_str(), 
                DB_SPLIT_MARK, trafficRule.c_str(), 
                DB_SETTABLE_TRAFFIC_RULE_ISUPDATEPERMITTED, 
                isUpdatePermitted.c_str(),
                DB_SETTABLE_TRAFFIC_RULE_ISREMOVALPERMITTED, 
                isRemovalPermitted.c_str());
}

void DbManager::getMeAppSecret(bool &isFound, string &secret, string appid)
{
    Redis db;
    isFound = false;
    try {
        db.asString(secret, "GET %s%s%s",
                    DB_ME_APP_INFO_KEY, DB_SPLIT_MARK, appid.c_str());
        isFound = true;
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}

void DbManager::getServicePermittedOps(bool &isFound, 
                                        string &isDeactivationPermited,
                                        string appid, string serviceName)
{
    Redis db;

    isFound = false;
    isDeactivationPermited = "NO";
    
    int res = 0;
    db.asInt(res, "EXISTS %s%s%s%s%s",
             DB_PROVIDABLE_SERVICE_KEY, DB_SPLIT_MARK, appid.c_str(), 
             DB_SPLIT_MARK, serviceName.c_str());
    
    if (0 < res) {
        isFound = true;
        try {
            db.asString(isDeactivationPermited, "HGET %s%s%s%s%s %s", 
                        DB_PROVIDABLE_SERVICE_KEY, DB_SPLIT_MARK, appid.c_str(), 
                        DB_SPLIT_MARK, serviceName.c_str(),
                        DB_PROVIDABLE_SERVICE_FIELD_ISDEACTIVATIONPERMITED);        
        } catch (Exception &e) {
            if (e.code != Exception::REDIS_NO_RESULT) {
                throw;
            }
        }
    }

}

void DbManager::getSubscribableServicesByAppid(StringArrayType &serviceList, 
                                                string appid)
{
    Redis db;
    try {
        db.asArray (serviceList, "KEYS %s%s%s%s*",
                    DB_SUBSCRIBABLE_SERVICE_KEY, DB_SPLIT_MARK, appid.c_str(), 
                    DB_SPLIT_MARK);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}

void DbManager::getSubscribableServicesByServiceName(
                                                StringArrayType &serviceList, 
                                                string serviceName, 
                                                string providerAppid)
{
    Redis db;
    try {
        db.asArray (serviceList, "KEYS %s%s*%s%s%s%s",
                    DB_SUBSCRIBABLE_SERVICE_KEY, DB_SPLIT_MARK, DB_SPLIT_MARK, 
                    serviceName.c_str(), DB_SPLIT_MARK, providerAppid.c_str());
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}

void DbManager::getSubscribableServicePermittedOps(string &required, 
                                            string &isUnsubscriptionPermitted, 
                                            string key)
{
    Redis db;
    required = "NO";
    isUnsubscriptionPermitted = "NO";
    
    try {
        db.asString(required, "HGET %s %s", key.c_str(), 
            DB_SUBSCRIBABLE_SERVICE_FIELD_REQUIRED);        
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
    try {
        db.asString(isUnsubscriptionPermitted, "HGET %s %s", key.c_str(), 
            DB_SUBSCRIBABLE_SERVICE_FIELD_ISUNSUBSCRIPTIONPERMITTED);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}

void DbManager::getSettableTrafficRules(StringArrayType &trafficRuleList, 
                                        string appid)
{
    Redis db;
    try {
        db.asArray (trafficRuleList, "KEYS %s%s%s%s*",
                    DB_SETTABLE_TRAFFIC_RULE_KEY, DB_SPLIT_MARK, appid.c_str(), 
                    DB_SPLIT_MARK);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}

void DbManager::getTrafficRulePermittedOps(string &isUpdatePermitted, 
                                           string &isRemovalPermitted, 
                                           string key)
{
    Redis db;
    isUpdatePermitted = "NO";
    isRemovalPermitted = "NO";
    try {
        db.asString(isUpdatePermitted, "HGET %s %s", key.c_str(), 
            DB_SETTABLE_TRAFFIC_RULE_ISUPDATEPERMITTED);
        db.asString(isRemovalPermitted, "HGET %s %s", key.c_str(), 
            DB_SETTABLE_TRAFFIC_RULE_ISREMOVALPERMITTED);

    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}

void DbManager::removeMeAppConfiguration(string appid)
{
    Redis db;
    StringArrayType list;
    int res;
    
    // Remove Me App info.
    db.asInt(res, "DEL %s%s%s", 
                DB_ME_APP_INFO_KEY, 
                DB_SPLIT_MARK, 
                appid.c_str());
    
    // Remove Providable Services.
    try {
        db.asArray (list, "KEYS %s%s%s%s*",
                DB_PROVIDABLE_SERVICE_KEY, DB_SPLIT_MARK, appid.c_str(), 
                DB_SPLIT_MARK);
        for (string &list_ : list) {
            db.asInt(res, "DEL %s",list_.c_str());
        }
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }

    // Remove Subscribable Services.
    try {
        db.asArray (list, "KEYS %s%s%s%s*",
                    DB_SUBSCRIBABLE_SERVICE_KEY, DB_SPLIT_MARK, appid.c_str(), 
                    DB_SPLIT_MARK);
        for (string &list_ : list) {
            db.asInt(res, "DEL %s",list_.c_str());
        }
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }

    // Remove SettableTraffic Rules.
    try {
        db.asArray (list, "KEYS %s%s%s%s*",
                    DB_SETTABLE_TRAFFIC_RULE_KEY, DB_SPLIT_MARK, appid.c_str(), 
                    DB_SPLIT_MARK);
        for (string &list_ : list) {
            db.asInt(res, "DEL %s",list_.c_str());
        }
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }

}

