/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file     PluginManager.h
* @brief    This class is responsible for managing plug-ins, initializing 
*           plug-ins, checking plug-in status, loading plug-ins, and unloading
*           plug-ins,
*/

#ifndef _PLUGINMANAGER_H_
#define _PLUGINMANAGER_H_

#include "Plugin.h"

class PluginInstance;
class DynamicLib;
class IProducer;
class PluginWatcher;

using namespace std;

class  PluginManager :public IPluginManager
{
    friend class PluginWatcher;
public:
    static PluginManager &getInstance();

    /**
    * @brief        Initializes the path where plug-ins will be stored and 
    *               a producer object.
    * @param[in]    pluginPath      Plug-in path.
    * @param[in]    pd              Producer object.
    * @return       true on success and false on failure.
    */
    bool init(IProducer *pd, string &pluginPath);

    /**
    * @brief        Checks all plug-ins to get plug-in activation information.
    * @return       void.
    */
    void check();

    /**
    * @brief        Enables the PluginManager to stop a PluginWatcher.
    * @return       void.
    */
    void stopPluginWatcher();

    /**
    * @brief        Gets all plug-ins' info.
    * @return       Vector of all plugins.
    */
    vector<PluginInstance *> getAllPlugins();

    /**
    * @brief        Enables a plug-in to load itself.
    * @return       true on success and false on fail.
    */
    virtual bool loadPlugin(PluginInstance *pPlugin);

    /**
    * @brief        Enables a plug-in to unload itself.
    * @return       true on success and false on fail.
    */
    virtual bool unLoadPlugin(PluginInstance *pPlugin);

    /**
    * @brief        Enables a plug-in to push data.
    * @return       true on success and false on fail.
    */
    virtual void notifyData(string &data);

protected:
    bool loadAndCheck(const string &strName);
    PluginInstance* load(const string &strName,int &errCode);
    bool unLoad(const string &strName);

    void getPluginFiles();
    static void* watcherThreadHandler(void *);

private:
    PluginManager(void);
    ~PluginManager(void);
    PluginManager(const PluginManager &rhs);
    const PluginManager &operator=(const PluginManager &rhs);

    vector<string> vecPluginFiles;
    vector<string>::iterator pluginFileItor;

    vector<PluginInstance *> vecPlugins;
    vector<PluginInstance *>::iterator pluginInsItor;
    map<string,DynamicLib *> vecPluginLibs;
    IProducer *producer;
    static PluginWatcher *pluginWatcher;
    string sPluginPath;
    string pluginShadowPath;
    pthread_t watherID;
};

#endif
