/*******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ******************************************************************************/
/**
 * @file Exception.h
 * @brief Header file for Exception
*/

#ifndef __MECFCGI__EXCEPTION__
#define __MECFCGI__EXCEPTION__

#include <stdio.h>
#include <iostream>
#include <map>
#include <json/json.h>

using namespace std;

#define HTTP_SC_SWITCHING_PROTOCOLS "101 Switching Protocols"
#define HTTP_SC_OK "200 OK"
#define HTTP_SC_CREATED "201 Created"
#define HTTP_SC_NO_CONTENT "204 No Content"
#define HTTP_SC_BAD_REQUEST "400 Bad Request"
#define HTTP_SC_NOT_FOUND "404 Not Found"
#define HTTP_SC_INTERNAL_SERVER_ERROR "500 Internal Server Error"

class Exception
{
public:
    enum {
        DISPATCH_NOTARGET,
        DISPATCH_NOTYPE,
        INIT_NES_CONNECT,
        INVALID_ACTION,
        INVALID_APPID,
        INVALID_MAC_ADDRESS,
        INVALID_PARAMETER,
        INVALID_SECRET,
        INVALID_SERVICE_LIST,
        INVALID_TRAFFIC_RULE,
        INVALID_TYPE,
        INVALID_VM_ID,
        INVALID_SERVICE_NAME,
        SERVICE_DATA_NOT_EXIST,
        KEYFIELDS_NOT_EXIST,
        UPDATE_DATA_NOT_EXIST,
        REDIS_ARRAY_ELE_TYPE_MISMATCH,
        REDIS_COMMAND_ERROR,
        REDIS_CONNECT_FAILD,
        REDIS_CONNECTIONPOOL,
        REDIS_NO_REPLY,
        REDIS_NO_RESULT,
        REDIS_TYPE_MISMATCH,
        REGISTERED,
        RNIS_DATA_ERROR,
        RNIS_DB_ERROR,
        RNIS_SERVICE_ERROR,
        APPID_NOT_EXIST,
        SECRET_WRONG,
        SEND_SERVICE_INFO_ERROR,
        SERVICE_EXIST,
        SERVICE_NOT_EXIST,
        SESSION_INV,
        SESSION_NOT_FOUND,
        TRAFFIC_RULE_AUTHORITY_ERROR,
        TRAFFIC_RULE_ERR,
        TRAFFIC_RULE_EXIST,
        UNKOWN_ERROR,
        WAIT_PUBLISHDATA_ERROR,
        PARSING_JSON_BODY,
        TEST_FAILED,
        INVALID_SERVICE_INFO,
        INVALID_SERVICE_DATA,
        INVALID_DATA_SCHEMA,
        HTTP_SYSTEM_ERROR,
        HTTP_STATUS_ERROR,
        NO_PERMISSION,
        INVALID_SERVICEID,
        DATA_BASE_FAILURE,
        ALREADY_SUBSCRIBED,
        MISSING_SUBSCRIPTION,
        NO_SUBSCRIPTION,
        DUPLICATE_SUBSCRIPTION,
        DUPLICATE_APPID,
        UNSUPPORTED_SERVICE_TYPE,
        APP_NOT_RUNNING,
        INVALID_PROVIDABLESERVICES,
        INVALID_SUBSCRIBABLESERVICES,
        INVALID_SETTABLETRAFFICRULES,
        INVALID_TIME_OUT_VALUE,
        NO_SERVICE_NAME,
        NO_SERVICE_VERSION,
        NO_SERVICE_ENDPOINT,
        NO_SERVICE_TYPE,
        INVALID_SERVICE_TYPE,
        NO_SERVICE_DATASCHEMA
    };

    Exception(int code, const string &err) : code(code), err(err) { }
    Exception(int code) : code(code) { }
    int code;
    string err;
    static void handlerException(Exception e, string &res, string &statusCode);
};

#endif /* defined(__MECFCGI__EXCEPTION__) */
