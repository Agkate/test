/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    HandlerCommon.h
 * @brief   Header file for declarations of commonly-used functions.
 */

#ifndef __HANDLER_COMMON__
#define __HANDLER_COMMON__

#include <string>
#include <stdlib.h>
#include <json/json.h>

using namespace std;
const char SPLIT_MARK = ':';
class HandlerCommon
{
public:
    /**
    * @brief        Gets traffic rule information for an ME App from database
    *               using a traffic rule ID.
    * @param[out]   match           Indication of whether a traffic rule is 
    *                               matched.
    * @param[in]    settableTraffic A set of traffic rules that an ME App/ME 
    *                               App Service may set.
    * @param[in]    traffic         A set of traffic rules that an ME App/ME 
    *                               App Service want to set.
    * @return       void
    */
    static void compareTrafficRule(bool &match, Json::Value settableTraffic,
                                    Json::Value traffic);

    /**
    * @brief        Checks traffic rules' format.
    * @param[out]   result          Check result.
    * @param[in]    traffic         A set of traffic rules that an ME App/ME 
    *                               App Service want to set.
    * @return       void
    */                                
    static void checkTrafficRuleFormat(string &result, Json::Value traffic);
};


#endif /* defined(__HANDLER_COMMON__) */
