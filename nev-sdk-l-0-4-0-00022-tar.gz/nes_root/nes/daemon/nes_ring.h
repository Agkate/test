/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file nes_ring.h
* @brief Header file for nes_ring
*/
#ifndef NES_RING_H_
#define NES_RING_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <rte_ring.h>
#include "nts/nts_lookup.h"

#define NES_RING_ELEMENTS_DEFAULT 1024
#define NES_RING_NAME_LEN RTE_RING_NAMESIZE

#define MBUFS_PER_RING NES_RING_ELEMENTS_DEFAULT
#define MBUFS_PER_PORT 1536

enum {
   YES,
   NO
};

/**
* Ring parameters
* Ring parameters for ring cosntructor
*/
typedef struct nes_ring_params_s {
    /**
    * Ring name
    */
    const char *name;
    /**
    * Maximum number of ring elements.
    * If set to 0, NES_RING_ELEMENTS_DEFAULT is used.
    */
    uint16_t count;
    /**
    * Specify single/multi producer ring access mode.
    * For multi producer set YES, otherwise set NO.
    * All rings are single consumer.
    */
    uint8_t  multiproducer;
    /**
    * Force enqueue threshold in microseconds.
    * A bigger value may boost bandwidth at the cost of latency. 
    * Smaller one may boost latency at the cost of bandwidth.
    * If unsure, test with 0;
    */
    uint32_t threshold_us; 
} nes_ring_params_t;

#define NES_RING_BURST_SIZE MAX_BURST_SIZE

/**
* Abstract ring object
*/
typedef struct nes_ring_s {
    struct rte_ring *ring;
    nts_lookup_tables_t *routing_tables;
    uint8_t remove;

    struct nes_ctrl_ring_s *ring_stats;
    int (*ctor)(struct nes_ring_s *, void *);
    int (*enq)(struct nes_ring_s *, void *);
    int (*enq_burst)(struct nes_ring_s *, void **, int);
    int (*flow)(struct nes_ring_s *, void **, int);
    int (*deq)(struct nes_ring_s *, void **);
    int (*deq_burst)(struct nes_ring_s *, void **, int);
    int (*dtor)(struct nes_ring_s *, void *);
} nes_ring_t;

static inline char *nes_ring_name(nes_ring_t *self)
{
    return self->ring->name;
}

int nes_ring_norings(void);
int nes_ring_init(void);
nes_ring_params_t *nes_ring_params_table_get(void);
int nes_ring_per_vm_set(int vm_id, nes_ring_t **rx_ring_ptr, nes_ring_t **tx_ring_ptr);
int nes_ring_per_port_set(int port_id, nes_ring_t **tx_ring_ptr);
inline nes_ring_t *get_egress_ring_from_src_ip(uint32_t src_ip);
inline nes_ring_t *get_egress_ring_from_dst_ip(uint32_t dst_ip);
inline nes_ring_t *get_egress_ring_from_ips(uint32_t src_ip, uint32_t dst_ip);
inline int nes_io_learn_egress_ring(uint32_t src_ip, nes_ring_t *ring);

#ifdef __cplusplus
}
#endif

#endif /* NES_RING_H_ */

