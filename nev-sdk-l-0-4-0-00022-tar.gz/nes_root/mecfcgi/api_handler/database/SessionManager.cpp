/*******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ******************************************************************************/
/**
 * @file SessionManager.cpp
 * @brief Implementation of SessionManager
*/

#include "SessionManager.h"
#include "Exception.h"
#include "DbManager.h"
#include "HashUtil.h"
#include <sstream>
#include "Log.h"


void SessionManager::createSession(string &sessionId,
                                    string appid, string secret)
{
    DbManager::StringArrayType sessionIdList;
    DbManager::getSessionIdListByAppid(sessionIdList, appid);
    if (0 < sessionIdList.size()){
        for (string &session_ : sessionIdList) {
            DbManager::delDataByKey(session_);
        }
    }

    stringstream ssTmp;
    ssTmp << appid << secret << time(NULL);
    sessionId = HashUtil::sha256(ssTmp.str());
    DbManager::addSessionId(appid, sessionId);
}

void SessionManager::deleteSession(string sessionId)
{
    DbManager::delSessionIdBySessionId(sessionId);
}

void SessionManager::checkSession(map<string, string> cookies,
                                    string &sessionId)
{
    if (cookies.find("SESSID") == cookies.end()) {
        MECFCGI_LOG(ERR, "Session invalid.\n");
        throw Exception(Exception::SESSION_INV, "Session invalid");
    }
    sessionId = cookies["SESSID"];

    DbManager::StringArrayType sessionIdList;
    DbManager::getSessionIdListBySessionId(sessionIdList,sessionId);
    int sessionIdListSize = sessionIdList.size();
    if (0 >= sessionIdListSize) {
        throw Exception(Exception::SESSION_INV,
            "Invalid session is used to query DB");
    } else if(1 < sessionIdListSize) {
        for (string &session_ : sessionIdList) {
            DbManager::delDataByKey(session_);
        }
        throw Exception(Exception::SESSION_INV,
            "Invalid session is used to query DB");
    }
}

void SessionManager::getAppidBySession(string sessionId, string &appid)
{
    DbManager::StringArrayType sessionIdList;
    DbManager::getSessionIdListBySessionId(sessionIdList,sessionId);
    int sessionIdListSize = sessionIdList.size();
    if (0 >= sessionIdListSize) {
        throw Exception(Exception::SESSION_INV,
            "Invalid session is used to query DB");
    } else if(1 < sessionIdListSize) {
        for (string &session_ : sessionIdList) {
            DbManager::delDataByKey(session_);
        }
        throw Exception(Exception::SESSION_INV,
            "Invalid session is used to query DB");
    } else{
        //sessionIdList  MES:appid:sessionId
        istringstream iss(sessionIdList.at(0));
        getline(iss, appid, ':'); //MES
        getline(iss, appid, ':'); //appid
    }
}

