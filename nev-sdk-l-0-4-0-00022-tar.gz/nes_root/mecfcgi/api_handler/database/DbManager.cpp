/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  DbManager.cpp
* @brief Implementation of database manager for Mobile Edge Applications.
*/

#include "DbManager.h"
#include "Exception.h"
#include "Log.h"

// Components for database queries
const char* DB_SPLIT_MARK = ":";

// related to session
// e.g.  MES:appid:sessionId
const char* DB_ME_SESSION_KEY = "_MEC_MES";

// related to ME App info
//|----------------------|-----------------|---------------------|
//|   key                |   field         |   value             |
//|----------------------|-----------------|---------------------|
//|   _MEC_MEAI:appid    |   token         |   "token"           |
//|   _MEC_MEAI:appid    |   type          |   "serviceType"     |
//|----------------------|-----------------|---------------------|
// e.g. MEAPPLI:appid
const char* DB_ME_APP_LIFECYCLE_INFO_KEY = "_MEC_MEAI";
const char* DB_ME_APP_LIFECYCLE_INFO_FIELD_TYPE = "type";
const char* DB_ME_APP_LIFECYCLE_INFO_FIELD_TOKEN = "token";

// related to ME App Services' activated/active service info
//|----------------------|-----------------|---------------------|
//|   key                |   field         |   value             |
//|----------------------|-----------------|---------------------|
//|_MEC_MEARS:serviceId  |   token         |   "token"           |
//|_MEC_MEARS:serviceId  |   serviceName   |   "serviceName"     |
//|_MEC_MEARS:serviceId  |   endPoint      |   "endPoint"        |
//|_MEC_MEARS:serviceId  |   version       |   "version"         |
//|_MEC_MEARS:serviceId  |   serviceType   |   "serviceType"     |
//|_MEC_MEARS:serviceId  |   dataSchemaCvt |   "dataSchemaCvt"   |
//|_MEC_MEARS:serviceId  |   dataSchema    |   "dataSchema"      |
//|----------------------|-----------------|---------------------|
// e.g. _MEC_MEARS:serviceId
const char* DB_ME_APP_ACTIVATED_SERVICES_KEY = "_MEC_MEARS";
const char* DB_ME_APP_ACTIVATED_SERVICES_TOKEN = "token";
const char* DB_ME_APP_ACTIVATED_SERVICES_SERVICENAME = "serviceName";
const char* DB_ME_APP_ACTIVATED_SERVICES_ENDPOINT = "endPoint";
const char* DB_ME_APP_ACTIVATED_SERVICES_VERSION = "version";
const char* DB_ME_APP_ACTIVATED_SERVICES_SERVICETYPE = "serviceType";
const char* DB_ME_APP_ACTIVATED_SERVICES_DATASCHEMACVT = "dataSchemaCvt";
const char* DB_ME_APP_ACTIVATED_SERVICES_DATASCHEMA = "dataSchema";

// related to ME Apps' service subcsription info
// e.g. _MEC_MEASS:token:serviceId
const char* DB_ME_APP_SERVICES_SUBSCRIPTION_KEY = "_MEC_MEASS";

//|------------------------|-----------------|---------------------|
//|   key                  |   field         |   value             |
//|------------------------|-----------------|---------------------|
//|_MEC_MEATR:trafficRuleId|   lookup        |   "lookup"          |
//|_MEC_MEATR:trafficRuleId|   mac           |   "mac"             |
//|_MEC_MEATR:trafficRuleId|   vmid          |   "vmid"            |
//|_MEC_MEATR:trafficRuleId|   token         |   "token"           |
//|_MEC_MEATR:trafficRuleId|   trafficrule   |   "trafficrule"     |
//|------------------------|-----------------|---------------------|
const char* DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY = "_MEC_MEATR";
const char* DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_LOOKUP = "lookup";
const char* DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_MACADDRESS = "mac";
const char* DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_VMID = "vmid";
const char* DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_TOKEN = "token";
const char* DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_TRAFFICRULE = "trafficrule";

// related to ME Apps' service data update
// e.g. MEAPPSD:dataKeys(ServiceId:filed<value>)
const char* DB_ME_APP_SERVICE_DATA_KEY = "_MEC_MEAPPSD";

void DbManager::delDataByKey(string key)
{
    Redis db;
    int res;
    db.asInt(res, "DEL %s",key.c_str());
}

void DbManager::checkAndGetAppTypeByAppid(bool &exist, string &appType,
                                            string appid)
{
    Redis db;
    try {
        db.asString(appType, "HGET %s%s%s %s",
                    DB_ME_APP_LIFECYCLE_INFO_KEY, DB_SPLIT_MARK, appid.c_str(),
                    DB_ME_APP_LIFECYCLE_INFO_FIELD_TYPE);
        exist = true;
    } catch (Exception &e) {
        if (e.code == Exception::REDIS_NO_RESULT) {
            exist = false;
        }else{
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::checkAndGetTokenByAppid(bool &exist, string &token,
                                        string appid)
{
    Redis db;
    try {
        db.asString(token, "HGET %s%s%s %s",
                    DB_ME_APP_LIFECYCLE_INFO_KEY, DB_SPLIT_MARK, appid.c_str(),
                    DB_ME_APP_LIFECYCLE_INFO_FIELD_TOKEN);
        exist = true;
    } catch (Exception &e) {
        if (e.code == Exception::REDIS_NO_RESULT) {
            exist = false;
        }else{
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getSessionIdListByAppid(StringArrayType &sessionIdList,
                                        string appid)
{
    Redis db;
    try {
        db.asArray(sessionIdList, "KEYS %s%s%s%s*", DB_ME_SESSION_KEY,
                    DB_SPLIT_MARK, appid.c_str(), DB_SPLIT_MARK);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}

void DbManager::getSessionIdListBySessionId(StringArrayType &sessionIdList,
                                            string sessionId)
{
    Redis db;
    try {
        db.asArray(sessionIdList, "KEYS %s%s*%s%s", DB_ME_SESSION_KEY,
                    DB_SPLIT_MARK, DB_SPLIT_MARK, sessionId.c_str());
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}


void DbManager::delSessionIdBySessionId(string sessionId)
{
    Redis db;
    StringArrayType sessionIdList;

    getSessionIdListBySessionId(sessionIdList, sessionId);
    for (string &sessionId_ : sessionIdList) {
        delDataByKey(sessionId_);
    }


}

void DbManager::addSessionId(string appid, string sessionId)
{
    Redis db;
    string res;
    db.asStatus(res, "SET %s%s%s%s%s %s",
                DB_ME_SESSION_KEY, DB_SPLIT_MARK, appid.c_str(),
                DB_SPLIT_MARK, sessionId.c_str(), appid.c_str());
}

void DbManager::saveMeAppInfo(string appid, string apptype, string token)
{
    Redis db;
    string res;
    db.asStatus (res, "HMSET %s%s%s %s %s %s %s",
                 DB_ME_APP_LIFECYCLE_INFO_KEY, DB_SPLIT_MARK, appid.c_str(),
                 DB_ME_APP_LIFECYCLE_INFO_FIELD_TYPE, apptype.c_str(),
                 DB_ME_APP_LIFECYCLE_INFO_FIELD_TOKEN, token.c_str());
}

void DbManager::clearMeAppInfo(string appid)
{
    Redis db;
    int res;
    db.asInt(res, "HDEL %s%s%s %s %s",
             DB_ME_APP_LIFECYCLE_INFO_KEY, DB_SPLIT_MARK, appid.c_str(),
             DB_ME_APP_LIFECYCLE_INFO_FIELD_TYPE,
             DB_ME_APP_LIFECYCLE_INFO_FIELD_TOKEN);
}

void DbManager::addActivatedService(string token, string serviceName,
                                    string serviceId, string endPoint,
                                    string version, string serviceType,
                                    string dataSchemaCvt, string dataSchema)
{
    Redis db;
    string res;
    db.asStatus(res, "HMSET %s%s%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                DB_ME_APP_ACTIVATED_SERVICES_KEY, DB_SPLIT_MARK,
                serviceId.c_str(),
                DB_ME_APP_ACTIVATED_SERVICES_TOKEN, token.c_str(),
                DB_ME_APP_ACTIVATED_SERVICES_SERVICENAME, serviceName.c_str(),
                DB_ME_APP_ACTIVATED_SERVICES_ENDPOINT, endPoint.c_str(),
                DB_ME_APP_ACTIVATED_SERVICES_VERSION, version.c_str(),
                DB_ME_APP_ACTIVATED_SERVICES_SERVICETYPE, serviceType.c_str(),
                DB_ME_APP_ACTIVATED_SERVICES_DATASCHEMACVT, 
                dataSchemaCvt.c_str(),
                DB_ME_APP_ACTIVATED_SERVICES_DATASCHEMA, dataSchema.c_str());
}

void DbManager::delActivatedServiceByServiceId(string serviceId)
{
    Redis db;
    int res;
    db.asInt(res, "DEL %s%s%s",
                DB_ME_APP_ACTIVATED_SERVICES_KEY, DB_SPLIT_MARK,
                serviceId.c_str());
}

void DbManager::getActivatedServiceName(string serviceId, string &serviceName)
{
    Redis db;
    try {
        db.asString(serviceName, "HGET %s%s%s %s",
                    DB_ME_APP_ACTIVATED_SERVICES_KEY,
                    DB_SPLIT_MARK, serviceId.c_str(),
                    DB_ME_APP_ACTIVATED_SERVICES_SERVICENAME);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getActivatedServiceToken(string serviceId, string &token)
{
    Redis db;
    token = "";
    try {
        db.asString(token, "HGET %s%s%s %s",
                    DB_ME_APP_ACTIVATED_SERVICES_KEY,
                    DB_SPLIT_MARK, serviceId.c_str(),
                    DB_ME_APP_ACTIVATED_SERVICES_TOKEN);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getActivatedServiceDataSchemaCvt(string serviceId,
                                                string &dataSchemaCvt)
{
    Redis db;
    try {
        db.asString(dataSchemaCvt, "HGET %s%s%s %s",
                    DB_ME_APP_ACTIVATED_SERVICES_KEY,
                    DB_SPLIT_MARK, serviceId.c_str(),
                    DB_ME_APP_ACTIVATED_SERVICES_DATASCHEMACVT);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getActivatedServiceDataSchema(string serviceId,
                                                string &dataSchema)
{
    Redis db;
    try {
        db.asString(dataSchema, "HGET %s%s%s %s",
                    DB_ME_APP_ACTIVATED_SERVICES_KEY,
                    DB_SPLIT_MARK, serviceId.c_str(),
                    DB_ME_APP_ACTIVATED_SERVICES_DATASCHEMA);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getActivatedServiceVersion(string serviceId, string &version)
{
    Redis db;
    try {
        db.asString(version, "HGET %s%s%s %s",
                    DB_ME_APP_ACTIVATED_SERVICES_KEY,
                    DB_SPLIT_MARK, serviceId.c_str(),
                    DB_ME_APP_ACTIVATED_SERVICES_VERSION);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getActivatedServiceEndPoint(string serviceId, string &endPoint)
{
    Redis db;
    try {
        db.asString(endPoint, "HGET %s%s%s %s",
                    DB_ME_APP_ACTIVATED_SERVICES_KEY,
                    DB_SPLIT_MARK, serviceId.c_str(),
                    DB_ME_APP_ACTIVATED_SERVICES_ENDPOINT);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getActivatedServiceServiceType(string serviceId,
                                                string &serviceType)
{
    Redis db;
    try {
        db.asString(serviceType, "HGET %s%s%s %s",
                    DB_ME_APP_ACTIVATED_SERVICES_KEY,
                    DB_SPLIT_MARK, serviceId.c_str(),
                    DB_ME_APP_ACTIVATED_SERVICES_SERVICETYPE);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getActivatedServiceIdList(StringArrayType &serviceIdList)
{
    Redis db;
    try {
        db.asArray(serviceIdList, "KEYS %s*",
                    DB_ME_APP_ACTIVATED_SERVICES_KEY);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getSessionByAppid(string &token, string appid)
{
    Redis db;
    try {
        db.asString(token, "HGET %s%s%s %s",
                    DB_ME_APP_LIFECYCLE_INFO_KEY, DB_SPLIT_MARK, appid.c_str(),
                    DB_ME_APP_LIFECYCLE_INFO_FIELD_TOKEN);
    } catch (Exception &e) {
        if (e.code == Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "ME App token does not exist.\n");
            throw Exception(Exception::APPID_NOT_EXIST);
        } else{
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::addServiceSubscription(string token, string serviceId)
{
    Redis db;
    string res;
    db.asStatus(res, "SET %s%s%s%s%s %s",
                DB_ME_APP_SERVICES_SUBSCRIPTION_KEY, DB_SPLIT_MARK,
                token.c_str(), DB_SPLIT_MARK, serviceId.c_str(),
                serviceId.c_str());
}

void DbManager::addServiceSubscription(string token, Json::Value serviceList)
{
    int size = serviceList.size();
    for (int i = 0; i < size; i++) {
        string serviceId = serviceList[i].get("serviceId", "Nil").asString();
        DbManager::addServiceSubscription(token, serviceId);
    }
}


void DbManager::getServiceSubscriptionListByToken(StringArrayType &serviceIdList
                                                    , string token)
{
    Redis db;
    try {
        db.asArray (serviceIdList, "KEYS %s%s%s%s*",
                    DB_ME_APP_SERVICES_SUBSCRIPTION_KEY, DB_SPLIT_MARK,
                    token.c_str(), DB_SPLIT_MARK);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}

void DbManager::delServiceSubscriptionListByToken(string token)
{
    Redis db;
    StringArrayType serviceIdList;
    getServiceSubscriptionListByToken(serviceIdList, token);
    for (string &key_ : serviceIdList) {
        delDataByKey(key_);
    }
}

void DbManager::getServiceSubscriptionStatus(bool &subscribed, string token,
                                                string serviceId)
{
    subscribed = false;
    Redis db;
    try {
        StringArrayType subscribedList;
        db.asArray (subscribedList, "KEYS %s%s%s%s%s",
                    DB_ME_APP_SERVICES_SUBSCRIPTION_KEY, 
                    DB_SPLIT_MARK, token.c_str(),
                    DB_SPLIT_MARK, serviceId.c_str());
        if (0 < subscribedList.size()) {
            subscribed = true;
        }
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getSubscriberByServiceId(StringArrayType &subscriberList,
                                            string serviceId)
{
    Redis db;
    try {
        db.asArray(subscriberList, "KEYS %s%s*%s%s",
                    DB_ME_APP_SERVICES_SUBSCRIPTION_KEY, DB_SPLIT_MARK,
                    DB_SPLIT_MARK, serviceId.c_str());
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            throw;
        }
    }
}

void DbManager::delSubscribedServiceByTokenAndServiceId(string token,
                                                        string serviceId)
{
    Redis db;
    int res;
    db.asInt(res, "DEL %s%s%s%s%s",
             DB_ME_APP_SERVICES_SUBSCRIPTION_KEY, DB_SPLIT_MARK, token.c_str(),
             DB_SPLIT_MARK, serviceId.c_str());
}

void DbManager::saveServiceData(string dataKeys, string serviceData)
{
    Redis db;
    string res;
    db.asStatus(res, "SET %s%s%s %s",
                DB_ME_APP_SERVICE_DATA_KEY, DB_SPLIT_MARK, dataKeys.c_str(),
                serviceData.c_str());

}

void DbManager::getServiceData(string dataKeys, string &serviceData)
{
    Redis db;
    serviceData = "";
    try {
        db.asString(serviceData, "GET %s%s%s",
                DB_ME_APP_SERVICE_DATA_KEY, DB_SPLIT_MARK, dataKeys.c_str());
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::addTrafficRulesInfo(string trafficRuleId, string token,
                                    string lookupKeys, string macAddress,
                                    uint32_t vmId, string trafficRule)
{
    Redis db;
    string res;
    string sVmId = to_string(vmId);
    db.asStatus(res, "HMSET %s%s%s %s %s %s %s %s %s %s %s %s %s",
                DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK,
                trafficRuleId.c_str(),
                DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_TOKEN, token.c_str(),
                DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_LOOKUP,
                lookupKeys.c_str(),
                DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_MACADDRESS,
                macAddress.c_str(),
                DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_VMID, sVmId.c_str(),
                DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_TRAFFICRULE,
                trafficRule.c_str());
}

void DbManager::getTrafficRuleInfoByTrafficRuleId(bool &isFound,
                                                    string trafficRuleId,
                                                    string &lookupKeys,
                                                    string &trafficRule)
{
    Redis db;
    isFound = false;
    try {
        db.asString(lookupKeys, "HGET %s%s%s %s",
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK,
                    trafficRuleId.c_str(),
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_LOOKUP);
        db.asString(trafficRule, "HGET %s%s%s %s",
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK,
                    trafficRuleId.c_str(),
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_TRAFFICRULE);
        isFound = true;
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getTrafficRuleInfoByTrafficRuleId(string trafficRuleId,
                                                    string &trafficRule)
{
    Redis db;
    try {
        db.asString(trafficRule, "HGET %s%s%s %s",
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK,
                    trafficRuleId.c_str(),
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_TRAFFICRULE);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getTrafficRuleIdList(StringArrayType &trafficRuleIdList)
{
    try {
        Redis db;
        db.asArray(trafficRuleIdList, "KEYS %s%s*",
                   DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getTrafficRuleTokenByRuleId(string &token, string trafficRuleId)
{
    try {
        Redis db;
        db.asString(token, "HGET %s%s%s %s",
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK,
                    trafficRuleId.c_str(),
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_TOKEN);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getTrafficRuleLookupByRuleId(string &lookup,
                                                string trafficRuleId)
{
    try {
        Redis db;
        db.asString(lookup, "HGET %s%s%s %s",
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK,
                    trafficRuleId.c_str(),
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_LOOKUP);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getTrafficRuleMacAddressByRuleId(string &macAddress,
                                                    string trafficRuleId)
{
    try {
        Redis db;
        db.asString(macAddress, "HGET %s%s%s %s",
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK,
                    trafficRuleId.c_str(),
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_MACADDRESS);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::getTrafficRuleVmIdByRuleId(string &vmId, string trafficRuleId)
{
    try {
        Redis db;
        db.asString(vmId, "HGET %s%s%s %s",
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK,
                    trafficRuleId.c_str(),
                    DB_ME_APP_TRAFFIC_RULE_MANAGER_FIELD_VMID);
    } catch (Exception &e) {
        if (e.code != Exception::REDIS_NO_RESULT) {
            MECFCGI_LOG(ERR, "Database error.\n");
            throw;
        }
    }
}

void DbManager::delTrafficRulesInfo(string trafficRuleId)
{
    Redis db;
    int res;
    db.asInt(res, "DEL %s%s%s",
                DB_ME_APP_TRAFFIC_RULE_MANAGER_KEY, DB_SPLIT_MARK,
                trafficRuleId.c_str());
}

