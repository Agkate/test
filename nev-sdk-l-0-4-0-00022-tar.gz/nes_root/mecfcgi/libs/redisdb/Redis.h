/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file Redis.h
 * @brief Header file for Redis
*/

#ifndef __MECFCGI__REDIS__
#define __MECFCGI__REDIS__

#include <hiredis/hiredis.h>
#include <iostream>
#include <vector>
#include <boost/thread.hpp>

using namespace std;
using namespace boost;

#define REDIS_MAX_CONNECTION_POOL 20

class Redis
{
public:
    typedef vector<string> StringArrayType;
    typedef pair<string, vector<string>> ScanArrayType;


    enum PASSWORD {
        NOT_HAS_PASSWORD = 0,
        HAS_PASSWORD
    };

    typedef struct redis_info_s
    {
        string      redis_ip;
        uint16_t    redis_port;
        uint16_t    redis_haspassword;
        string      redis_password;
    } redis_info_t;

    /**
     * @brief    Constructs a Redis object that encapsulates a connection to the
     *           underlying Redis database. (Up to REDIS_MAX_CONNECTION_POOL
     *           connections may be created.)
     * @throw    Exception    Thrown on failure.
     */
    Redis();
    ~Redis();

    /**
     * @brief        Sets the parameters for establishing Redis connections.
     * @param[in]    redis_ip          The ip address for accessing the Redis
     *                                 database.
     * @param[in]    redis_port        The port number for accessing the Redis
     *                                 database.
     * @param[in]    redis_password    The password for accessing the Redis
     *                                 database.
     * @return       void
     */
    static void setRedisInfo(string redis_ip, uint16_t redis_port, string redis_password);

    /**
     * @brief        Issues a command to the Redis database and retrieves the
     *               result as a string.
     * @param[out]   res          Holds the result of Redis database executing
     *                            the command.
     * @param[in]    command      A command string with place-hold charaters,
     *                            that may be replaced with values supplied by
     *                            following arguments.
     * @param[in]    ...          Variable argument lists containing arguments
     *                            corresponding to place-holder characters in
     *                            the command string.
     * @throw        Exception    Thrown on failure.
     * @return       void
     */
    void asString(string &res, const string command, ...);

    /**
     * @brief        Issues a command to the Redis database and retrieves the
     *               result as an integer.
     * @param[out]   res          Holds the result of Redis database executing
     *                            the command.
     * @param[in]    command      A command string with place-hold charaters,
     *                            that may be replaced with values supplied by
     *                            following arguments.
     * @param[in]    ...          Variable argument lists containing arguments
     *                            corresponding to place-holder characters in
     *                            the command string.
     * @throw        Exception    Thrown on failure.
     * @return       void
     */
    void asInt(int &res, const string command, ...);

    /**
     * @brief        Issues a command to the Redis database and retrieves the
     *               result as a simple string indicating command executinon
     *               status.
     * @param[out]   res          Holds the result of Redis database executing
     *                            the command.
     * @param[in]    command      A command string with place-hold charaters,
     *                            that may be replaced with values supplied by
     *                            following arguments.
     * @param[in]    ...          Variable argument lists containing arguments
     *                            corresponding to place-holder characters in
     *                            the command string.
     * @throw        Exception    Thrown on failure.
     * @return       void
     */
    void asStatus(string &res, const string command, ...);

    /**
     * @brief        Issues a command to the Redis database and retrieves the
     *               result as an array of strings.
     *               status.
     * @param[out]   array        Holds the result of Redis database executing
     *                            the command.
     * @param[in]    command      A command string with place-hold charaters,
     *                            that may be replaced with values supplied by
     *                            following arguments.
     * @param[in]    ...          Variable argument lists containing arguments
     *                            corresponding to place-holder characters in
     *                            the command string.
     * @throw        Exception    Thrown on failure.
     * @return       void
     */
    void asArray(StringArrayType &array, const string command, ...);
private:
    static boost::mutex mutex;
    static redisContext *redis[REDIS_MAX_CONNECTION_POOL];
    static int connectionPoolTop;

    int connectionIndex;
    void checkReply(redisReply *reply, int type);

    static redis_info_t redisInfo;
};

#endif /* defined(__MECFCGI__REDIS__) */
