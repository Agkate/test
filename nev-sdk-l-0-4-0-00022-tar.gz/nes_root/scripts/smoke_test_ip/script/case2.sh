#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

#set -e
TEST_NAME="2"
TEST_DESCRIPTION="Routing API - SRV IP based add"

. functions.sh

VM_NAME=$VM1_NAME
VM_NES_IP=$VM1_NES_IP

ROUTE_IP=$VM_NES_IP
ROUTE_TYPE=srv_ip

copy_sshkey_to_vm $VM_NAME

VM_MAC=$(get_MAC_addr $VM_NAME $VM_NES_ETH)

TEST_STATUS=0

configure_app appid001
modify_route $VM_NAME REMOVE 0 $VM_MAC $ROUTE_TYPE $ROUTE_IP 24 > /dev/null 2>&1
modify_route $VM_NAME CREATE 0 $VM_MAC $ROUTE_TYPE $ROUTE_IP 24
if [ $? != 0 ]; then
	TEST_STATUS=1
fi

# set IP to eth1 on VM
exec_on_vm $VM_NAME "ifconfig $VM_NES_ETH $VM_NES_IP/24"
exec_on_vm $VM_NAME "route add -net 192.168.210.0/24 gw $VM_NES_IP" > /dev/null 2>&1
exec_on_vm $VM_NAME "arp -s $UE_IP $UE_MAC -i $VM_NES_ETH"

# send some MAC authorization frames
exec_on_vm $VM_NAME "ping -I $VM_NES_ETH 255.255.255.254 -c 1 > /dev/null 2>&1"

ping -c 1 $EXT_IP > /dev/null

# execute iperf3 server on VM
exec_on_vm $VM_NAME "iperf3 -s -D -B $VM_NES_IP"

if_name=`ifconfig | grep 192.168.210.1 -B 1 | awk -F ":" 'NR==1{print $1}'`
ip route add 192.168.1.0/24 dev $if_name > /dev/null 2>&1

# send some traffic
do_iperf "-c $VM_NES_IP -i 1 -t 2 -M 1400"
if [ $? != 0 ]; then
	TEST_STATUS=1
fi

exec_on_vm $VM_NAME "killall iperf3"

modify_route $VM_NAME REMOVE 0 $VM_MAC $ROUTE_TYPE $ROUTE_IP 24
if [ $? != 0 ]; then
	TEST_STATUS=1
fi

rem_sshkey_in_vm $VM_NAME

put_result $TEST_STATUS $TEST_NAME "$TEST_DESCRIPTION"

