/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file nes_common.h
* @brief Header file for common declarations
*/

#ifndef _NES_COMMON_H_
#define _NES_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <rte_log.h>
#include "nes_api_common.h"

#define LOOKUP_TABLE_ENTRIES 2048
#define MAX_LOOKUPS_PER_VM 10
#define MAX_VM_NUMBER 90
#define MAX_BURST_SIZE 32

#define RTE_LOGTYPE_NES RTE_LOGTYPE_USER1
#if defined (COVERAGE_ENABLED) || defined (LIBNES_API)
    #define NES_LOG(level,...) do { printf(__VA_ARGS__); } while(0)
#else
    #define NES_LOG(level,...) RTE_LOG(level, NES, "["#level"] "__VA_ARGS__)
#endif

#ifdef UNIT_TESTS
    #define NES_STATIC
    #define NES_TEST_MAIN main
    #define NES_MAIN __attribute__((unused)) nes_main
    #define NES_EXIT(status)
    extern volatile int nes_thread_terminate;
    #define NES_FOREVER_LOOP ;!nes_thread_terminate;
    #define FORCE_INLINE
#else
    #define NES_STATIC static
    #define NES_MAIN main
    #define NES_EXIT(status) exit(status)
    #define NES_FOREVER_LOOP ;;
    #define FORCE_INLINE __attribute__((always_inline)) inline
#endif

#define UDP_GTPU_PORT 2152
#define UDP_GTPC_PORT 2123
#define IP_PROTO_SCTP   132
#define IP_PROTO_UDP    17
#define IP_PROTO_TCP    6
#define IP_PROTO_ICMP   1

static inline const void** conv_ptr_to_const(uint32_t** ptr)
{
    return (const void **)(void*)ptr;
}

typedef enum {
    NES_UPSTREAM,
    NES_DOWNSTREAM,
} nes_direction_t;

#define rte_memcmp strcmp

#ifdef __cplusplus
}
#endif /* extern "C" */

#endif /* _NES_COMMON_H_ */
