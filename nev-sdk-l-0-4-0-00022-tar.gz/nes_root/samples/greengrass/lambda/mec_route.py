#!/usr/bin/python
# coding: utf-8
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

# Sample lambda function - create/remove routing in NEV_SDK based on /mec/route/trigger topic
# Lambda setup on AWS board:
# - Memory limit: 16MB
# - Timeout: 3s
# - Lambda lifecycle: On-demand
# - Read access to /sys: Disable
# - Additional resource to site-packages where extra python libraries are installed
# -  for example /usr/lib/python2.7/site-packages/

import sys
import greengrasssdk
import platform
import httplib2
import threading
import socket
import json
import re
import ctypes
import getopt
import logging
import websocket
import random
import os.path
import time

# Creating a greengrass core sdk client
client = greengrasssdk.client('iot-data')

# Retrieving platform information to send from Greengrass Core
my_platform = platform.platform()

class Vector:
    first=""
    second=""
    def __init__(self,x,y):
        self.first=x
        self.second=y

# Meapp class
class Meapp:
    def __init__(self):
        self.__HOSTPORT = '8080'                            # host port number
        self.__WEBSOCKETPORT = '8888'                       # websocket port number
        self.__HOSTADDR = 'mec.local'                         # host ip
        self.__CERTPATH = os.environ.get('PYTHONPATH') + 'mec.crt'
        self.__h = httplib2.Http(ca_certs=self.__CERTPATH)
        self.__cookie = ''                                  # cookie value
        self.__stopped = True                               # thread switch
        self.logFlagForDebug = True                        # debug log output switch
        self.arrServiceID = ''                              #
        self.thread = ""                                    # websocket thread
        self.__updatetraffic = ""
        self.__subscription = ""
        self.subscribableServiceList = []                   # list of ME services an ME App may subscribe to.
        self.subscribedServicesList = []                    # list of ME services an ME App has been subscribed.
        self.trafficRuleList = []
        self.createdTrafficRuleList = []
        self.__baseUrl = 'https://' + self.__HOSTADDR + ':' + self.__HOSTPORT + '/appliance/v1' # url prefix

# Do Mobile Edge Application Live Indicator(-z)
    def liveIndicator(self, appid='appid003', secret=''):
        procedure = 'Live Indicator Request'
        url = self.__baseUrl + '/live_apps'
        method = "POST"
        contentType = "application/json"
        requestBody = json.loads('{{ "appid": "{}", "secret": "{}", "type": "MEAPP" }}'.format(appid, secret))

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            # Save cookies
            self.__cookie = resp['set-cookie']
            print('[OK] Mobile Edge Application Live Indicator.')
        else:
            print('[NG] Mobile Edge Application Live Indicator.')

# Delete thread
    def delWebSocket(self):
        self.__stopped = True

    def formatChannelListenerResponse(self, str):
        str = list(str)
        temp = ""
        count = 0
        for s in str:
            if s == '{' :
                count += 1
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == '[' :
                count += 1
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == ',':
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == '}':
                count -= 1
                temp += '\n'
                temp = self.addTable(temp,count)
                temp += s
            elif s == ']':
                count -= 1
                temp += '\n'
                temp = self.addTable(temp,count)
                temp += s
            else:
                temp += s
        return temp
    def addTable(self,s,num):
        for i in range(0,num):
            s += '    '
        return s

# Create WebSocket
    def createWebSocket(self):
        if not self.__cookie:
            print('[NG] ME App Connection Establishment Failed: cookie is null')
            self.__stopped = True
            return

        if self.__cookie.find('SESSID=') != -1:
            refId = self.__cookie[self.__cookie.find('SESSID=') + 7:]
        else:
            refId = self.__cookie
        url = 'ws://' + self.__HOSTADDR + ':' + self.__WEBSOCKETPORT + '/notifications/' + refId
        try:
            websocket.enableTrace(True)
            ws = websocket.create_connection(url)
        except:
            print ('[NG] ME App Connection Establishment Failed: WebSocket header is invalid. Please try again.')
            self.__stopped = True
            return
        print ('[OK] ME App Connection Establishment.')
        while not self.__stopped:
            result = ws.recv()
            if result:
                result = self.formatChannelListenerResponse(result)
                print(result)

# Do Mobile Edge Traffic Rules Control(Create: -t, Remove: -r, Update: -f)
    def trafficRuleCreation(self, json_rule=''):
        procedure = 'Traffic Rule Creation Request'
        url = self.__baseUrl + '/traffic'
        method = "POST"
        contentType = "application/json"
        requestBody = json.loads(json_rule)
        createdFileName = "route"

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            respDic = json.loads(content)
            trafficRuleId = respDic['trafficRuleId']
            createdTrafficRule = Vector(createdFileName, trafficRuleId)
            self.createdTrafficRuleList.append(createdTrafficRule)
            print('[OK] Mobile Edge Traffic Rule Creation.')
            return True
        else:
            print('[NG] Mobile Edge Traffic Rule Creation.')
            return False


    def trafficRuleRemoval(self):
        procedure = 'Traffic Rule Removal Request'
        method = "DELETE"
        contentType = "application/json"

        if not self.createdTrafficRuleList:
            print("There are no existing traffic rules.")
            return False
        trafficRuleId = ""
        for createdTrafficRule_ in self.createdTrafficRuleList:
            trafficRuleId = createdTrafficRule_.second
            str = '1'
            self.arrServiceID = str.split()
        url = self.__baseUrl + '/traffic/' + trafficRuleId
        requestBody = ""

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            self.createdTrafficRuleList.pop(int(self.arrServiceID[0])-1)
            print('[OK] Mobile Edge Traffic Rule Removal.')
            return True
        else:
            print('[NG] Mobile Edge Traffic Rule Removal.')
            return False


# result check
    def checkResult(self, resp, content):
        if not 'status' in resp:
            print "http server is not running!"
            return False
        try:
            respDic = json.loads(content)
            if respDic['result'] == "OK" or (
                respDic['result'] == "AlreadySubscribed" or
                respDic['result'] == "TrafficRuleExist" or
                respDic['result'] == "AppidAuthenticated"):
                return True
            else:
                print('result:{}'.format(respDic['result']))
                return False
        except ValueError:
            print "http server is not running!"
            return False
# output request log
    def reqLogout(self, data):
        if data['Body']:
            data['Body'] = json.dumps(data['Body'], sort_keys=True, indent=4)
        print('')
        print("{}".format(data['Tip']))
        print('')
        print("Request Header")
        print("  URL        : {}".format(data['URL']))
        print("  Method     : {}".format(data['Method']))
        print("  ContentType: {}".format(data['ContentType']))
        print("  Cookie     : {}".format(data['Cookie']))
        print('')
        print("Request Body")
        print('{}'.format(data['Body']))
        print('')

# output response log
    def respLogout(self, data):
        data['Resp'] = json.dumps(data['Resp'], sort_keys=True, indent=4)
        if "result" in data['Content']:
            data['Content'] = json.dumps(json.loads(data['Content']), sort_keys=True, indent=4)
        print('')
        print("{}".format(data['Tip']))
        print('')
        print("Response Header")
        print('{}'.format(data['Resp']))
        print('')
        print("Response Body")
        print('{}'.format(data['Content']))
        print('')

    def setCookie(self, cookie):
        self.__cookie=cookie


# When deployed to a Greengrass core, this code will be executed immediately
# as a long-lived lambda function.  The code will enter the infinite while loop
# below.

if my_platform:
    message = "lambda is being run on Greengrass Core Platform"
else:
    message = "lambda run on AWS Greengrass"

print 'message {}'.format(message)

def function_handler(event, context):
    meapp = Meapp()
    if my_platform:
        if 'action' in event and 'json' in event:
            if event['action'] == 'add':
                meapp.liveIndicator(event['appid'], event['secret'])
                if meapp.trafficRuleCreation(event['json']):
                    client.publish(topic='mec/route', payload=json.dumps({'result': 'Route added successfully'}))
                else:
                    client.publish(topic='mec/route', payload=json.dumps({'result': 'Failed to add route'}))
            elif event['action'] == 'del':
                meapp.liveIndicator(event['appid'], event['secret'])
                meapp.trafficRuleCreation(event['json'])
                if meapp.trafficRuleRemoval():
                    client.publish(topic='mec/route', payload=json.dumps({'result': 'Route deleted successfully'}))
                else:
                    client.publish(topic='mec/route', payload=json.dumps({'result': 'Failed to delete route'}))

