/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
 * @file nes_configuration.c
 * @brief nes server configuration
 */
#include <stdio.h>
#include <stdlib.h>
#include <rte_cfgfile.h>
#include <rte_config.h>
#include <rte_eal.h>
#include <rte_debug.h>
#include <rte_malloc.h>

#include "ctrl/nes_configuration.h"
#include "nes_common.h"
#include "libnes_cfgfile.h"

int nes_server_configure(configuration_t *conf)
{
    const char *ctrl_socket;
#ifdef EXT_CTRL_SOCKET
    const char *ctrl_ip;
    const char *ctrl_port;
    conf->server_ip = NULL;
    conf->server_port = 0;
#endif


    conf->server_socket = NULL;
    if(NES_FAIL == nes_cfgfile_entry("NES_SERVER", "ctrl_socket", &ctrl_socket )) {
#ifndef EXT_CTRL_SOCKET
        NES_LOG(ERR, "Error reading [NES_SERVER] ctrl_socket.\n");
        return NES_FAIL;
#else
        if (NES_FAIL == nes_cfgfile_entry("NES_SERVER", "ctrl_ip", &ctrl_ip )) {
            NES_LOG(ERR, "Reading server IP from config file failed.");
            return NES_FAIL;
        }

        if (NES_FAIL == nes_cfgfile_entry("NES_SERVER", "ctrl_port", &ctrl_port )) {
            NES_LOG(ERR, "Reading server port from config file failed.");
            return NES_FAIL;
        }
        conf->server_ip = ctrl_ip;
        conf->server_port = atoi(ctrl_port);
        conf->server_port = (uint16_t)conf->server_port;
#endif
    }
    else {
    conf->server_socket = ctrl_socket;
    }

    return NES_SUCCESS;
}
