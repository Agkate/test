/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file nts_lookup.c
* @brief Implementation of lookup functionality
*/
#include <stdlib.h>


#include <rte_malloc.h>

#include "nes_common.h"
#include "nes_capacity.h"
#include "libnes_cfgfile.h"
#include "libnes_lookup.h"
#include "libnes_sq.h"
#include "nts/nts_lookup.h"
#include "nts_edit.h"
#include "nes_ring_lookup.h"
#define NTS_LOOKUP_VM_MAX 90

#ifdef UNIT_TESTS
#include "nts_lookup_decl.h"
#endif
NES_STATIC int    nts_lookup_vm_max;
NES_STATIC char **nts_lookup_tx_ring_names;

char *nts_lookup_tx_ring_name_get(int vm_num) {
    if (0      > vm_num             ||
        vm_num >= nts_lookup_vm_max ||
        NULL   == nts_lookup_tx_ring_names) {
        return NULL;
    }
    return nts_lookup_tx_ring_names[vm_num];
}

NES_STATIC int nts_lookup_init_tx_rings_names(int vms_cnt)
{
    int i, j;
    nts_lookup_tx_ring_names = rte_malloc(
                            "Ring names table",
                            vms_cnt * sizeof(char*),
                            0);

    if (NULL == nts_lookup_tx_ring_names) {
        NES_LOG(ERR, "Could not allocate table for VM ring names.\n");
        return NES_FAIL;
    }
    for (i = 0; i < vms_cnt; i++) {
        nts_lookup_tx_ring_names[i] = rte_malloc(
                                   "Ring name",
                                   NES_RING_NAME_LEN,
                                   0);
        if (NULL == nts_lookup_tx_ring_names[i]) {
            NES_LOG(ERR, "Ring name allocation failed");
            break;
        }
    }
    if (i < vms_cnt) {
        for (j=0; j<i; j++) {
            rte_free(nts_lookup_tx_ring_names[j]);
        }
        return NES_FAIL;
    }

    for (i=0; i < vms_cnt; i++) {
        snprintf(
            nts_lookup_tx_ring_names[i],
            NES_RING_NAME_LEN,
            "IO_VM%d_ANY",
            i);
    }
    return NES_SUCCESS;
}

int nts_lookup_init(nts_lookup_tables_t * lookup_tables)
{
    const char* buffer;
    struct nes_lookup_params_s lookup_table_params ={
        .name = "nts_io_learning_lookup_table",
        /* Learning table size - make it 4 times the exact size to avoid hash conflicts */
        .number_of_entries = 4 * NES_MAX_UE,
        .key_len = IPV4_BYTES,
        .entry_len = sizeof(nts_enc_entry_t)
    };

    lookup_tables->learning = rte_malloc("Learning lookup table", sizeof(nes_lookup_table_t), 0);
    VERIFY_PTR_OR_RET(lookup_tables->learning, NES_FAIL);
    if (NES_SUCCESS != nes_lookup_ctor(lookup_tables->learning, &lookup_table_params))  {
        NES_LOG(ERR, "Failed to create learning lookup table\n");
        return NES_FAIL;
    }

    if (NES_SUCCESS != is_avp_enabled()) {
        if (NES_SUCCESS != nes_cfgfile_entry("VM common","max",&buffer)) {
            NES_LOG(ERR,"Missing: section %s, entry %s, in config file.\n", "VM common", "max");
            return NES_FAIL;
        }
        nts_lookup_vm_max = atoi(buffer);

        return nts_lookup_init_tx_rings_names(nts_lookup_vm_max);
    } else {
        return NES_SUCCESS;
    }
}
