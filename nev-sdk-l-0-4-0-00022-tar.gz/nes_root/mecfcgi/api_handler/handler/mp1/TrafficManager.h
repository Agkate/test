/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    TrafficManager.h
 * @brief   The class of handlers responsible for handling Mobile Edge Traffic
 *          Rules Control.
 *
 *          <Mobile Edge Traffic Rules Control>
 *          Once a running ME App/ME App Service has been authenticated by the
 *          ME Platform, it may request the ME Platform to create, update or
 *          remove traffic rules to manipulate the data flow in the underlying
 *          data plane. The ME Platform determines whether a request is to be
 *          processed based on the ME App's/ME App Service's policy
 *          configuration.
 *          This is a mandatory API. An ME application cannot perform traffic
 *          rules control-related operations without using this API.
 */
#ifndef __MECFCGI__TRAFFICMANAGER__
#define __MECFCGI__TRAFFICMANAGER__

#include "PostRequestHandler.h"
#include "PutRequestHandler.h"
#include "DelRequestHandler.h"


class CreateTrafficRule : public PostRequestHandler
{
public:
    /**
    * @brief            Handles REST API requests for adding a traffic rule.
    * @param[in]        request     JSON-formatted request data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute(Json::Value &request, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

class UpdateTrafficRule : public PutRequestHandler
{
public:
    /**
    * @brief            Handles REST API requests for updating a traffic rule.
    * @param[in]        request     JSON-formatted request data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute(Json::Value &request, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

class RemoveTrafficRule : public DelRequestHandler
{
public:
    /**
    * @brief            Handles REST API requests for removing a traffic rule.
    * @param[in]        params      JSON-formatted params data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute(map<string, string> params, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

#endif //__MECFCGI__TRAFFICMANAGER__