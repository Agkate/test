/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    SysPlugin.cpp
 * @brief   Implementation of SysPlugin.
 */

#include <json/json.h>
#include <sstream>
#include <unistd.h>
#include <string.h>

#include "GetServiceData.h"
#include "Config.h"

string getHostMemInfo();
float getHostCPURate();
int64_t getHostCache();

typedef struct SysCPUInfo_s
{
    char *name;
    uint64_t user;  //User CPU time in "jiffies" (1 jiffy is 0.01 second), not 
                    //counting those processes whose "nice" value is negative, 
                    //measured from system boot-up to the present moment.

    uint64_t nic;   //CPU time in "jiffies" (1 jiffy is 0.01 second), of those 
                    //processes whose "nice" value is negative, measured from 
                    //system boot-up to the present moment.
                    
    uint64_t system;//Kernel time in "jiffies" (1 jiffy is 0.01 second), 
                    //measured from system boot-up to the present moment.
                    
    uint64_t idle;  //Idle time in "jiffies" (1 jiffy is 0.01 second), excluding
                    //hard drive I/O idle time, measured from system boot-up 
                    //to the present moment.
} SysCPUInfo;


string getServiceData()
{
    string sysMemInfo = "";
    float cpuRate;
    int64_t cache;
    cpuRate = getHostCPURate();
    sysMemInfo = getHostMemInfo();
    cache = getHostCache();

    Json::Reader reader;
    Json::Value systemInfo;
    reader.parse(SERVICE_DATA_TEMPLATE, systemInfo);
    size_t n = sysMemInfo.find_last_of("\n"); 
    if( n != string::npos ) { 
        sysMemInfo = sysMemInfo.substr(0, n); 
    }    
    systemInfo["serviceData"]["data"]["memory"] = sysMemInfo;
    
    stringstream cpuInfo;
    cpuInfo << "cpu rate: " << cpuRate <<"%";
    systemInfo["serviceData"]["data"]["CPUUsage"] = cpuInfo.str();

    stringstream cacheInfo;
    cacheInfo << "cached: " << cache <<" MB";
    systemInfo["serviceData"]["data"]["cacheUsage"] = cacheInfo.str();

    Json::FastWriter writer;
    string data = writer.write(systemInfo);

    return data;
}


string getHostMemInfo()
{
    FILE *fstream = NULL;
    char buff[1024];
    memset (buff ,'\0', sizeof(buff));

    string cmd = "free -m";
    cmd +=
        "| awk -F ' ' 'NR==2{print \" total: \" $2 \" MB "
                                       "used: \" $3 \" MB "
                                       "free: \" $4 \" MB\"}'";
                                       
    if(NULL == (fstream = popen(cmd.c_str (), "r"))) {
        return 0;
    }

    if(NULL == fgets(buff, sizeof(buff), fstream))
    {
        pclose(fstream);
        return 0;
    }

    stringstream ss;
    ss << buff;
    pclose(fstream);
    return ss.str();
}

SysCPUInfo* getHostCPUInfo()
{
    SysCPUInfo *cpuinfo = (SysCPUInfo *)malloc(sizeof(SysCPUInfo));
    if (cpuinfo == NULL) {
        return NULL;
    }
    memset(cpuinfo, 0, sizeof(SysCPUInfo));

    FILE    *fd;
    char    buff[256];
    memset(buff, '\0', 256);

    fd = fopen("/proc/stat", "r");
    if (NULL == fd) {
        free(cpuinfo);
        return NULL;
    }
    fgets(buff, sizeof(buff), fd);
    char delims[] = " ";
    char *user = NULL;
    char *nic = NULL;
    char *system = NULL;
    char *idle = NULL;
    cpuinfo->name = strtok(buff, delims);
    if (NULL == cpuinfo->name) {
        free(cpuinfo);
        fclose(fd);
        return NULL;
    }
    user = strtok(NULL, delims);
    if (NULL == user) {
        free(cpuinfo);
        fclose(fd);
        return NULL;
    }
    nic = strtok(NULL, delims);
    if (NULL == nic) {
        free(cpuinfo);
        fclose(fd);
        return NULL;
    }
    system = strtok(NULL, delims);
    if (NULL == system) {
        free(cpuinfo);
        fclose(fd);
        return NULL;
    }
    idle = strtok(NULL, delims);
    if (NULL == idle) {
        free(cpuinfo);
        fclose(fd);
        return NULL;
    }
    cpuinfo->user = strtoul(user, 0, 10);
    cpuinfo->nic = strtoul(nic, 0, 10);
    cpuinfo->system = strtoul(system, 0, 10);
    cpuinfo->idle = strtoul(idle, 0, 10);
    fclose(fd);
    return cpuinfo;
}

float calculateHostCPURate(SysCPUInfo *first, SysCPUInfo *second)
{
    uint64_t   oldCPUTime, newCPUTime;
    uint64_t   usrTimeDiff, sysTimeDiff, nicTimeDiff;
    float      cpu_use = 0.0;

    oldCPUTime = (uint64_t)(first->user + first->nic + 
                            first->system + first->idle);
    newCPUTime = (uint64_t)(second->user + second->nic + 
                            second->system + second->idle);

    usrTimeDiff = (uint64_t)(second->user - first->user);
    sysTimeDiff = (uint64_t)(second->system - first->system);
    nicTimeDiff = (uint64_t)(second->nic - first->nic);

    if ((newCPUTime - oldCPUTime) != 0) {
        cpu_use = (float)100*(usrTimeDiff + sysTimeDiff + nicTimeDiff)/
                        (newCPUTime - oldCPUTime);
    } else {
        cpu_use = 0.0;
    }
    return cpu_use;
}

float getHostCPURate()
{
    float cpu_rate = 0.0;
    SysCPUInfo *first, *second;
    first = getHostCPUInfo();
    if (NULL == first){
        return cpu_rate;
    }
    sleep(1);
    second = getHostCPUInfo();
    if (NULL == second){
        free(first);
        return cpu_rate;
    }
    cpu_rate = calculateHostCPURate(first, second);

    free(first);
    free(second);
    first = second = NULL;

    return cpu_rate;
}

int64_t getHostCache()
{
    FILE *fstream = NULL;
    char buff[1024];
    memset (buff ,'\0', sizeof(buff));

    std::string cmd = "free -m";
    cmd += "| awk -F ' ' 'NR==2{print $7}'";
    if(NULL == (fstream = popen(cmd.c_str (), "r"))) {
        return 0;
    }

    if(NULL == fgets(buff, sizeof(buff), fstream))
    {
        pclose(fstream);
        return 0;
    }

    stringstream ss;
    ss << buff;
    int64_t cache = 0;
    ss >> cache;
    pclose(fstream);
    return cache;
}  