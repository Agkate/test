#!/usr/bin/env python

###################################################################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
###################################################################################################

# Standard library imports:
import json
import time
import sys

# GG/MEC imports:
from ggmec import make_common_parser, setup_logger, setup_mqtt_client


_LOG = None
ADD_ACTION="add"
DEL_ACTION="del"

def make_parser():
    actions = (ADD_ACTION, DEL_ACTION)
    actions_str = "{0:s} or {1:s}".format(", ".join(actions[:-1]), actions[-1])
    default_route = "mec_route.json"

    parser = make_common_parser()
    parser.add_argument(
        "--mec-action", action="store", metavar="CODE", dest="mec_action", default="ADD_ACTION",
        choices=actions,
        help="Published MEC action CODE name ({0:s})".format(actions_str))
    parser.add_argument(
        "--mec-route", action="store", metavar="PATH", dest="mec_route", default=default_route,
        help="Published MEC route json file PATH (default: {0:s})".format(default_route))

    return parser


def create_msg_data(options, mec_route):
    return {
        "action": options.mec_action,
        "appid": "appid003",
        "secret": "secret001",
        "json": mec_route}


def main(options):
    client = setup_mqtt_client(options)
    if not client.connect():
        _LOG.critical("AWS IoT connection failed")
        return 1
    else:
        _LOG.debug("AWS IoT connection established successfully")

    if options.subscribe_flag:
        subscribe_status = {"cnt": 0} # workaround for nonlocal missing in 2.7
        def subscribe_cb(client, userdata, message):
            _LOG.info("Received a message for topic {0}".format(message.topic))
            _LOG.debug("Message payload:\n{0}".format(message.payload))

            subscribe_status["cnt"] += 1

        if client.subscribe("mec/route", 1, subscribe_cb):
            _LOG.info(
                "Successfully subscribed to the '{0:s}' topic"
                "".format("mec/route"))
        else:
            _LOG.error(
                "Failed to subscribe to the '{0:s}' topic"
                "".format("mec/route"))
    else:
        subscribe_status = None


    if options.publish_flag:
        try:
            mec_route = open(options.mec_route).read()
        except IOError as e:
            _LOG.critical("Failed to read MEC route configuration ({0:s})".format(str(e)))
            return 2

        try:
            # Verify that the MEC route configuration file content is a valid json (there is no
            # sense to send it when it is invalid)
            json.loads(mec_route)
        except ValueError as e:
            _LOG.critical(
                "Failed to deserialize MEC route configuration taken from '{0:s}' file ({1:s})"
                "".format(options.mec_route, str(e)))
            return 3

        payload = json.dumps(create_msg_data(options, mec_route))

        if not client.publish(options.topic, payload, 1):
            _LOG.critical("Failed to publish to the '{0:s}' topic".format(options.topic))
            return 4
        else:
            _LOG.info("Successfully published message to the '{0:s}' topic".format(options.topic))
            _LOG.debug("Message payload:\n{0:s}".format(payload))

    time.sleep(1)

    # Print communication outcome for tester convenience:
    if subscribe_status is not None:
        if not subscribe_status["cnt"]:
            _LOG.error("No message received for subscribed topic")
            return 5
        elif subscribe_status["cnt"] > 1:
            _LOG.error("More than one message received for subscribed topic")
            return 6

    _LOG.info("Communication successful")

    return 0


if __name__ == '__main__':
    options = make_parser().parse_args()
    _LOG = setup_logger(options)
    sys.exit(main(options))
