/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file  NesPort.h
 * @brief nes wrapper
 */

#ifndef __MECFCGI__NESPORT__
#define __MECFCGI__NESPORT__

#include <stdint.h>
#include <boost/thread.hpp>
#include <vector>
#include <nes_api_common.h>
#include <libnes_api.h>

#define SERVICE_FIELD_NAME_SPLIT_MARK_MIDDLE_L    '<'
#define SERVICE_FIELD_NAME_SPLIT_MARK_MIDDLE_R    '>'
#define SERVICE_FIELD_NAME_SPLIT_MARK_BIG_L    '{'
#define SERVICE_FIELD_NAME_SPLIT_MARK_BIG_R    '}'
#define SERVICE_ID_SPLIT_MARK ':'

#define PUBLISH_DATA_LENGTH_MAX 1024

#define INIT_NTS_FLAG         (1 << 1)

using namespace boost;
using namespace std;

class NesPort
{
protected:
    thread worker;
public:
    enum
    {
        STATE_RUNNING,
        STATE_STOPPED
    } state = STATE_STOPPED;
    
    enum INIT_NES
    {
        INIT_NES_FAILED,
        INIT_NES_SUCCESS
    };

    typedef enum
    {
        STATE_CONNECT,
        STATE_NOTCONNECT
    } ConnectState;

    typedef struct
    {
        string lookupKeys;
        string macAddr;
        uint32_t vmId;
    } AddRoute;

    typedef struct
    {
        string lookupKeys;
    } RemoveRoute;

    ConnectState trfficCtrConn_state;

    uint8_t initNes_state;

    nes_remote_t trfficCtrConn;

    NesPort();
    ~NesPort();
    void startNesPortWatcher();
    void stopNesPortWatcher();
    void addRoute(AddRoute &params);
    void removeRoute(RemoveRoute &params);
    int initTrafficRulesInfo();
};

#endif //__MECFCGI__NESPORT__
