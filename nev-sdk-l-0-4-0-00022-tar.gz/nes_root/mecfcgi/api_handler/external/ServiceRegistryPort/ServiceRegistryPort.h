/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    ServiceRegistryPort.h
 * @brief   This class is primarily responsible for handling the communication
 *          between mecfcgi and service registry.
 *          With this class, mecfcgi can call the Service Registry's REST API 
 *          for policy checks.
 */

#ifndef __MECFCGI__SERVICEREGISTRYPORT__
#define __MECFCGI__SERVICEREGISTRYPORT__

#include <iostream>
#include <vector>
#include <json/json.h>

using namespace std;

class ServiceRegistryPort
{
public:
    typedef enum {
        ACTION_ACTIVATION_SERVICE,
        ACTION_DEACTIVATION_SERVICE,
        ACTION_SUBSCRIPTION_SERVICE,
        ACTION_UNSUBSCRIPTION_SERVICE,
        ACTION_CREATE_TRAFFIC_RULE,
        ACTION_UPDATE_TRAFFIC_RULE,
        ACTION_REMOVE_TRAFFIC_RULE
    } ACTION;

    static void setServiceRegistryInfo(string ip, uint16_t port);
    static void setPlatformProducerAppInfo(string appid, string secret);
    /**
    * @brief        Saves an ME App's/ME App Service's configuration 
    *               information.
    * @param[in]    request     ME App's/ME App Service's configuration 
    *                           information.
    * @param[out]   result      Status returned by API.
    * @return       void
    */
    static void saveMeAppConfiguration(string &result, Json::Value request);
    /**
    * @brief        Removes an ME App's/ME App Service's  configuration
    *               information.
    * @param[in]    appid       ME App's ID.
    * @param[out]   result      Status returned by API.
    * @return       void
    */
    static void removeMeAppConfiguration(string &result, string appid);

    /**
    * @brief        Authenticates an ME App/ME App Service.
    * @param[out]   result      Status returned by API.
    * @param[in]    appid       ME App's/ME App Service's ID.
    * @param[in]    secret      ME App's/ME App Service's secret.
    * @param[in]   appType      ME App's/ME App Service's type.
    * @return       void
    */
    static void checkPolicyForMeApp(string &result, string appid, 
                                        string secret, string appType);

    /**
    * @brief        Checks that a service may be activated or deactivated.
    * @param[in]    action      Permitted operations on the ME Service.
    * @param[in]    appid       ME App's/ME App Service's ID.
    * @param[in]    serviceName A name representing a service provided by an 
    *                           ME App Service. 
    * @param[out]   result      Status returned by API.
    * @return       void
    */
    static void checkPolicyForService(string &result,
                                        ACTION action, 
                                        string appid,
                                        string serviceName);
    
    /**
    * @brief        Checks if an ME App may subscribe to a list of ME services.
    * @param[out]   isPass                  Indication of whether the ME App may
    *                                       subscribe to the list of services.
    * @param[in]    action                  Permitted operations on the ME 
    *                                       Service
    * @param[in]    appid                   ME App's ID.
    * @param[in]    subscriptionServiceList List of subscribed services.
    * @return       void
    */
    static void checkPolicyForSubscriber(bool &isPass,
                                            ACTION action, 
                                            string appid, 
                                        Json::Value subscriptionServiceList);

    /**
    * @brief        Checks if an ME App may subscribe to an ME service.
    * @param[out]   isPass      Indication of whether the ME App may subscribe 
    *                           to the service.
    * @param[in]    action      Permitted operations on the ME Service
    * @param[in]    appid       ME App's ID.
    * @param[in]    serviceId   ID representing a service provided by an ME App 
    *                           Service.
    * @return       void
    */
    static void checkPolicyForSubscriber(bool &isPass,
                                            ACTION action, 
                                            string appid,
                                            string serviceId);

    /**
    * @brief        Checks if an ME App/ME App Service can manipulate this 
    *               traffic rule.
    * @param[out]   isPass      Indication of whether the ME App may manipulate 
    *                           the traffic rule.
    * @param[in]    action      Permitted operations on the trafficRule
    * @param[in]    appid       ME App's ID.
    * @param[in]    trafficRule Traffic rule specifying the data routing and 
    *                           forwarding criteria for the data plane.
    * @return       void
    */
    static void checkPolicyForTrafficRule(bool &isPass,
                                            ACTION action, 
                                            string appid, 
                                            Json::Value trafficRule);
    
    /**
    * @brief        Retrieves an ME Service's authorized (potential) 
    *               subscribers.
    * @param[in]    serviceName     Name representing a service provided by an 
    *                               ME App Service.
    * @param[in]    providerAppId   App ID of the ME App Service that provides 
    *                               the service.
    * @param[out]   appidList       List of ME Apps that may subscribe 
    *                               to the service.
    * @return       void
    */
    static void getAppidListFromServiceRegistry(Json::Value &appidList, 
                                                    string serviceName, 
                                                    string providerAppId);

    /**
    * @brief        Retrieves an ME App's subscribable services.
    * @param[in]    appid         ME App's ID.
    * @param[out]   serviceList   List of subscribable ME services.
    * @return       void
    */
    static void getSubscriptionServiceListFromServiceRegistry(
                                                    Json::Value &serviceList,
                                                    string appid);


private:
    typedef struct serviceRegistry_info_s
    {
        string      ip;
        uint16_t    port;
    } serviceRegistry_info_t;

    static serviceRegistry_info_t serviceRegistryInfo;
    static void sendMessageToServiceRegistry(string url, string method, 
                                                Json::Value request, 
                                                string &status, 
                                                Json::Value &response);
    static string PlatformProducerAppid;
    static string PlatformProducerSecret;
};

#endif /* defined(__MECFCGI__SERVICEREGISTRYPORT__) */