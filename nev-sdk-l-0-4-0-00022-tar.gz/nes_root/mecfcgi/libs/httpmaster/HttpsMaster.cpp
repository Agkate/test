/*******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ******************************************************************************/
/**
 * @file  HttpsMaster.cpp
 * @brief HTTPS Master
 */

#include "HttpsMaster.h"
#include "Exception.h"
#include <boost/algorithm/string.hpp>
#include <boost/bind.hpp>
#include "Log.h"


using namespace boost::algorithm;
using namespace boost::asio::ssl;

string HttpsMaster::cookie = "";
string HttpsMaster::hostURL = "";
uint16_t HttpsMaster::hostPort = 0;
string HttpsMaster::verificationCertPath = "";

HttpsMaster::HttpsMaster() : ctx(ssl::context::tlsv1), sock(svc, ctx)
{
    boost::system::error_code ec;   
    sock.set_verify_mode(boost::asio::ssl::verify_peer, ec);
    if(ec) {
        MECFCGI_LOG(ERR, "Error setting peer verification mode%s\n", 
            boost::system::system_error(ec).what());
        throw Exception(Exception::HTTP_SYSTEM_ERROR, "http system error");
    }

    if (verificationCertPath.empty()) {
        MECFCGI_LOG(INFO, "HTTPS without verification certificate\n");
        return;
    }
    ctx.load_verify_file(verificationCertPath, ec);
    if(ec) {
        MECFCGI_LOG(ERR, "Error loading verification certificate %s %s\n", 
	    verificationCertPath.c_str(),
            boost::system::system_error(ec).what());
        throw Exception(Exception::HTTP_SYSTEM_ERROR, "http system error");
    }
}

void HttpsMaster::setVerifCertPath(const string& path) 
{
    verificationCertPath = path;
}

void HttpsMaster::setHostInfo(string url, uint16_t port)
{
    hostURL= url;
    hostPort = port;
}

void HttpsMaster::connect(string url, uint16_t port)
{
    ip::tcp::endpoint ep(ip::address_v4::from_string(url), port);
    boost::system::error_code ec;

    sock.lowest_layer().connect(ep,ec);
    if(ec) {
        MECFCGI_LOG(ERR, "http system socket connect error. %s\n", 
            boost::system::system_error(ec).what());
        throw Exception(Exception::HTTP_SYSTEM_ERROR, "http system error");
    }

    sock.handshake(ssl::stream_base::handshake_type::client, ec);
    if(ec) {
        MECFCGI_LOG(ERR, "http system socket ssl handshake error. %s\n", 
            boost::system::system_error(ec).what());
        throw Exception(Exception::HTTP_SYSTEM_ERROR, "http system error");
    }
}
void HttpsMaster::connect()
{
    connect(hostURL, hostPort);
}
void HttpsMaster::disconnect()
{
    boost::system::error_code ec;
    sock.shutdown(ec);
    if(ec) {
        // Ignoring short read error, not a real error
        if (ec.category() != boost::asio::error::get_ssl_category() ||
                ec.value() != ERR_PACK(ERR_LIB_SSL, 0, SSL_R_SHORT_READ)) {
            sock.lowest_layer().close();
            MECFCGI_LOG(ERR, "http system socket disconnect error. %s\n", 
                boost::system::system_error(ec).what());
            throw Exception(Exception::HTTP_SYSTEM_ERROR, "http system error");
        }
    }
    sock.lowest_layer().close();
}
void HttpsMaster::httpsRequest(const string &url, const string &method, 
                                Json::Value &body, const string &contentType)
{
    stringstream ss;

    Json::FastWriter writer;
    string sdata = writer.write(body);

    ss << method << " " << url << " HTTP/1.1\r\n";
    ss << "Accept: application/json\r\n";
    ss << "Content-Length: " << sdata.length() << "\r\n";
    ss << "Content-Type: " << contentType<< "\r\n";
    ss << "Cookie: " << HttpsMaster::cookie << "\r\n";
    ss << "Host: Service Registry\r\n\r\n";
    ss << sdata;
    boost::asio::write(sock, buffer(ss.str()));
}

void HttpsMaster::httpsResponse(string &status, string &body)
{
    boost::system::error_code ec;
    string str = "";
    try {
        while (true) {
            array<char, 1024> recvBuf;
            size_t data_read = sock.read_some(buffer(recvBuf), ec);
            if (ec) { 
                MECFCGI_LOG(ERR, "Error while reading from the socket %s\n",
                                    boost::system::system_error(ec).what());
                throw Exception(Exception::HTTP_SYSTEM_ERROR, "http system error");

                break;
            }
            str.append(recvBuf.data(), data_read);

            if (str.find("Transfer-Encoding: chunked") == string::npos || 
                str.find ("\r\n0\r\n\r\n") != string::npos) {
                break;
            }
        }
    } catch(boost::system::system_error &e) {
        MECFCGI_LOG(ERR, "http system socket receive error.\n");
        throw Exception(Exception::HTTP_SYSTEM_ERROR, "http system error");
    }
    
    size_t posStart, posEnd;
    if ((posStart = str.find("HTTP/1.1 ")) != string::npos) {
        if ((posEnd = str.find("\r\n", posStart)) != string::npos) {
            status = str.substr(posStart + 9, posEnd - posStart - 9);
            trim (status);
        }
    }
    if ((posStart = str.find ("Set-Cookie:")) != string::npos) {
        HttpsMaster::cookie = str.substr (posStart + 12, 71);
        trim (HttpsMaster::cookie);
    }
    if ((posStart = str.find ("{")) != string::npos) {
        posEnd = str.rfind ("}");
        if (posEnd == string::npos){
            throw Exception(Exception::HTTP_SYSTEM_ERROR, 
                "Failed to parse response body");
        }
        body = str.substr(posStart, posEnd - posStart + 1);
    }
}
