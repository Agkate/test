/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file nes_cmdline_parse_acl_string.h
 * @brief Header file for nes_cmdline_parse_acl_string
 */
#ifndef NES_CMDLINE_PARSE_ACL_STRING_H
#define	NES_CMDLINE_PARSE_ACL_STRING_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "libnes_cfgfile.h"
    
typedef char nes_cmdline_acl_string_t[NES_MAX_LOOKUP_ENTRY_LEN];
extern struct cmdline_token_ops nes_cmdline_token_acl_string_ops;

int nes_cmdline_parse_acl_string(cmdline_parse_token_hdr_t *tk, const char *srcbuf, void *res, unsigned int buf_len);

#define NES_TOKEN_ACL_STRING_INITIALIZER(structure, field, string)  \
{                                                           \
	{                                                   \
		&nes_cmdline_token_acl_string_ops,          \
		offsetof(structure, field),                 \
	},                                                  \
	{                                                   \
		string,                                     \
	},                                                  \
}


#ifdef	__cplusplus
}
#endif

#endif	/* NES_CMDLINE_PARSE_ACL_STRING_H */

