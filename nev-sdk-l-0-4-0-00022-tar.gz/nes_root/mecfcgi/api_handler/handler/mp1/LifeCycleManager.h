/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    LifeCycleManager.h
 * @brief   Classes of handlers responsible for handling Mobile Edge Application
 *          Live Indicator and Termination Indicator.
 *
 *          <Mobile Edge Application Live Indicator>
 *          When an ME App/ME App Service is up and running after instantiation,
 *          it needs to send a live indicator to the ME Platform to become
 *          authenticated before it can consume or provide services on the ME
 *          Platform.
 *          This is a mandatory API. An ME application cannot signal its
 *          liveness to the ME Platform and get authenticated without using
 *          this API.
 *
 *          <Mobile Edge Application Termination Indicator>
 *          When an ME App/ME App Service receives a Termination Notification
 *          Request from the ME Platform, it should start preparing for
 *          termination. Once it is ready for termination, it should send a
 *          Termination Indicator to the ME Platform. An ME App/ME App Service
 *          may also request the ME Platform to clear its information for any
 *          reason even if it does not receive a termination notification.
 *          This is a mandatory API. An ME App/ME App Service cannot signal its
 *          termination readiness after receiving a Termination Notification
 *          without using this API. However, the ME App/ME App Service is not
 *          required to use this API when it does not receive a Termination
 *          Notification.
 */

#ifndef __MECFCGI__LIFECYCLEMANAGER__
#define __MECFCGI__LIFECYCLEMANAGER__

#include "PostRequestHandler.h"
#include "DelRequestHandler.h"

class AppLiveIndicator : public PostRequestHandler
{
public:
    /**
    * @brief            Allows an ME App/ME App Service to indicate to the ME
    *                   Platform that it is up and running after instantiation
    *                   and become authenticated.
    * @param[in]        request     JSON-formatted request body.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers, may contain token on
    *                               authentication success.
    * @param[in]        cookies     Not used here.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute (Json::Value &request, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

class AppTerminationIndicator : public DelRequestHandler
{
public:
    /**
    * @brief            Allows an ME App/ME App Service to indicate to the ME
    *                   Platform that is ready for termination after receiving
    *                   termination notification, or simply to indicate to the
    *                   ME Platform that it wish to have its informatin removed.
    * @param[in]        params      JSON-formatted params data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers, contains the token the ME
    *                               App/ME App Service received on
    *                               authentication success.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute(map<string, string> params, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};
#endif //__MECFCGI__LIFECYCLEMANAGER__
