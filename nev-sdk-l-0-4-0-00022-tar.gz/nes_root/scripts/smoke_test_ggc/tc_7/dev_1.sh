#!/usr/bin/expect
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

set timeout 10
log_user 0

spawn ssh -q -o StrictHostKeyChecking=no $::env(DEV1_USER)@$::env(DEV1_IP)

set timeout 20

#add routing
send "cd ~/$::env(ROUTE_ADD_PATH); PYTHONPATH=.. python $::env(ROUTE_ADD_NAME) -vDEBUG \
--root-ca=root-ca.pem \
--certificate=$::env(ROUTE_ADD_KEY).cert.pem \
--private-key=$::env(ROUTE_ADD_KEY).private.key \
--client-id=$::env(ROUTE_ADD_DEVICE_ID) \
--topic=$::env(ROUTE_ADD_TOPIC) $::env(ROUTE_ADD_MODE) \
--mec-action $::env(ROUTE_ADD_ACTION) $::env(ENDPOINT)\r"


expect {
    timeout { send_user "\nTimeout on $::env(DEV1_IP).\n"; exit 1}
    "*No such file or directory" { send_user "\nFailed to find directory on $::env(DEV1_IP)\n"; exit 1 }
    "*{\"result\": \"*successfully\"}*" { send_user "\nRoute added successfully.\n" }
}

set timeout 20
send "cd ~/$::env(SAMPLE_PATH); rm -rf groupCA; \
    PYTHONPATH=.. \
    python $::env(SCRIPT_NAME) \
        --endpoint $::env(ENDPOINT) \
        --rootCA root-ca.pem \
        --cert $::env(KEY_1).cert.pem \
        --key $::env(KEY_1).private.key \
        --thingName $::env(DEVICE_ID_1) \
        -m publish\r"

expect {
    timeout { send_user "\nTimeout on $::env(DEV1_IP)\n"; exit 1}
    "*No such file or directory" { send_user "\nFailed to find directory on $::env(DEV1_IP)\n"; exit 1 }
    "*Published topic sdk/test/Python*" { send_user "\nPublished topic.\n" }
    "*Error in discovery!*" { send_user "\nError in discovery!\n"; exit 1 }
}

set timeout 5
expect timeout { }

send "\x03"
send_user "\nTC_7 finished on $::env(DEV1_IP)\n"

send "exit\r"
close
