/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ******************************************************************************/
/**
 * @file Exception.cpp
 * @brief Implementation of Exception
*/

#include "Exception.h"

void Exception::handlerException(Exception e, string &res, string &statusCode)
{
    switch (e.code)
    {
    case Exception::REDIS_CONNECTIONPOOL:
    case Exception::REDIS_NO_REPLY:
    case Exception::REDIS_TYPE_MISMATCH:
    case Exception::REDIS_CONNECT_FAILD:
    case Exception::REDIS_COMMAND_ERROR:
    case Exception::REDIS_ARRAY_ELE_TYPE_MISMATCH:
    case Exception::DATA_BASE_FAILURE:
        statusCode = HTTP_SC_INTERNAL_SERVER_ERROR;
        res= "DatabaseFailure";
        break;
    case Exception::REDIS_NO_RESULT:
        statusCode = HTTP_SC_NOT_FOUND;
        res= "DatabaseNoResult";
        break;
    case Exception::INVALID_TYPE:
    case Exception::INVALID_PARAMETER:
        statusCode = HTTP_SC_BAD_REQUEST;
        res= "ParameterInvalid";
        break;
    case Exception::APPID_NOT_EXIST:
        statusCode = HTTP_SC_NOT_FOUND;
        res= "AppidNotExist";
        break;
    case Exception::INVALID_DATA_SCHEMA:
    case Exception::INVALID_SERVICE_INFO:
        statusCode = HTTP_SC_BAD_REQUEST;
        res= "InvalidServiceList";
        break;
    case Exception::SESSION_INV:
        statusCode = HTTP_SC_NOT_FOUND;
        res= "SessionNotExist";
        break;
    case Exception::NO_PERMISSION:
        res= "NoPermission";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::SECRET_WRONG:
        res= "SecretWrong";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::DUPLICATE_APPID:
        res= "AppidAuthenticated";
        statusCode = HTTP_SC_OK;
        break;
    case Exception::TRAFFIC_RULE_ERR:
        res= "TrafficRuleError";
        statusCode = HTTP_SC_INTERNAL_SERVER_ERROR;
        break;
    case Exception::SERVICE_EXIST:
        res= "ServiceExist";
        statusCode = HTTP_SC_OK;
        break;
    case Exception::SERVICE_NOT_EXIST:
        res= "ServiceNotExist";
        statusCode = HTTP_SC_NOT_FOUND;
        break;
    case Exception::ALREADY_SUBSCRIBED:
        res= "AlreadySubscribed";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::MISSING_SUBSCRIPTION:
        res= "MissingSubscription";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::NO_SUBSCRIPTION:
        res= "NoSubscription";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::DUPLICATE_SUBSCRIPTION:
        res= "DuplicateSubscription";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;        
    case Exception::INVALID_MAC_ADDRESS:
        res= "InvalidMacAddress";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::INVALID_VM_ID:
        res= "InvalidVMId";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::TRAFFIC_RULE_AUTHORITY_ERROR:
        res= "UnauthroizedTrafficRuleOp";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::SERVICE_DATA_NOT_EXIST:
        res= "ServiceDataNotExist";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::KEYFIELDS_NOT_EXIST:
        res= "KeyfieldsNotExist";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::UPDATE_DATA_NOT_EXIST:
        res= "UpdateDataNotExist";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::UNSUPPORTED_SERVICE_TYPE:
        res= "UnsupportedServiceType";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::INVALID_SERVICEID:
        res= "InvalidServiceId";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::INVALID_SERVICE_DATA:
        res= "InvalidServiceData";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::TRAFFIC_RULE_EXIST:
        res= "TrafficRuleExist";
        statusCode = HTTP_SC_OK;
        break;
    case Exception::UNKOWN_ERROR:
        res= "UnknownError";
        statusCode = HTTP_SC_INTERNAL_SERVER_ERROR;
        break;
    case Exception::Exception::INVALID_APPID:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "InvalidAppid";
        break;
    case Exception::INVALID_SECRET:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "InvalidSecret";
        break;
    case Exception::INVALID_PROVIDABLESERVICES:
        res = "InvalidProvidableServices";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::INVALID_SUBSCRIBABLESERVICES:
        res = "InvalidSubscribableServices";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::INVALID_SETTABLETRAFFICRULES:
        res = "InvalidSettableTrafficRules";
        statusCode = HTTP_SC_BAD_REQUEST;
        break;
    case Exception::INVALID_SERVICE_NAME:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "InvalidServiceName";
        break;
    case Exception::INVALID_TRAFFIC_RULE:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "InvalidTrafficRule";
        break;
    case Exception::INVALID_TIME_OUT_VALUE:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "InvalidTimeOutValue";
        break;
    case Exception::APP_NOT_RUNNING:
        statusCode = HTTP_SC_NOT_FOUND;
        res = "AppNotRunning";
        break;
    case Exception::HTTP_SYSTEM_ERROR:
        statusCode = HTTP_SC_INTERNAL_SERVER_ERROR;
        res= "HttpSystemError";
        break;
    case Exception::NO_SERVICE_NAME:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "NoServiceName";
        break;
    case Exception::NO_SERVICE_VERSION:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "NoServiceVersion";
        break;
    case Exception::NO_SERVICE_ENDPOINT:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "NoServiceEndPoint";
        break;
    case Exception::NO_SERVICE_TYPE:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "NoServiceType";
        break;
    case Exception::INVALID_SERVICE_TYPE:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "InvalidServiceType";
        break;
    case Exception::NO_SERVICE_DATASCHEMA:
        statusCode = HTTP_SC_BAD_REQUEST;
        res = "NoServiceDataSchema";
        break;
    default:
        statusCode = HTTP_SC_INTERNAL_SERVER_ERROR;
        res= "UnknownError";
        break;
    }
}