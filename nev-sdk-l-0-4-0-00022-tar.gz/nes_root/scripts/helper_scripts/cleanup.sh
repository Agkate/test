#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

#CLEANUP AFTER SIMULATION (stop applications, delete vm, networks and routers)

ip netns | xargs -L1 ip netns delete
echo "Old network namespaces deleted"

echo "Kill pktgen on control"
pkill -9 pktgen

echo "Kill l2fwd on control"
pkill -9 l2fwd

echo "Cleanup hugepages"
rm -rf /mnt/huge/*

echo "Kill NES daemon on compute"
ssh -f root@$COMPUTE_IP "pkill -9 nes"


echo "Deleting old VMs..."
var=($(nova list | awk 'NR>4 {print l} {l=$0}' |awk '{print $2}'))

if [ ! -z $var ]; then
	nova list | awk 'NR>4 {print l} {l=$0}' |awk '{print $2}' | xargs -L1 nova delete
	cnt=20
	sleep .5
	while [ ! -z $var ] && [ $cnt -ne 0 ]; do
		var=($(nova list | awk 'NR>4 {print l} {l=$0}' |awk '{print $2}'))
	        sleep 1
        	((cnt--))
	done

	if [ ! -z $var ]; then
		echo "Unable delete old VMs"
		echo "Script canceled"
		exit 1
	else
		echo "Old VMs deleted"
	fi
else
	echo "No VMs"
fi


if neutron router-list | grep -qs $PUBLICROUTER; then
	neutron router-gateway-clear $PUBLICROUTER
	neutron router-port-list $PUBLICROUTER | awk 'NR>4 {print l} {l=$0}' |awk '{print $8}' | sed 's/[",]//g'| xargs -L1 neutron router-interface-delete $PUBLICROUTER 
	neutron router-delete $PUBLICROUTER
	echo "Old routers deleted"
else
	echo "No routers"
fi

sleep .5

var=($(neutron port-list | awk 'NR>4 {print l} {l=$0}' |awk '{print $2}'))
if [ ! -z $var ]; then
	neutron port-list | awk 'NR>4 {print l} {l=$0}' |awk '{print $2}' | xargs -L1 neutron port-delete
	echo "Old ports deleted"
else
	echo "No ports"
fi

sleep .5

var=($(neutron net-list | awk 'NR>4 {print l} {l=$0}' |awk '{print $2}'))
if [ ! -z $var ]; then
	neutron net-list | awk 'NR>4 {print l} {l=$0}' |awk '{print $2}' | xargs -L1 neutron net-delete
	echo "Old networks deleted"
else
	echo "No nets"
fi

exit 0
