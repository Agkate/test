#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

VM0_CFG_MAC="52:54:00:00:00:01"
VM0_COM_MAC="de:ad:bb:ef:33:33"
VM1_CFG_MAC="52:54:00:00:00:02"
VM1_COM_MAC="de:ad:bb:ef:44:44"
VM2_CFG_MAC="52:54:00:00:00:03"
VM2_COM_MAC="de:ad:bb:ef:55:55"
VM3_CFG_MAC="52:54:00:00:00:04"
VM3_COM_MAC="de:ad:bb:ef:66:66"

function start_VM(){
    /usr/local/bin/qemu-system-x86_64 \
    -nographic \
    -enable-kvm -cpu host -m 4096 \
    -drive file=${1} \
    -object memory-backend-file,id=mem,size=4096M,mem-path=/mnt/huge-1048576kB/,share=on -numa node,memdev=mem -mem-prealloc \
    -device virtio-net-pci,netdev=net0,mac=${3} \
    -netdev type=tap,id=net0 \
    -chardev socket,id=char1,path=/usr/bin/usvhost-1 \
    -netdev type=vhost-user,id=mynet1,chardev=char1 \
    -device virtio-net-pci,mac=${2},netdev=mynet1,id=net1,csum=off,gso=off,guest_csum=off,guest_tso4=off,guest_tso6=off,guest_ecn=off &
    test $? = 0 || exit -1
}

case $2 in
"0" ) start_VM $1 ${VM0_CFG_MAC} ${VM0_COM_MAC} ;;
"1" ) start_VM $1 ${VM1_CFG_MAC} ${VM1_COM_MAC} ;;
"2" ) start_VM $1 ${VM2_CFG_MAC} ${VM2_COM_MAC} ;;
"3" ) start_VM $1 ${VM3_CFG_MAC} ${VM3_COM_MAC} ;;
*)
{
    echo "ERROR VM Num:$1"
    exit -1
}
;;
esac

exit 0