/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
 * @file nes_tcp_connection.c
 * @brief tcp server connection
 */
#include <assert.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "ctrl/nes_tcp_connection.h"
#include "nes_common.h"

#define MAX_IP_ADDR_LEN 16
#define MIN_IP_ADDR_LEN 7
#define PORTS_NUMBER    1024

#ifdef EXT_CTRL_SOCKET
int nes_connection_setup(const char *ip_addr, uint16_t port_nr, tcp_connection_t *conn)
{
    assert(NULL != conn);
    assert(NULL != ip_addr);
    assert(MAX_IP_ADDR_LEN >= strlen(ip_addr));
    assert(MIN_IP_ADDR_LEN <= strlen(ip_addr));
    assert(PORTS_NUMBER < port_nr);

    in_addr_t ip_addr_inet;
    int opt = 1;

    conn->addr_len = sizeof(struct sockaddr);
    ip_addr_inet = inet_addr(ip_addr);
    conn->listen_sock = socket(AF_INET, SOCK_STREAM, 0);

    if( 0 > conn->listen_sock ) {
        NES_LOG(ERR, "Error creating listening socket.\n");
        return NES_FAIL;
    }

    if( setsockopt(conn->listen_sock, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt)) < 0 ) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    memset(&conn->local_addr, 0, sizeof(struct sockaddr_in));
    memset(&conn->remote_addr, 0, sizeof(struct sockaddr_in));
    conn->local_addr.sin_family      = AF_INET;
    conn->local_addr.sin_addr.s_addr = htonl(ip_addr_inet);
    conn->local_addr.sin_port        = htons(port_nr);
    if( bind(conn->listen_sock, (struct sockaddr *)&conn->local_addr, sizeof(struct sockaddr_in))) {
       NES_LOG(ERR, "Error biding listening socket.\n");
       return NES_FAIL;
    }

   if( listen(conn->listen_sock, 5)) {
        NES_LOG(ERR, "Error listening on socket.\n");
        return NES_FAIL;
    }
   fprintf(stderr, "\n\nStarting to listen on port %d\n\n", port_nr);


    return NES_SUCCESS;
}
#endif

int nes_connection_un_setup(const char *socket_path, tcp_connection_t *conn)
{
    assert(NULL != conn);
    assert(NULL != socket_path);

    conn->addr_len = sizeof(struct sockaddr);
    conn->listen_sock = socket(AF_UNIX, SOCK_STREAM, 0);

    if( 0 > conn->listen_sock ) {
        NES_LOG(ERR, "Error creating listening socket.\n");
        return NES_FAIL;
    }

    memset(&conn->local_un_addr, 0, sizeof(struct sockaddr_un));
    memset(&conn->remote_addr, 0, sizeof(struct sockaddr_in));
    conn->local_un_addr.sun_family      = AF_UNIX;
    strncpy( conn->local_un_addr.sun_path, socket_path, sizeof(conn->local_un_addr.sun_path)-1);
    conn->local_un_addr.sun_path[sizeof(conn->local_un_addr.sun_path)-1] = 0;
    unlink(conn->local_un_addr.sun_path);
    if( bind(conn->listen_sock, (struct sockaddr *)&conn->local_un_addr, sizeof(struct sockaddr_un)) ) {
       NES_LOG(ERR, "Error biding listening socket.\n");
       return NES_FAIL;
    }

    if( listen(conn->listen_sock, 5)) {
        NES_LOG(ERR, "Error listening on socket.\n");
        return NES_FAIL;
    }
    fprintf(stderr, "\n\nStarting to listen on socket %s\n\n", conn->local_un_addr.sun_path);

    return NES_SUCCESS;
}
