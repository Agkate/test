#!/usr/bin/env python

###################################################################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
###################################################################################################

# Standard library imports:
import json
import os
import signal
import time
import sys

# GG/MEC imports:
from ggmec import make_thing_parser, retrieve_ggc_conf, setup_logger, setup_mqtt_shadow_client

def subscribe_cb(client, userdata, message):
    _LOG.info("Received a message for topic {0}".format(message.topic))
    _LOG.debug("Message payload:\n{0}".format(message.payload))


def make_shadow_delta_cb(handler):
    def __shadow_delta_cb(payload, responseStatus, token):
        data = json.loads(payload)
        light = data["state"]["property"]

        _LOG.info(
            "Received Shadow Delta message (property={0}, version={0})"
            "".format(light, data["version"]))

        out_data = {
            "state": {
                "reported": {
                    "property": light
                }
            }
        }
        out_payload = json.dumps(data)

        _LOG.info("Payload data to be used for shadow update: {0:s}".format(out_payload))
        handler.shadowUpdate(out_payload, shadow_update_cb, 5)
    return __shadow_delta_cb


def shadow_update_cb(payload, responseStatus, token):
    # payload is a JSON string ready to be parsed using json.loads(...)
    # in both Py2.x and Py3.x
    if responseStatus == "timeout":
        _LOG.info("Update request {0:s} time out".format(token))
    elif responseStatus == "accepted":
        data = json.loads(payload)
        _LOG.info(
            "Update request with token {0:s} accepted (property='{1:s}')"
            "".format(token, data["state"]["reported"]["property"]))
    elif responseStatus == "rejected":
        _LOG.info("Update request {0:s} rejected".format(token))


def main(options):
    ggc_conf = retrieve_ggc_conf(options)

    if ggc_conf is None:
        _LOG.critical("Failed to retrieve GG Core configuration")
        return 1

    shadowClient = setup_mqtt_shadow_client(options, ggc_conf['host'], ggc_conf['path'])
    if not shadowClient.connect():
        _LOG.critical("AWS IoT connection failed")
        return 2
    else:
        _LOG.debug("AWS IoT connection established successfully")

    handler = shadowClient.createShadowHandlerWithName(options.thing_name, True)
    handler.shadowRegisterDeltaCallback(make_shadow_delta_cb(handler))

    client2 = shadowClient.getMQTTConnection()
    client2.subscribe("hello/world/pubsub", 1, subscribe_cb)

    # Loop forever
    while True:
	time.sleep(1)

if __name__ == '__main__':
    options = make_thing_parser().parse_args()
    _LOG = setup_logger(options)
    sys.exit(main(options))
