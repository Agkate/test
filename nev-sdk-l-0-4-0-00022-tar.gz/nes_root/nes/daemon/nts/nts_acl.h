/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file nts_acl.h
 * @brief Header file for nts_acl
 */
#ifndef NTS_ACL_H
#define	NTS_ACL_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <rte_acl.h>
#include <rte_spinlock.h>

#include "nes_common.h"
#include "nts/nts_acl_cfg.h"
    
int nts_acl_lookup_init(nes_acl_ctx_t* lookup_ctx);

void nts_acl_lookup_dtor(nes_acl_ctx_t* lookup_ctx);

int nts_acl_lookup_add_vm(nes_acl_ctx_t* lookup_ctx, char* lookup_str, struct ether_addr vm_mac_addr, nts_edit_modes_t edit_mode);

int nts_acl_lookup_remove(nes_acl_ctx_t* lookup_ctx, char* lookup_str);

int nts_acl_lookup_find(nes_acl_ctx_t* lookup_ctx, char* lookup_str, nes_sq_t **upstream_route, nes_sq_t **downstream_route);

int nts_acl_add_lbp_entries(nes_acl_ctx_t* lookup_ctx);

void nts_acl_flush(nes_acl_ctx_t* lookup_ctx);

#ifdef	__cplusplus
}
#endif

#endif	/* NTS_ACL_H */

