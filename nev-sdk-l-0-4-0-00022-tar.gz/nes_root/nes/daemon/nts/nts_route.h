/************************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
************************************************************************************/
/**
* @file nts_route.h
* @brief Routing related definitions
*/
#ifndef _NTS_ROUTE_H_
#define _NTS_ROUTE_H_

#ifdef __cpluplus
extern "C" {
#endif

#include <rte_mbuf.h>
#include "nes_ring.h"
    
#define NTS_ENCAP_VLAN_FLAG (1<<0)   
#define NTS_ENCAP_GTPU_FLAG (1<<1)   
    
typedef struct nts_route_entry_s {
    const char *ring_name;
    nes_ring_t *dst_ring;
    uint32_t    ip_addr;
    struct ether_addr mac_addr;
    int (*edit)(struct nts_route_entry_s *, struct rte_mbuf *, int, void *);
} nts_route_entry_t;

typedef struct nts_enc_subentry_s {
    struct ether_addr dst_mac_addrs;
    struct ether_addr src_mac_addrs;
    uint32_t           ue_ip;
    uint32_t           dst_ip;
    uint32_t           src_ip;
    uint16_t           dst_ip_port;
    uint16_t           src_ip_port;
    uint32_t           teid;
    uint8_t            encap_flag;
    uint16_t           vlan_tci;
    nes_ring_t         *dst_ring;
} nts_enc_subentry_t;

typedef struct nts_enc_entry_s {
    nts_enc_subentry_t upstream;
    nts_enc_subentry_t downstream;
} nts_enc_entry_t;

#ifdef __cpluplus
}
#endif

#endif /* _NTS_ROUTE_H_ */

