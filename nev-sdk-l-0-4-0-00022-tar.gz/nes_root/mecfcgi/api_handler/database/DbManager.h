/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file     DbManager.h
* @brief    Database manager for Mobile Edge Applications.
*/

#ifndef __MECFCGI__DBMANAGER__
#define __MECFCGI__DBMANAGER__

#include "Redis.h"
#include <json/json.h>

class DbManager
{
public:
    typedef Redis::StringArrayType StringArrayType;
    /**
    * @brief        Deletes data associated with a key from database.
    * @param[in]    key             Key that identifies a record in database.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void delDataByKey(string key);

    /**
    * @brief        Tries to get an ME App's type from database using its App 
    *               ID.
    * @exist[out]   exist           Indication of whether the ME App's type 
    *                               exists.
    * @param[out]   appType         ME App's type.
    * @param[in]    appid           ME App's ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void checkAndGetAppTypeByAppid(bool &exist, string &appType,
                                            string appid);

    /**
    * @brief        Tries get an ME App's token from database using its App ID.
    * @param[out]   exist           Indication of whether the ME App's token 
    *                               exists.
    * @param[out]   token           ME App's token (reference ID).
    * @param[in]    appid           ME App's ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void checkAndGetTokenByAppid(bool &exist, string &token,
                                        string appid);

    /**
    * @brief        Gets a list of session IDs from database using an App ID.
    * @param[out]   sessionIdList   List of session IDs.
    * @param[in]    appid           ME App's ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getSessionIdListByAppid(StringArrayType &sessionIdList,
                                        string appid);

    /**
    * @brief        Gets a list of session IDs from database using a session ID.
    * @param[out]   sessionIdList   List of session IDs.
    * @param[in]    sessionId       Session ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getSessionIdListBySessionId(StringArrayType &sessionIdList,
                                            string sessionId);

    /**
    * @brief        Deletes a session ID from database.
    * @param[in]    sessionId       Session ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void delSessionIdBySessionId(string sessionId);

    /**
    * @brief        Adds a session ID to database.
    * @param[in]    appid           ME App's ID.
    * @param[in]    sessionId       Session ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void addSessionId(string appid, string sessionId);

    /**
    * @brief        Saves an ME App's type and token into database.
    * @param[in]    appid           ME App's ID.
    * @param[in]    apptype         ME App's type.
    * @param[in]    token           ME App's token (reference ID).
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void saveMeAppInfo(string appid, string apptype, string token);

    /**
    * @brief        Clears an ME App's information from database using App ID.
    * @param[in]    appid           ME App's ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void clearMeAppInfo(string appid);

    /**
    * @brief        Adds an activated service to database.
    * @param[in]    token           ME App's token (reference ID).
    * @param[in]    serviceName     Name representing a service provided by an
    *                               ME App Service.
    * @param[in]    serviceId       Service ID.
    * @param[in]    endPoint        Service endpoint URL.
    * @param[in]    version         Service version.
    * @param[in]    serviceType     Service type.
    * @param[in]    dataSchemaCvt   JSON Schema specifying the format of service 
    *                               data.
    * @param[in]    dataSchema      JSON Schema specifying the format of service 
    *                               data.
    * @throw        Exception   Thrown on failure.
    * @return       void
    */
    static void addActivatedService(string token, string serviceName,
                                    string serviceId, string endPoint,
                                    string version, string serviceType,
                                    string dataSchemaCvt, string dataSchema);

    /**
    * @brief        Gets a service name from database using a service ID.
    * @param[out]   serviceName     Name representing a service provided by an
    *                               ME App Service.
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getActivatedServiceName(string serviceId, string &serviceName);

    /**
    * @brief        Gets a token from database using a service ID.
    * @param[out]   token           ME App's token (reference ID).
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getActivatedServiceToken(string serviceId, string &token);

    /**
    * @brief        Gets a service's version from database using a service ID.
    * @param[out]   version         Service version.
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getActivatedServiceVersion(string serviceId, string &version);

    /**
    * @brief        Gets a service's endpoint from database using a service ID.
    * @param[out]   endPoint        Service endpoint URL.
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getActivatedServiceEndPoint(string serviceId, string &endPoint);

    /**
    * @brief        Gets an active service's type from database using a
    *               service ID.
    * @param[out]   serviceType     Service type.
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getActivatedServiceServiceType(string serviceId,
                                                string &serviceType);

    /**
    * @brief        Gets a data schema from database using a service ID.
    * @param[out]   dataSchemaCvt   JSON Schema specifying the format of service
    *                               data.
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getActivatedServiceDataSchemaCvt(string serviceId,
                                                string &dataSchemaCvt);

    /**
    * @brief        Gets a data schema from database using a service ID.
    * @param[out]   dataSchema      JSON Schema specifying the format of service
    *                               data.
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getActivatedServiceDataSchema(string serviceId,
                                                string &dataSchema);

    /**
    * @brief        Deletes a service from database.
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void delActivatedServiceByServiceId(string serviceId);

    /**
    * @brief        Gets all active services from database.
    * @param[out]   serviceIdList   List of active services' IDs .
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getActivatedServiceIdList(StringArrayType &serviceIdList);

    /**
    * @brief        Gets the session associated with a appid.
    * @param[out]   token           ME App's token (reference ID).
    * @param[in]    appid           ME App's ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getSessionByAppid(string &token, string appid);

    /**
    * @brief        Adds a service to database.
    * @param[in]    token           ME App's token (reference ID).
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void addServiceSubscription(string token, string serviceId);

    /**
    * @brief        Adds a list of service subscriptions to database.
    * @param[in]    token           ME App's token (reference ID).
    * @param[in]    serviceList     List of service IDs.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void addServiceSubscription(string token, Json::Value serviceList);

    /**
    * @brief        Gets a list of service subscriptions from database using a
    *               token.
    * @param[out]   serviceIdList   List of subscribed services' IDs.
    * @param[in]    token           ME App's token (reference ID).
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getServiceSubscriptionListByToken(
                                                StringArrayType &serviceIdList,
                                                string token);

    /**
    * @brief        Deletes service subscriptions from database using a token.
    * @param[in]    token           ME App's token (reference ID).
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void delServiceSubscriptionListByToken(string token);

    /**
    * @brief        Gets the subscription status of a service using a service ID
    *               and token.
    * @param[out]   subscribed      Subscription status of a service.
    * @param[in]    token           ME App's token (reference ID).
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getServiceSubscriptionStatus(bool &subscribed, string token,
                                                string serviceId);

    /**
    * @brief        Gets the subscribers of a service using a service ID and
    *               token.
    * @param[out]   subscriberList  Subscribers of a service.
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getSubscriberByServiceId(StringArrayType &subscriberList,
                                            string serviceId);

    /**
    * @brief        Deletes service subscriptions from database using a token
    *               and service ID.
    * @param[in]    token           ME App's token (reference ID).
    * @param[in]    serviceId       Service ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void delSubscribedServiceByTokenAndServiceId(string token,
                                                        string serviceId);

    /**
    * @brief        Saves service data in database.
    * @param[in]    dataKeys        Keys in service data, consists of service ID
    *                               and key fields.
    * @param[in]    serviceData     Data structure used for data update and
    *                               publication.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void saveServiceData(string dataKeys, string serviceData);

    /**
    * @brief        Gets service data from database.
    * @param[in]    dataKeys        Keys in service data, consists of service ID
    *                               and key fields.
    * @param[out]   serviceData     Data structure used for data update and
    *                               publication.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getServiceData(string dataKeys, string &serviceData);

    /**
    * @brief        Adds traffic rule information for an ME App to database.
    * @param[in]    trafficRuleId   Traffic rule ID.
    * @param[in]    token           ME App's token (reference ID).
    * @param[in]    lookupKeys      Set of look-up keys associated with one or
    *                               more traffic rules.
    * @param[in]    macAddress      Virtual machine's M.A.C. address.
    * @param[in]    vmId            Virtual machine's ID.
    * @param[in]    trafficRule     Traffic rule specification indicating the
    *                               data routing and forwarding criteria for the
    *                               data plane.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void addTrafficRulesInfo(string trafficRuleId, string token,
                                    string lookupKeys, string macAddress,
                                    uint32_t vmId, string trafficRule);

    /**
    * @brief        Gets traffic rule information for an ME App from database
    *               using a traffic rule ID.
    * @param[in]    trafficRuleId   Traffic rule ID.
    * @param[out]   isFound         Indication of whether a traffic rule is 
    *                               found.
    * @param[out]   lookupKeys      Set of look-up keys associated with one or
    *                               more traffic rules.
    * @param[out]   trafficRule     Traffic rule specification indicating the 
    *                               data routing and forwarding criteria for the
    *                               data plane.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getTrafficRuleInfoByTrafficRuleId(bool &isFound,
                                                    string trafficRuleId,
                                                    string &lookupKeys,
                                                    string &trafficRule);

    /**
    * @brief        Gets traffic rule information for an ME App from database
    *               using a traffic rule ID.
    * @param[in]    trafficRuleId   Traffic rule ID.
    * @param[out]   trafficRule     Traffic rule specification indicating the 
    *                               data routing and forwarding criteria for the
    *                               data plane.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getTrafficRuleInfoByTrafficRuleId(string trafficRuleId,
                                                    string &trafficRule);
    /**
    * @brief        Gets a list of all traffic rule IDs from database.
    * @param[out]   trafficRuleIdList   List of all traffic rule IDs.
    * @throw        Exception           Thrown on failure.
    * @return       void
    */
    static void getTrafficRuleIdList(StringArrayType &trafficRuleIdList);

    /**
    * @brief        Gets an ME App's token from database using a traffic rule
    *               ID.
    * @param[in]    trafficRuleId   Traffic rule ID.
    * @param[out]   token           ME App's token (reference ID).
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getTrafficRuleTokenByRuleId(string &token,
                                            string trafficRuleId);

    /**
    * @brief        Gets traffic rule lookup keys for an ME App from database
    *               using a traffic rule ID.
    * @param[in]    trafficRuleId   Traffic rule ID.
    * @param[out]   lookupKeys      Set of look-up keys associated with one or
    *                               more traffic rules.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getTrafficRuleLookupByRuleId(string &lookupKeys,
                                                string trafficRuleId);

    /**
    * @brief        Gets traffic rule MAC Address from database using a traffic
    *               rule ID.
    * @param[out]   macAddress      Set of MAC address associated with one or
    *                               more traffic rules.
    * @param[in]    trafficRuleId   Traffic rule ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getTrafficRuleMacAddressByRuleId(string &macAddress,
                                                    string trafficRuleId);
    /**
    * @brief        Gets traffic rule VM ID from database.
    * @param[out]   vmId            Virtual machine's ID.
    * @param[in]    trafficRuleId   Traffic rule ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void getTrafficRuleVmIdByRuleId(string &vmId, string trafficRuleId);

    /**
    * @brief        Deletes traffic rule information for an ME App from
    *               database.
    * @param[in]    trafficRuleId   Traffic rule ID.
    * @throw        Exception       Thrown on failure.
    * @return       void
    */
    static void delTrafficRulesInfo(string trafficRuleId);
};

#endif //__MECFCGI__DBMANAGER__
