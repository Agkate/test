/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file  ServiceRegistryPort.cpp
* @brief Implementation of ServiceRegistryPort.
*/

#include "ServiceRegistryPort.h"
#include "Exception.h"
#include "DbManager.h"
#include "HttpsMaster.h"
#include "SessionManager.h"
#include "HandlerCommon.h"

const string BASE_URL = "/serviceregistry/v1";
ServiceRegistryPort::serviceRegistry_info_t
    ServiceRegistryPort::serviceRegistryInfo;

string ServiceRegistryPort::PlatformProducerAppid = "";
string ServiceRegistryPort::PlatformProducerSecret = "";

void ServiceRegistryPort::setServiceRegistryInfo(string hostIp, 
                                                    uint16_t hostPort)
{
    serviceRegistryInfo.ip = hostIp;
    serviceRegistryInfo.port = hostPort;
}

void ServiceRegistryPort::setPlatformProducerAppInfo(string appid, string secret)
{
    PlatformProducerAppid = appid;
    PlatformProducerSecret = secret;
}

void ServiceRegistryPort::sendMessageToServiceRegistry(string url, 
                                                        string method, 
                                                        Json::Value request, 
                                                        string &status, 
                                                        Json::Value &response)
{
    HttpsMaster requestMaster;
    string respBody = "";
    Json::Reader reader;    
    requestMaster.connect(ServiceRegistryPort::serviceRegistryInfo.ip, 
        ServiceRegistryPort::serviceRegistryInfo.port);
    requestMaster.httpsRequest(url, method, request, "application/json");
    try {
        requestMaster.httpsResponse(status, respBody);
        requestMaster.disconnect();
    }
    catch (Exception &e) {
        throw;
    }
    reader.parse(respBody, response);
}

void ServiceRegistryPort::saveMeAppConfiguration(string &result, 
                                                    Json::Value request)
{
    string status = "";
    Json::Value response;
    string URL = BASE_URL + "/configure";
    sendMessageToServiceRegistry(URL, "POST", request, status, response);
    result = response.get("result", "Nil").asString();
}

void ServiceRegistryPort::removeMeAppConfiguration(string &result, string appid)
{
    string status = "";
    Json::Value response;
    string URL = BASE_URL + "/configure/" + appid;
    sendMessageToServiceRegistry(URL, "DELETE", "", status, response);
    result = response.get("result", "Nil").asString();
}

void ServiceRegistryPort::checkPolicyForMeApp(string &result, string appid, 
                                              string secret, string appType)
{
    if (0 != appType.compare(MEAPP_TYPE_PFPRODUCERAPP)) {
        string status = "";
        Json::Value request;
        Json::Value response;
        request["appid"] = appid;
        request["secret"] = secret;
        string URL = BASE_URL + "/policy/app";
        sendMessageToServiceRegistry(URL, "POST", request, status, response);
        result = response.get("result", "Nil").asString();
    } else {
        if (0 != appid.compare(PlatformProducerAppid)) {
            result = "NoPermission";
        } else {
            if (0 != secret.compare(PlatformProducerSecret)) {
                result = "SecretWrong";
            } else {
                result ="OK";
            }
        }
    }

}

void ServiceRegistryPort::checkPolicyForService(string &result, ACTION action, 
                                                string appid, 
                                                string serviceName)
{

    bool exist = false;
    string appType;
    DbManager::checkAndGetAppTypeByAppid(exist, appType, appid);
    if ((0 != appType.compare(MEAPP_TYPE_MEAPPSERVICE)) && 
        (0 != appType.compare(MEAPP_TYPE_PFPRODUCERAPP))) {
        result = "NoPermission";
        return;
    }
    if (0 == appType.compare(MEAPP_TYPE_PFPRODUCERAPP)) {
        result = "OK";
        return;
    }

    result = "";
    string status = "";
    Json::Value response;
    Json::Value request;
    request["appid"] = appid;
    request["serviceName"] = serviceName;
    string URL = BASE_URL + "/policy/service";
    sendMessageToServiceRegistry(URL, "POST", request, status, response); 
    string res;
    res = response.get("result","Nil").asString();
    if (0 != res.compare("OK")) {
        result = res;
        return;
    }
    
    if (ACTION_ACTIVATION_SERVICE == action) {
        result = "OK";
    } else if (ACTION_DEACTIVATION_SERVICE == action) {
        string isDeactivationPermited = 
            response.get("isDeactivationPermited","Nil").asString();
        if (0 == isDeactivationPermited.compare("YES")) {
            result = "OK";
        } else {
            result = "NoPermission";
        }
    } else {
        result = "InvalidAction";
    }
}

void ServiceRegistryPort::checkPolicyForSubscriber(bool &isPass, ACTION action, 
                                                    string appid, 
                                                    Json::Value 
                                                    subscriptionServiceList)
{
    isPass = true;
    Json::Value policyServiceList;
    ServiceRegistryPort::
        getSubscriptionServiceListFromServiceRegistry(policyServiceList, appid);
    
    int subscriptionServiceListSize = subscriptionServiceList.size();
    int size = policyServiceList.size();
    for (int i = 0; i < subscriptionServiceListSize; i++){
        string subscriptionServiceId = 
            subscriptionServiceList[i].get("serviceId", "Nil").asString();
        string subscriptionProviderAppToken = "";
        string subscriptionProviderAppId = "";
        string subscriptionServiceName = "";
        DbManager::getActivatedServiceToken(subscriptionServiceId, 
                                            subscriptionProviderAppToken);
        if (0 == subscriptionProviderAppToken.compare("")) {
            isPass = false;
            return;
        }
        SessionManager::getAppidBySession(subscriptionProviderAppToken, 
                                            subscriptionProviderAppId);
        DbManager::getActivatedServiceName(subscriptionServiceId, 
                                            subscriptionServiceName);
        bool isMatch = false;
        for (int j = 0; j < size; j++) {
            string providerAppId = 
                policyServiceList[j].get("providerAppId", "Nil").asString();
            string serviceName = 
                policyServiceList[j].get("serviceName", "Nil").asString();
            string isUnsubscriptionPermitted = policyServiceList[j].get(
                "isUnsubscriptionPermitted", "").asString();
            if (0 == providerAppId.compare(subscriptionProviderAppId) && 
                0 == serviceName.compare(subscriptionServiceName)) {
                if (ACTION_SUBSCRIPTION_SERVICE == action) {
                    isMatch = true;
                } else if (ACTION_UNSUBSCRIPTION_SERVICE == action) {
                    if (0 == isUnsubscriptionPermitted.compare("YES")) {
                        isMatch = true;
                    }
                }
                break;
            }
        }
        if (!isMatch){
            isPass = false;
            break;
        }
    }
}

void ServiceRegistryPort::checkPolicyForSubscriber(bool &isPass, ACTION action, 
                                                    string appid, 
                                                    string serviceId)
{
    Json::Value subscriptionServiceList = Json::Value(Json::arrayValue);
    Json::Value service;
    service["serviceId"] = serviceId;
    subscriptionServiceList.append(service);
    ServiceRegistryPort::checkPolicyForSubscriber(isPass, action, appid, 
                                                    subscriptionServiceList);
}

void ServiceRegistryPort::checkPolicyForTrafficRule(bool &isPass, ACTION action,
                                                    string appid, 
                                                    Json::Value trafficRule)
{
    string status = "";
    isPass = false;
    Json::Value request;
    Json::Value response;
    request = trafficRule;
    request["appid"] = appid;
    string URL = BASE_URL + "/policy/trafficrule";    
    sendMessageToServiceRegistry(URL, "POST", request, status, response);
    string result = response.get("result", "Nil").asString();
    if (0 == result.compare("OK")) {
        if (ACTION_CREATE_TRAFFIC_RULE == action) {
            isPass = true;
        } else if (ACTION_UPDATE_TRAFFIC_RULE == action) {
            string isUpdatePermitted = 
                response.get("isUpdatePermitted", "Nil").asString();
            if (0 == isUpdatePermitted.compare("YES")) {
                isPass = true;
            }
        } else if (ACTION_REMOVE_TRAFFIC_RULE == action) {
            string isRemovalPermitted = 
                response.get("isRemovalPermitted", "Nil").asString();
            if (0 == isRemovalPermitted.compare("YES")) {
                isPass = true;
            }
        } else {
            result = "InvalidAction";
        }
    }
}

void ServiceRegistryPort::getAppidListFromServiceRegistry(
                                                        Json::Value &appidList, 
                                                        string serviceName, 
                                                        string providerAppId)
{
    string status = "";
    Json::Value response;
    Json::Value request;        
    request["serviceName"] = serviceName;
    request["providerAppid"] = providerAppId;
    string URL = BASE_URL + "/policy/subscriber";
    sendMessageToServiceRegistry(URL, "POST", request, status, response);
    if (0 == response.get("result","Nil").asString().compare("OK")) {
        appidList = response.get("appids","Nil");
    } else {
        appidList = "Nil";
    }
}

void ServiceRegistryPort::getSubscriptionServiceListFromServiceRegistry(
                                                    Json::Value &serviceList,
                                                    string appid)
{
    string status = "";
    Json::Value response;
    string URL = BASE_URL + "/policy/subscriber/" + appid;
    sendMessageToServiceRegistry(URL, "GET", "", status, response);
    if (0 == response.get("result","Nil").asString().compare("OK")) {
        serviceList = response.get ("services","Nil");
    } else {
        serviceList = "Nil";
    }
}


