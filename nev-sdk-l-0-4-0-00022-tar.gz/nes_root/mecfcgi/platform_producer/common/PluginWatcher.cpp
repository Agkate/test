/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    PluginWatcher.cpp
 * @brief   Implementation of PluginWatcher.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <sys/inotify.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include "PluginWatcher.h"
#include "PluginManager.h"
#include "Log.h"

#define EVENT_SIZE  ( sizeof (struct inotify_event) )
#define BUF_LEN     ( 100 * ( EVENT_SIZE + 32 ) )

PluginWatcher::PluginWatcher()
{
    pPluginManager = NULL;
    sPluginPath = "";
    runFlag = false;
}

PluginWatcher::~PluginWatcher(void)
{

}

bool PluginWatcher::init(string &path,PluginManager *pm)
{
    pPluginManager = pm;
    sPluginPath = path;
    return true;
}

void PluginWatcher::stop()
{
    runFlag = false;
}

void PluginWatcher::watchProc()
{
    int fd;
    int wd;
    int len;
    int nread;
    char buf[BUF_LEN];
    struct inotify_event *event;

    fd = inotify_init();
    if( fd < 0 ) {
        MECFCGI_LOG(ERR, "inotify_init failed");
        return;
    }

    wd = inotify_add_watch(fd, sPluginPath.c_str(),  IN_ALL_EVENTS);
    if(wd < 0) {
        MECFCGI_LOG(ERR, "inotify_add_watch failed, path:%s", sPluginPath.c_str());
        return;
    }

    buf[sizeof(buf) - 1] = 0;
    runFlag = true;

    while( runFlag ) {
        len = read(fd, buf, sizeof(buf) - 1);
        nread = 0;
        while( len > 0 ) {
            event = (struct inotify_event *)&buf[nread];

            if( event->mask & IN_ISDIR  ) {
                nread = nread + sizeof(struct inotify_event) + event->len;
                len = len - sizeof(struct inotify_event) - event->len;
                continue;
            } else if ( event->mask & IN_DELETE ) {
                if(event->len > 0) {
                    if(pPluginManager != NULL) {
                        pPluginManager->unLoad(event->name);
                    }
                }
            } else if ( event->mask & IN_CLOSE_WRITE ) {
                if(event->len > 0) {
                    if(pPluginManager != NULL) {
                        pPluginManager->loadAndCheck(event->name);
                    }
                }
            } else if ( event->mask & IN_MOVED_FROM ) {
                if(event->len > 0) {
                    if(pPluginManager != NULL) {
                        pPluginManager->unLoad(event->name);
                    }
                }
            } else if ( event->mask & IN_MOVED_TO ) {
                if(event->len > 0) {
                    if(pPluginManager != NULL) {
                        pPluginManager->loadAndCheck(event->name);
                    }
                }
            } else {
                MECFCGI_LOG(WARNING, 
                    "watcher detected a file event that is not create or delete: ignore:%s", 
                    event->name);
            }
            nread = nread + sizeof(struct inotify_event) + event->len;
            len = len - sizeof(struct inotify_event) - event->len;
        }
    }
    inotify_rm_watch( fd, wd );
    close( fd );
}
