/*******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    SubscribeManager.h
 * @brief   Classes of handlers responsible for handling Mobile Edge Service 
 *          Subscription.
 *
 *          <Mobile Edge Service Subscription/Subscriptions Update>
 *          Once an ME App/ME App Service has been authenticated by the ME
 *          Platform, the ME App/ME App Service can subscribe to services on
 *          the ME Platform using the service information it received by
 *          service discovery.
 *          An ME App may subscribe to a service by sending a single Service
 *          Subscription Request, it may also subscribe to multiple services or
 *          update its service subscriptions by sending a Subscriptions Update
 *          Request. The request fails if the requested service cannot be
 *          subscribed to.
 *          This is a mandatory API. An ME application cannot perform service
 *          subscription-related operations without using this API.
 *
 *          <Mobile Edge Service Unsubscription/Subscriptions Reset>
 *          An ME App/ME App Service with service subscriptions may cancel
 *          individual service subscription by sending a Service Unsubscription
 *          Request. Alternatively, and it may also delete all of its service
 *          subscriptions at once by sending a Subscriptions Reset Request.
 *          This is an optional API. An ME application is not required to
 *          unsubscribe from services using this API.
 */


#ifndef __MECFCGI__SUBSCRIBEMANAGER__
#define __MECFCGI__SUBSCRIBEMANAGER__

#include "PutRequestHandler.h"
#include "DelRequestHandler.h"
#include "GetRequestHandler.h"

class AddSubscription : public GetRequestHandler
{
public:
    /**
    * @brief            Handles REST API requests for subscribing to an ME
    *                   Service.
    * @param[in]        params      JSON-formatted params data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Respsonse headers.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute(map<string, string> params, Json::Value &response, map<string,
                 string> &headers, map<string, string> &cookies);
};

class UpdateSubscripion : public PutRequestHandler
{
public:
    /**
    * @brief            Handles REST API Rrquests for updating an ME
    *                   App's service subscriptions.
    * @param[in]        request     JSON-formatted request data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */

    void execute(Json::Value &request, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

class DelSubscripion : public DelRequestHandler
{
public:
    /**
    * @brief            Handles REST API requests for deleting a subscription to
    *                   an ME Service.
    * @param[in]        params      JSON-formatted params data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute(map<string, string> params, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

class ResetSubscripion : public DelRequestHandler
{
public:
    /**
    * @brief            Handles REST API requests for clearing all of an ME
    *                   application's service subscriptions.
    * @param[in]        params      JSON-formatted params data.
    * @param[out]       response    JSON-formatted key-value pair(s) indicating
    *                               response.
    * @param[out]       headers     Response headers.
    * @param[in]        cookies     Cookies header in request.
    * @throw            Exception   Thrown on failure.
    * @return           void
    */
    void execute(map<string, string> params, Json::Value &response,
                 map<string, string> &headers, map<string, string> &cookies);
};

#endif //__MECFCGI__SUBSCRIBEMANAGER__