#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

#Check if variables are already exported, return if they are
#if [ ! -z $GLOBAL_FSC ]; then
#	return
#fi

export NES_DIR='/root/nes_latency/scripts'
export COMPUTE_IP='10.237.214.187'

export VM1_NAME='vm0'
export BOOT_IMAGE='test2901'

export PHYSNET1='physnet1'
export PHYSNET2='physnet2'

export MGMT_NET='tenant-mgmt-net'
export MGMT_SUBNET='tenant-mgmt-subnet'

export TENANT_NET1='tenant-net1'
export TENANT_NET2='tenant-net2'
export TENANT_SUBNET1='tenant-subnet1'
export TENANT_SUBNET2='tenant-subnet2'

export PUBLICROUTER='public-router0'
export MY_PUBLIC='my-public'        
export MY_PUBLIC_SUB='my-public-subnet'


source /etc/nova/openrc

#Set flag that variables are already exported
#export GLOBAL_FSC='done'
