#!/bin/sh
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

#Check connectivity with VM on mgmt port
MAX_CNT=60

cnt=$((MAX_CNT*2))
echo "Check for qdhcp... max ${cnt}s"

NAMESPACE=$(ip netns | grep -m 1 qdhcp)

cnt=$MAX_CNT

while [ -z $NAMESPACE ] && [ $cnt -ge 0 ]; do
    NAMESPACE=$(ip netns | grep -m 1 qdhcp)
    sleep 2
    ((cnt--))
done

if [ -z $NAMESPACE ]; then
    echo "No qdhcp... abort script"
    exit 1
else
    echo "Router found - ${NAMESPACE}"
fi

#get IP address
IP=$(nova show ${VM1_NAME} | grep ${MGMT_NET} |grep -oE "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b")

cnt=$((MAX_CNT*4))
echo "Check if host is reachable... max ${cnt}s"

ip netns exec $NAMESPACE ping -w 1 -q $IP 2>&1 > /dev/null
var=$?


while [ $var -ne 0 ] && [ $cnt -ge 0 ]; do
    ip netns exec $NAMESPACE ping -w 1 -q $IP 2>&1 > /dev/null
    var=$?
    ((cnt--))
done
 
time=$(((MAX_CNT*4)-cnt))

if (($var == 0)); then
    echo "Host $IP is reachable after ${time}s"
    awk '!/192.168.100.2/' /root/.ssh/known_hosts > /root/.ssh/tmp && mv /root/.ssh/tmp /root/.ssh/known_hosts
#    cat ~/.ssh/id_rsa.pub | ip netns exec $NAMESPACE  ssh root@$IP "mkdir -p ~/.ssh && cat >>  ~/.ssh/authorized_keys"

else
    echo "Host $IP is unreachable"
    echo "Script canceled"
    exit 1
fi

exit 0
