#!/usr/bin/python
# coding: utf-8
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

import httplib2
import threading
import socket
import time
import json
import sys
import re
import random
import getopt
import os.path
import logging
import websocket

def outputLog():
    if False == os.path.exists('./log'):
        os.makedirs('./log')
    logFilename = './log/meappservice.log'
    logging.basicConfig(
                    level   = logging.DEBUG,
                    format  = '%(message)s',
                    datefmt = '%m-%d %H:%M',
                    filename= logFilename,
                    filemode= 'w')

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(message)s')
    console.setFormatter(formatter)
    logging.getLogger().addHandler(console)

MEAPPSERVICE_LOG = logging.getLogger('MEAPPSERVICE_LOG')

# Select a module to run by specifying the corresponding command
COMMANDS = {'L1': 'oqn',
            'L2': 'msq',
            'L3.1': 'stq',
            'L3.2': 'zmladutfrq'}
dictOpts = {'quit': 'q',                                                 # common
            'nevSdk': 'n', 'logOut': 'o',                                # L1
            'multiPro': 'm', 'singlePro': 's',                           # L2
            'startProvidingServices': 's', 'stopProvidingServices': 't', # L3.1
            'liveindicator': 'z',                                        # L3.2
            'terminationindicator': 'm',
            'connectionestablishment': 'l',
            'serviceactivation': 'a',
            'servicedeactivation': 'd',
            'servicedataupdate': 'u',
            'trafficrulecreation': 't',
            'trafficruleupdate': 'f',
            'trafficruleremoval': 'r',}
gLevel = 'L1'

class Vector:
    first=""
    second=""
    def __init__(self,x,y):
        self.first=x
        self.second=y

# Meappservice class
class Meappservice:
    def __init__(self):
        self.__HOSTPORT = '8080'                    # host port
        self.__WEBSOCKETPORT = '8888'               # webSocket prot
        self.__HOSTADDR = 'mec.local'                 # host ip
        self.__CERTPATH = 'mec.crt'
        self.h = httplib2.Http(".cache", ca_certs=self.__CERTPATH)
        self.cookie = ''                            # cookie value

        self.arrServiceID = ''                      #
        self.baseJsonPath = 'json/'                 # file path prefix for json files
        self.logFlagForDebug = False                # debug log output switch
        self.thread = ""                            # update thread
        self.__stopped = True                       # thread switch
        self.webSocketThread = ""                   # webSocket thread
        self.__webSocketThreadStopped = True        # thread switch
        self.__trafficName = ""
        self.__updatetraffic = ""
        self.__serviceName = ""
        self.updateServiceName = ""
        self.updateCount = 5                        # number of updates
        self.updateInterval = 1000                  # interval between updates, in ms
        self.serviceActivationList = []             # service value
        self.provideServiceList = []                # service value
        self.trafficRuleList = []                   #
        self.createdTrafficRuleList = []            #
        self.baseUrl = 'https://' + self.__HOSTADDR + ':' + self.__HOSTPORT + '/appliance/v1'       # url prefix

# Do Mobile Edge Application Live Indicator(-z)
    def liveIndicator(self):
        procedure = 'Live Indicator Request'
        url = self.baseUrl + '/live_apps'
        method = "POST"
        contentType = "application/json"

        jsonPath = self.baseJsonPath + 'AppLiveIndicator.json'
        if not os.path.exists(jsonPath):
            print("[NG] The file \"{}\" cannot be found.".format(jsonPath))
            return

        # Read request data from json file
        requestBody = self.loadJsonFile(jsonPath)

        # send request
        resp, content = self.h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            # Save cookies
            self.cookie = resp['set-cookie']
            print('[OK] Mobile Edge Application Live Indicator.')
        else:
            print('[NG] Mobile Edge Application Live Indicator.')

# Do Mobile Edge Application Termination Indicator(-m)
    def terminationIndicator(self):
        procedure = 'Termination Indicator Request'
        url = self.baseUrl + '/live_apps'
        method = "DELETE"
        contentType = ""
        requestBody = ""

        # send request
        resp, content = self.h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'Cookie': self.cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            if self.webSocketThread:
                self.delWebSocket()
                self.webSocketThread = ""
                time.sleep(1)
            self.createdTrafficRuleList = []
            self.serviceActivationList = []
            self.cookie = ""                   # init cookie value
            print('[OK] Mobile Edge Application Termination Indicator.')
        else:
            print('[NG] Mobile Edge Application Termination Indicator.')

# Do Mobile Edge Application Connection Establishment(-l)
    def connectionEstablishment(self):
        if not self.__webSocketThreadStopped:
            print('[WARNING] ME App Connection is already established.')
            return
        self.__webSocketThreadStopped = False
        self.webSocketThread = threading.Thread(name = "WebsocketThread", target = self.createWebSocket)
        self.webSocketThread.setDaemon(True)
        self.webSocketThread.start()

# Delete thread
    def delWebSocket(self):
        self.__webSocketThreadStopped = True

    def formatChannelListenerResponse(self, str):
        str = list(str)
        temp = ""
        count = 0
        for s in str:
            if s == '{' :
                count += 1
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == '[' :
                count += 1
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == ',':
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == '}':
                count -= 1
                temp += '\n'
                temp = self.addTable(temp,count)
                temp += s
            elif s == ']':
                count -= 1
                temp += '\n'
                temp = self.addTable(temp,count)
                temp += s
            else:
                temp += s
        return temp
    def addTable(self,s,num):
        for i in range(0,num):
            s += '    '
        return s

# listening on channel
    def createWebSocket(self):
        if not self.cookie:
            print('[NG] ME App Connection Establishment Failed: cookie is null')
            self.__webSocketThreadStopped = True
            return

        if self.cookie.find('SESSID=') != -1:
            refId = self.cookie[self.cookie.find('SESSID=') + 7:]
        else:
            refId = self.cookie
        url = 'ws://' + self.__HOSTADDR + ':' + self.__WEBSOCKETPORT + '/notifications/' + refId
        try:
            websocket.enableTrace(True)
            ws = websocket.create_connection(url)
        except:
            print ('[NG] ME App Connection Establishment Failed: WebSocket header is invalid. Please try again.')
            self.__stopped = True
            return
        print ('[OK] ME App Connection Establishment.')
        while not self.__webSocketThreadStopped:
            result = ws.recv()
            if result:
                result = self.formatChannelListenerResponse(result)
                MEAPP_LOG.info(result)

#Do Mobile Edge Service Activation(-a)
    def serviceActivation(self, requestBody = ""):
        procedure = 'Service Activation Request'
        url = self.baseUrl + '/service'
        method = "POST"
        contentType = "application/json"
        if not requestBody:
            self.provideServiceListCreation()
            if not self.provideServiceList:
                print("No provide service")
                return
            if self.__serviceName:
                for provideService_ in self.provideServiceList:
                    if self.__serviceName == provideService_.first:
                        requestBody = provideService_.second
                        break;
                if not requestBody:
                    print("Service name specified on the command line command line is not found.")
                    return
            else:
                userSelect = self.getServicesFromUser(self.provideServiceList)
                if not userSelect.second:
                    print("No serial number was entered.")
                    return
                requestBody = userSelect.second
        serviceName = requestBody['serviceName']
        # send request
        resp, content = self.h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'Cookie': self.cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie': self.cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            # Save cookies
            respDic = json.loads(content)
            serviceId = respDic['serviceId']
            found = False
            for serviceActivation_ in self.serviceActivationList:
                if serviceName == serviceActivation_.first:
                    found = True
                    break
            if not found:
                serviceActivation = Vector(serviceName, serviceId)
                self.serviceActivationList.append(serviceActivation)
            print('[OK] Do Mobile Edge Service Activation.')
        else:
            print('[NG] Do Mobile Edge Service Activation.')

    def provideServiceListCreation(self):
        jsonPath = self.baseJsonPath + 'serviceActivation/'
        if not os.path.exists(jsonPath):
            print("The directory \"{}\" cannot be found.".format(jsonPath))
            return

        for parent,dirnames,filenames in os.walk(jsonPath):
            if not filenames:
                print "There are no service specifications found on the specified path."
                return
            for filename in filenames:
                fileCon = self.loadJsonFile(os.path.join(parent,filename))
                serviceName = fileCon['serviceName']
                found = False
                for proviceService_ in self.provideServiceList:
                    if serviceName == proviceService_.first:
                        found = True
                        break
                if not found:
                    provideService = Vector(serviceName, fileCon)
                    self.provideServiceList.append(provideService)

# Mobile Edge Service Deactivation(-d)
    def serviceDeactivation(self, serviceId = ""):
        procedure = 'Service Deactivation Request'

        method = "DELETE"
        contentType = ""
        requestBody = ""
        if not self.serviceActivationList:
            print("There are no activated service.")
            return
        if self.__serviceName:
            for service in self.serviceActivationList:
                if self.__serviceName == service.first:
                    serviceId = service.second
                    str = '1'
                    self.arrServiceID = str.split()
                    break
            if not serviceId:
                print("Service Name specified on the command line is not found.")
                return
        else:
            if not serviceId:
                serviceId = self.getServicesFromUser(self.serviceActivationList).second
                if not serviceId:
                    print("No serial number was entered.")
                    return
        url = self.baseUrl + '/service/' + serviceId
        # send request
        resp, content = self.h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'Cookie': self.cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            self.serviceActivationList.pop(int(self.arrServiceID[0])-1)
            print('[OK] Mobile Edge Service Deactivation.')
        else:
            print('[NG] Mobile Edge Service Deactivation.')

# Do Mobile Edge Service Data Update and Publication(-u)
    def serviceDataUpdate(self, interactiveFlag = True):
        _self = self
        class updateThread(threading.Thread):
            def __init__(self, count, interval):
                threading.Thread.__init__(self)
                self.interval = int(interval)/1000
                self.totalNum = int(count)
                self.thread_stop = False
                self.num = 0

            def run(self):
                procedure = 'Data Update Request'
                url = _self.baseUrl + '/notifications'
                method = "POST"
                contentType = "application/json"

                jsonPath = _self.baseJsonPath + 'update.json'
                if not os.path.exists(jsonPath):
                    print("The file \"{}\" cannot be found.".format(jsonPath))
                    return

                # Read request data from json file

                serviceData = _self.loadJsonFile(jsonPath)
                if _self.updateServiceName:
                    serviceData['serviceData']['serviceName'] = _self.updateServiceName

                serviceName = serviceData['serviceData']['serviceName']
                serviceId = ""
                requestBody = {"serviceId":"serviceId","serviceData":{}}
                for serviceActivation_ in _self.serviceActivationList:
                    if serviceName == serviceActivation_.first:
                        serviceId = serviceActivation_.second
                if serviceId:
                    requestBody['serviceId'] = serviceId
                    requestBody['serviceData'] = serviceData['serviceData']
                else:
                    print("Service not found")
                    return

                while not self.thread_stop and self.num < self.totalNum:
                    if requestBody :
                        _self.produceUpdateData(requestBody)

                    # send request
                    resp, content = _self.h.request(url,
                                                    method,
                                                    json.dumps(requestBody),
                                                    headers={'content-type': contentType, 'Cookie': _self.cookie})

                    if _self.logFlagForDebug:
                        # output log
                        _self.reqLogout({'Tip':procedure,
                                        'URL':url,
                                        'Method':method,
                                        'ContentType':contentType,
                                        'Cookie':_self.cookie,
                                        'Body':requestBody})
                        _self.respLogout({'Tip':procedure.replace('Request','Response'),
                                        'Resp':resp,
                                        'Content':content})
                    self.num += 1
                    # check result
                    if _self.checkResult(resp, content):
                        print('[OK] Send Update Data to ME Platform ({}/{}).'.format(self.num, self.totalNum))
                    else:
                        print('[NG] Send Update Data to ME Platform ({}/{}).'.format(self.num, self.totalNum))
                    if self.num == self.totalNum:
                        _self.thread = ""
                    time.sleep(self.interval)

            def stop(self):
                self.thread_stop = True

        if interactiveFlag:
            if _self.updateServiceName:
                self.thread = updateThread(10, 1000)
                self.thread.start()
            else:
                if self.setAttrForUpdate():
                    self.thread = updateThread(self.updateCount, self.updateInterval)
                    self.thread.start()
        else:
            self.thread = updateThread(10, 1000)
            self.thread.start()

# set the number of data updates and update interval using user input
    def setAttrForUpdate(self):
        tmpCount = raw_input('\n>>>Please enter the number of data updates, \n    or press enter to use the default value (5):')
        count = self.checkAttrForUpdate(tmpCount, 5)

        tmpInterval = raw_input('\n>>>Please enter the interval length between data updates in ms, \n    or press enter to use the default value (1000):')
        interval = self.checkAttrForUpdate(tmpInterval, 1000)

        while True:
            print("\nYou have entered the following inputs: \n    number={}, interval={}ms. Continue? (y/n)".format(count, interval))
            input = raw_input('>>>')
            if not re.match('^[yn]$', input):
                continue
            else:
                if "y" == input:
                    self.updateCount = count
                    self.updateInterval = interval
                    ret = True
                elif "n" == input:
                    ret = False
                else:
                    pass
                break

        return ret

    def checkAttrForUpdate(self, value, defaultValue):
        while True:
            if not value:
                value = defaultValue
                break
            else:
                if not re.match('^[0-9]+$', value):
                    value = raw_input('\n>>>The input is not a valid number. Please enter again:')
                    continue
                break
        return value

# randomly generate update data
    def produceUpdateData(self, baseData):
        keys = {"keyFields", "data"}
        for key in keys:
            if key in baseData["serviceData"]:
                for field in baseData["serviceData"][key]:
                    if isinstance(baseData["serviceData"][key][field], int):
                        value = random.randint(1, 10000)
                        baseData["serviceData"][key][field] = value

# Do Mobile Edge Traffic Rules Control(Create: -t, Remove: -r, Update: -f)
    def trafficRuleCreation(self):
        procedure = 'Traffic Rule Creation Request'
        url = self.baseUrl + '/traffic'
        method = "POST"
        contentType = "application/json"
        jsonPath = self.baseJsonPath + 'trafficRule/'
        requestBody = ""
        if not os.path.exists(jsonPath):
            print("[NG] The directory \"{}\" cannot be found.".format(jsonPath))
            return

        for parent,dirnames,filenames in os.walk(jsonPath):
            if not filenames:
                print "There are no traffic rule files found on the specified path."
                return
            del self.trafficRuleList[:]
            if self.__trafficName:
                __trafficName = self.__trafficName + ".json"
                for filename in filenames:
                    if __trafficName == filename:
                        requestBody = self.loadJsonFile(os.path.join(parent,filename))
                        createdFileName = filename
                        break;
                if not requestBody:
                    print("The traffic rule file name specified on the command line is not found.")
                    return
            else:
                for filename in filenames:
                    fileCon = self.loadJsonFile(os.path.join(parent,filename))
                    found = False
                    for trafficRule_ in self.trafficRuleList:
                        if filename == trafficRule_.first:
                            found = True
                            break
                    if not found:
                        trafficRule = Vector(filename, fileCon)
                        self.trafficRuleList.append(trafficRule)
                userSelect = self.getServicesFromUser(self.trafficRuleList)
                if not userSelect.second:
                    print("No serial number was entered.")
                    return
                createdFileName = userSelect.first
                requestBody = userSelect.second

        # send request
        resp, content = self.h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'Cookie': self.cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            respDic = json.loads(content)
            trafficRuleId = respDic['trafficRuleId']
            createdTrafficRule = Vector(createdFileName, trafficRuleId)
            self.createdTrafficRuleList.append(createdTrafficRule)
            print('[OK] Mobile Edge Traffic Rule Creation.')
        else:
            print('[NG] Mobile Edge Traffic Rule Creation.')

    def trafficRuleUpdate(self):
        procedure = 'Traffic Rule Update Request'
        method = "PUT"
        contentType = "application/json"

        trafficRuleId = ""
        requestBody = ""
        if not self.createdTrafficRuleList:
            print("There are no created traffic rule(s).")
            return
        if self.__updatetraffic and self.__trafficName:
            jsonPath = self.baseJsonPath + 'trafficRule/'

            __trafficName = self.__trafficName + ".json"
            for createdTrafficRule_ in self.createdTrafficRuleList:
                if __trafficName == createdTrafficRule_.first:
                    trafficRuleId = createdTrafficRule_.second
                    str = '1'
                    self.arrServiceID = str.split()
                    break;
            if not trafficRuleId:
                print("The traffic rule file name specified on the command line is not found.")
                return
            if not os.path.exists(jsonPath):
                print("[NG] The directory \"{}\" cannot be found.".format(jsonPath))
                return
            for parent,dirnames,filenames in os.walk(jsonPath):
                if not filenames:
                    print "There are no traffic files found on the specified path."
                    return
                __trafficName = self.__updatetraffic + ".json"
                for filename_ in filenames:
                    if __trafficName == filename_:
                        requestBody = self.loadJsonFile(os.path.join(parent,filename_))
                        fileName = filename_
                        break;
                if not requestBody:
                    print("The traffic rule file name specified on the command line is not found.")
                    return
        else:
            if not self.trafficRuleList:
                print("There are no traffic rule(s) specified.")
                return
            result, fileName = self.updateTrafficeRule(self.trafficRuleList, self.createdTrafficRuleList)
            if not result:
                print("No serial number was entered.")
                return
            trafficRuleId = result.first
            requestBody = result.second
        url = self.baseUrl + '/traffic/' + trafficRuleId
        # send request
        resp, content = self.h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'Cookie': self.cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            self.createdTrafficRuleList.pop(int(self.arrServiceID[0])-1)
            createdTrafficRule = Vector(fileName, trafficRuleId)
            self.createdTrafficRuleList.append(createdTrafficRule)
            print('[OK] Mobile Edge Traffic Rule Update.')
        else:
            print('[NG] Mobile Edge Traffic Rule Update.')

    def updateTrafficeRule(self, trafficRuleList, createdTrafficRuleList):
        userSelect = []
        fileName = ""
        if not createdTrafficRuleList or None == createdTrafficRuleList:
            return userSelect, fileName
        else:
            # print list of services
            print("Created TrafficRule List")
            self.printSelectedList(createdTrafficRuleList)

            print("TrafficRule List")
            self.printSelectedList(trafficRuleList)
        # Waiting for user input
        max = len(createdTrafficRuleList)
        while 1:
            str = raw_input('>>>>>>Please enter a serial number within the range [1-{}] that you want removed:'.format(max))
            self.arrServiceID = str.split()
            if not str:
                self.arrServiceID = 0
                return userSelect, fileName
            elif len(self.arrServiceID) > 1:
                print('Input contains multiple characters.')
            elif not re.search(r'^[\d\s]*$', str):
                print('Input contains non-numeric characters.')
            elif int(self.arrServiceID[0]) > max or int(self.arrServiceID[0]) < 1:
                print('No.{} is out of range.'.format(int(self.arrServiceID[0])))
            else:
                break

        max = len(trafficRuleList)
        newID = 0
        while 1:
            str = raw_input('>>>>>>Please enter a serial number within the range [1-{}] that you want added:'.format(max))
            newID = str.split()
            if not str:
                newID = 0
                return userSelect, fileName
            elif len(newID) > 1:
                print('Input contains multiple characters.')
            elif not re.search(r'^[\d\s]*$', str):
                print('Input contains non-numeric characters.')
            elif int(newID[0]) > max or int(newID[0]) < 1:
                print('No.{} is out of range.'.format(int(newID[0])))
            else:
                break
        # create list of services to subscribe to

        trafficeRuleId_ = createdTrafficRuleList[int(self.arrServiceID[0])-1].second
        trafficeRuleInfo = trafficRuleList[int(newID[0])-1].second
        fileName = trafficRuleList[int(newID[0])-1].first
        userSelect = Vector(trafficeRuleId_, trafficeRuleInfo)
        return userSelect, fileName

    def trafficRuleRemoval(self):
        procedure = 'Traffic Rule Removal Request'
        method = "DELETE"
        contentType = "application/json"

        if not self.createdTrafficRuleList:
            print("There are no existing traffic rules.")
            return
        trafficRuleId = ""
        if self.__trafficName:
            __trafficName = self.__trafficName + ".json"
            for createdTrafficRule_ in self.createdTrafficRuleList:
                if __trafficName == createdTrafficRule_.first:
                    trafficRuleId = createdTrafficRule_.second
                    str = '1'
                    self.arrServiceID = str.split()
                    break;
            if not trafficRuleId:
                print("The traffic rule file name specified on the command line is not found.")
                return
        else:
            userSelect = self.getServicesFromUser(self.createdTrafficRuleList)
            if not userSelect.second:
                print("No serial number was entered.")
                return
            trafficRuleId = userSelect.second
        url = self.baseUrl + '/traffic/' + trafficRuleId

        requestBody = ""

        # send request
        resp, content = self.h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'Cookie': self.cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            self.createdTrafficRuleList.pop(int(self.arrServiceID[0])-1)
            print('[OK] Mobile Edge Traffic Rule Removal.')
        else:
            print('[NG] Mobile Edge Traffic Rule Removal.')

# result check
    def checkResult(self, resp, content):
        if not 'status' in resp:
            print "http server is not running!"
            return False
        try:
            respDic = json.loads(content)
            if respDic['result'] == "OK" or (
                respDic['result'] == "ServiceExist" or
                respDic['result'] == "TrafficRuleExist" or
                respDic['result'] == "AppidAuthenticated"):
                return True
            else:
                print('result:{}'.format(respDic['result']))
                return False
        except ValueError:
            print "http server is not running!"
            return False
# Returns the selected content according to the user's choice
    def getServicesFromUser(self, selectedList):
        userSelect = Vector("","")
        if not selectedList or None == selectedList:
            return userSelect
        else:
            self.printSelectedList(selectedList)
        # Waiting for user input
        max = len(selectedList)
        while 1:
            str = raw_input('>>>>>>Please enter a serial number within the range [1-{}] :'.format(max))
            self.arrServiceID = str.split()
            if not str:
                return userSelect
            elif len(self.arrServiceID) > 1:
                print('Input contains multiple characters.')
            elif not re.search(r'^[\d\s]*$', str):
                print('Input contains non-numeric characters.')
            elif int(self.arrServiceID[0]) > max or int(self.arrServiceID[0]) < 1:
                print('No.{} is out of range.'.format(int(self.arrServiceID[0])))
            else:
                break

        userSelect = selectedList[int(self.arrServiceID[0])-1]
        return userSelect
# print list of selected items
    def printSelectedList(self, selectedList):
        count = 0
        print('No.    itemName')
        for sub in selectedList:
            count += 1
            print(' {}     {}'.format(count, sub.first, indent=2))
# read data from json file
    def loadJsonFile(self, path):
        fp = open(path, 'r')
        jsonData = json.load(fp)
        fp.close()

        return jsonData

# output request log
    def reqLogout(self, data):
        if data['Body']:
            data['Body'] = json.dumps(data['Body'], sort_keys=True, indent=4)
        MEAPPSERVICE_LOG.info('')
        MEAPPSERVICE_LOG.info("{}".format(data['Tip']))
        MEAPPSERVICE_LOG.info('')
        MEAPPSERVICE_LOG.info("Request Header")
        MEAPPSERVICE_LOG.info("    URL        : {}".format(data['URL']))
        MEAPPSERVICE_LOG.info("    Method     : {}".format(data['Method']))
        MEAPPSERVICE_LOG.info("    ContentType: {}".format(data['ContentType']))
        MEAPPSERVICE_LOG.info("    cookie     : {}".format(data['Cookie']))
        MEAPPSERVICE_LOG.info('')
        MEAPPSERVICE_LOG.info("Request Body")
        MEAPPSERVICE_LOG.info('{}'.format(data['Body']))
        MEAPPSERVICE_LOG.info('')

# output response log
    def respLogout(self, data):
        data['Resp'] = json.dumps(data['Resp'], sort_keys=True, indent=4)
        if "result" in data['Content']:
            data['Content'] = json.dumps(json.loads(data['Content']), sort_keys=True, indent=4)
        MEAPPSERVICE_LOG.info('')
        MEAPPSERVICE_LOG.info("{}".format(data['Tip']))
        MEAPPSERVICE_LOG.info('')
        MEAPPSERVICE_LOG.info("Response Header")
        MEAPPSERVICE_LOG.info('{}'.format(data['Resp']))
        MEAPPSERVICE_LOG.info('')
        MEAPPSERVICE_LOG.info("Response Body")
        MEAPPSERVICE_LOG.info('{}'.format(data['Content']))
        MEAPPSERVICE_LOG.info('')

    def setJsonPath(self, path):
        self.baseJsonPath = path
    def setCookie(self, cookie):
        self.cookie=cookie
    def setTrafficName(self, name):
        self.__trafficName = name
    def setUpdateTrafficName(self, name):
        self.__updatetraffic = name
    def setServiceName(self, name):
        self.__serviceName = name
    def setUpdateService(self, name):
        self.updateServiceName = name
# python parameter specification
def usage(name):
    global gLevel
    print ""
    if 'L1' == gLevel:
        print "[ {} ] Demonstrate NEV SDK API ".format("n")
        print "[ {} ] Enable Log ".format("o")
        print "[ {} ] Exit".format("q")
    elif 'L2' == gLevel:
        print "[ {} ] Demonstrate Multi-Procedure Combinations ".format("m")
        print "[ {} ] Demonstrate Single Procedures ".format("s")
        print "[ {} ] Back".format("q")
    elif 'L3.1' == gLevel:
        print "[ {} ] Start Providing Services for ME Platform".format("s")
        print "[ {} ] Stop Providing Services for ME Platform".format("t")
        print "[ {} ] Back".format("q")
    elif 'L3.2' == gLevel:
        print "[ {} ] Do Application Live Indicator".format("z")
        print "[ {} ] Do Application Termination Indicator".format("m")
        print "[ {} ] Do Application Connection Establishment".format("l")
        print "[ {} ] Do Mobile Edge Service Activation".format("a")
        print "[ {} ] Do Mobile Edge Service Deactivation".format("d")
        print "[ {} ] Do Service Data Update and Publication".format("u")
        print "[ {} ] Do Traffic Rules Creation".format("t")
        print "[ {} ] Do Traffic Rules Update".format("f")
        print "[ {} ] Do Traffic Rules Removal".format("r")
        print "[ {} ] Back".format("q")
    else:
        pass

def levelOne(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        print "exit program"
        sys.exit(0)
    if dictOpts['nevSdk'] in opts:
        gLevel = 'L2'
        usage(sys.argv[0] + ': ' + gLevel)

def levelTwo(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        gLevel = 'L1'
        usage(sys.argv[0] + ': ' + gLevel)
        return
    if dictOpts['multiPro'] in opts:
        gLevel = 'L3.1'
        usage(sys.argv[0] + ': ' + gLevel)
        return
    if dictOpts['singlePro'] in opts:
        gLevel = 'L3.2'
        usage(sys.argv[0] + ': ' + gLevel)
        return

def levelThrOne(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        gLevel = 'L2'
        usage(sys.argv[0] + ': ' + gLevel)
        return
    if dictOpts['startProvidingServices'] in opts:
        if meappService.thread:
            meappService.thread.stop()
            meappService.thread = ""
            return
        else:
            meappService.liveIndicator()
            meappService.connectionEstablishment()
            meappService.provideServiceListCreation()
            if meappService.provideServiceList:
                for provideService in meappService.provideServiceList:
                    meappService.serviceActivation(provideService.second)
                    break;
            meappService.serviceDataUpdate(False)
            return
    if dictOpts['stopProvidingServices'] in opts:
        if meappService.serviceActivationList:
            for service in meappService.serviceActivationList:
                str = '1'
                meappService.arrServiceID = str.split()
                meappService.serviceDeactivation(service.second)
                break
        meappService.terminationIndicator()
        return

def levelThrTwo(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        gLevel = 'L2'
        usage(sys.argv[0] + ': ' + gLevel)
        return

    for subOpts in opts:
        if dictOpts['liveindicator'] == subOpts:
            meappService.liveIndicator()
        elif dictOpts['terminationindicator'] == subOpts:
            meappService.terminationIndicator()
        elif dictOpts['connectionestablishment'] == subOpts:
            meappService.connectionEstablishment()
        elif dictOpts['serviceactivation'] == subOpts:
            meappService.serviceActivation()
        elif dictOpts['servicedeactivation'] == subOpts:
            meappService.serviceDeactivation()
        elif dictOpts['servicedataupdate'] == subOpts:
            meappService.serviceDataUpdate()
        elif dictOpts['trafficrulecreation'] == subOpts:
            meappService.trafficRuleCreation()
        elif dictOpts['trafficruleupdate'] == subOpts:
            meappService.trafficRuleUpdate()
        elif dictOpts['trafficruleremoval'] == subOpts:
            meappService.trafficRuleRemoval()
        else:
            pass

levelFunc = {'L1': levelOne, 'L2': levelTwo, 'L3.1': levelThrOne, 'L3.2': levelThrTwo}

# Module execution control
def modulePerforms(opts):
    global gLevel
    if not opts:
        usage(sys.argv[0] + ': ' + gLevel)
        return
    if dictOpts['logOut'] in opts:
        # turn on debug log output switch
        meappService.logFlagForDebug = True
        opts.remove(dictOpts['logOut'])
    levelFunc.get(gLevel)(opts)

# convert string into opts
def stringToOpts(data):
    global gLevel
    opts = []
    dataTemp = re.findall('[A-Za-z]+', data)
    dataTemp = list('.'.join(dataTemp))
    for sep in dataTemp:
        if sep in COMMANDS[gLevel]:
            opts.append(sep)
    return opts


if __name__ == '__main__':
    outputLog()
    meappService = Meappservice()
    actioncontinue = ""
    if len(sys.argv) > 1:
        try:
            opts, args = getopt.getopt(sys.argv[1:], "t:p:n:c:f:a:u:e:", ["actioncontinue=","path=","noninteractive=","cookie=","traffic=","service=","update=","updatetraffic="])
        except getopt.GetoptError:
            print sys.argv[0], " [-t <actioncontinue>] [-p <json path>] [-n <commands>] [-c <cookie>] [-f <traffic>] [-a <service>] [-u <update>] [-e <updatetraffic>]"
            sys.exit(1)

        commands = ""
        JsonPath = ""
        cookie = ""

        for opt, arg in opts:
            if opt in ("-p", "--path"):
                JsonPath=arg
                if not JsonPath or not os.path.exists(JsonPath):
                    print("The directory \"{}\" cannot be found.".format(JsonPath))
                    print "exit program"
                    sys.exit(0)
                meappService.setJsonPath(JsonPath)
            if opt in ("-f","--traffic"):
                trafficName=arg
                meappService.setTrafficName(trafficName)
            if opt in ("-e","--updatetraffic"):
                updatetraffic=arg
                meappService.setUpdateTrafficName(updatetraffic)
            if opt in ("-a","--service"):
                serviceName=arg
                meappService.setServiceName(serviceName)
            if opt in ("-u","--update"):
                updateService=arg
                meappService.setUpdateService(updateService)
            if opt in ("-t", "--actioncontinue"):
                actioncontinue = arg
            if opt in ("-n", "--noninteractive"):
                commands=arg
            elif opt in ("-c", "--cookie"):
                cookie=arg
                meappService.setCookie(arg)

        if commands:
            for arg in commands.split():
                modulePerforms(stringToOpts(arg))
            if actioncontinue != "True":
                sys.exit(0)
        elif cookie:
            print sys.argv[0], " [-t <actioncontinue>] [-p <json path>] [-n <commands>] [-c <cookie>] [-f <traffic>] [-a <service>] [-u <update>] [-e <updatetraffic>]"
            sys.exit(1)
        elif not JsonPath:
            print sys.argv[0], " [-t <actioncontinue>] [-p <json path>] [-n <commands>] [-c <cookie>] [-f <traffic>] [-a <service>] [-u <update>] [-e <updatetraffic>]"
            sys.exit(1)
    if actioncontinue != "True":
        usage(sys.argv[0] + ': ' + gLevel)
    while True:
        command = raw_input('\n>>>Please enter a command:')
        opts = stringToOpts(command)
        modulePerforms(opts)
        time.sleep(0.5)
