#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

SAMPLE_PATH="${DST_SAMPLES_DIR}/rtt"
THING_NAME=${GG_HELLO_PUB_NAME}
TOPIC="mec/rtt"
MODE="--subscribe --publish"

. functions.sh

export KEY=$(get_key_prefix "${THING_NAME}")

# remove old cert and keys
exec_on_remote "${DEV1_IP}" "${DEV1_USER}" "rm -rf ${SAMPLE_PATH}/*cert.pem ${SAMPLE_PATH}/*.key"

# copy new cert and keys
copy_to_remote "${THING_NAME}/*" "${DEV1_IP}" "${DEV1_USER}" "${SAMPLE_PATH}"

OUTPUT=$(exec_on_remote "${DEV1_IP}" "${DEV1_USER}" "cd ${SAMPLE_PATH}; PYTHONPATH=.. \
stdbuf -oL python ./measure_delay_cloud.py -vDEBUG \
    --root-ca=root-ca.pem \
    --certificate=${KEY}.cert.pem \
    --private-key=${KEY}.private.key \
    --client-id=${THING_NAME} \
    --topic=\"${TOPIC}\" \
    ${MODE} \
    ${ENDPOINT} 2>&1 & procpid=\$!; sleep 10; kill \$procpid")

echo ${OUTPUT}

if [ -z "$(echo ${OUTPUT} | grep 'RTT for cloud')" ]; then
    TEST_STATUS=1
    exit 1
fi
