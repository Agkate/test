/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file nes_dns_tools.c
 * @brief implementation of nes_dns_tools
 */

#include <assert.h>
#include <stdio.h>
#include <stdint.h>

#include "nes_dns_tools.h"

int
nes_dns_labels_to_domain(const char *labels, char *domain, uint8_t domain_len) {
    assert(labels);
    assert(domain);

    uint8_t label_len, labels_len, offset = 1; // offset is 1 because first byte defines first label length

    labels_len = strlen(labels);
    if (labels_len > domain_len) {
        return NES_FAIL;
    }
    memset(domain, 0, domain_len);
    label_len = labels[0];

    while (1) {
        if (offset > labels_len || label_len > (domain_len - strlen(domain))) {
            return NES_FAIL;
        }
        strncat(domain, labels + offset, label_len);
        offset += label_len + 1; //move past next label length byte
        label_len = labels[offset - 1];
        if (label_len > 0 && 0 == (label_len & 0xC0)) {
            strcat(domain, ".");
        } else {
            break;
        }
    }
    return NES_SUCCESS;

}