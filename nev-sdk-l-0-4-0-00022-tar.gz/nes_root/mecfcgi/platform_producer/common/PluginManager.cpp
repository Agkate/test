/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    PluginManager.cpp
 * @brief   Implementation of PluginManager.
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <iostream>
#include "PluginManager.h"
#include "PluginInstance.h"
#include "DynamicLib.h"
#include "IProducer.h"
#include "PluginWatcher.h"
#include "Log.h"

PluginWatcher *PluginManager::pluginWatcher = NULL;

PluginManager::PluginManager(void):
producer()
{
    vecPlugins.clear();
    vecPluginLibs.clear();
    memset(&watherID, 0, sizeof(pthread_t));
    
}

PluginManager::~PluginManager(void)
{

}

PluginManager &PluginManager::getInstance()
{
    static PluginManager instance;
    return instance;
}

void PluginManager::getPluginFiles()
{
    char strPwd[80];
    getcwd(strPwd, 80);

    char *pwd= (char*)sPluginPath.c_str();
    DIR *dp;
    struct dirent *entry;
    struct stat statbuf;

    if((dp = opendir(pwd)) == NULL) {
        MECFCGI_LOG(ERR, "Cannot open directory: %s.\n", pwd);
        return;
    }
    chdir(pwd);
    while((entry = readdir(dp)) != NULL) {
        lstat(entry->d_name, &statbuf);
        if(S_ISDIR(statbuf.st_mode)) {
            MECFCGI_LOG(ERR, "Get folder:%s ignore.\n", entry->d_name);
        } else {
            vecPluginFiles.push_back(entry->d_name);
        }
    }
    chdir(strPwd);
    closedir(dp);
}

bool PluginManager::init(IProducer *pd, string &pluginPath)
{
    bool ret = true;
    int err = 0;
    if(pd == NULL) {
        ret = false;
        MECFCGI_LOG(ERR, "pd is NULL");
        return ret;
    }
    producer = pd;
    if(pluginPath.size() > 0) {
        sPluginPath = pluginPath;
        getPluginFiles();
        pluginShadowPath = ".cache";
        DIR *dp=opendir(pluginShadowPath.c_str());
        if(dp != NULL) {
            rmdir(pluginShadowPath.c_str());
        }
        mkdir(".cache", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);

        pluginFileItor = vecPluginFiles.begin();
        while(pluginFileItor!=vecPluginFiles.end()) {
            load(*pluginFileItor, err);
            pluginFileItor++;
        }
    } else {
        ret = false;
        MECFCGI_LOG(ERR, "invalid parameter pluginPath");
    }
    return ret;
}


void PluginManager::check()
{
    PluginInstance* pPlugin = NULL;
    string strServiceInfo;
    pluginInsItor = vecPlugins.begin();
    while(pluginInsItor != vecPlugins.end()) {
        pPlugin = *pluginInsItor;
        if(pPlugin != NULL) {
            strServiceInfo = pPlugin->getServiceActivationInfo();
            bool flag = producer->activateMobileEdgeService(strServiceInfo);
            if(flag == false) {
                string name = pPlugin->getFileName();
                unLoad(name);
                MECFCGI_LOG(ERR, "Plugin:%s activates failed.\n", name.c_str());
            } else {
                pPlugin->start();
            }
        }
        pluginInsItor++;
    }
    pluginWatcher = new PluginWatcher();
    pluginWatcher->init(sPluginPath, this);
    pthread_create(&watherID, NULL, watcherThreadHandler, this);
}

void PluginManager::stopPluginWatcher()
{
    pluginWatcher->stop();
}

void* PluginManager::watcherThreadHandler(void *param)
{
    PluginManager *pm = (PluginManager *)param;
    if(pm == NULL) {
        MECFCGI_LOG(ERR, "create watcher thread param err");
        return NULL;
    }
    if(pluginWatcher != NULL) {
        pluginWatcher->watchProc();
    }
    return NULL;
}

PluginInstance* PluginManager::load(const string &strName,int &errCode)
{
    map<string, DynamicLib *>::iterator iter = vecPluginLibs.find(strName);
    if (iter != vecPluginLibs.end()) {
        unLoad(strName);
    }

    //copy plug-in file from path to shadow path
    string strCmd = "cp " + sPluginPath + "/" + strName + " " + pluginShadowPath;
    system(strCmd.c_str());

    DynamicLib* pLib = new DynamicLib;
    if (pLib != NULL) {
        // load plug-in from shadow dir
        pLib->loadLib(pluginShadowPath.c_str(), strName.c_str());
        vecPluginLibs.insert(make_pair(strName,pLib));
        START_PLUGIN_FUN pFun = (START_PLUGIN_FUN)pLib->getSymbolAddress("startPlugin");
        if (pFun != NULL) {
            PluginInstance* pPlugin = pFun(this);
            errCode = 0;
            return pPlugin;
        }
        errCode = 1;
        return NULL;
    }
    errCode = 1;
    return NULL;
}

bool PluginManager::loadAndCheck(const string &strName)
{
    int err;

    PluginInstance* pPlug = load(strName, err);
    if(pPlug == NULL) {
        return false;
    }
    string strServiceInfo = pPlug->getServiceActivationInfo();
    bool flag = producer->activateMobileEdgeService(strServiceInfo);
    if(flag == false) {
        string name = pPlug->getFileName();
        unLoad(name);
        MECFCGI_LOG(ERR, "Plugin:%s activates failed.\n", name.c_str());
        return false;
    } else {
        pPlug->start();
        return true;
    }
}

bool PluginManager::loadPlugin(PluginInstance *pPlugin)
{
    vecPlugins.push_back(pPlugin);
    return true;
}

bool PluginManager::unLoad(const string &strName)
{
    map<string,DynamicLib *>::iterator iter = vecPluginLibs.begin();
    for (; iter != vecPluginLibs.end(); ++iter ) {
        DynamicLib *pLib = iter->second;
        if (NULL == pLib) {
            continue;
        }
        if (0 == strcmp(pLib->getName(),strName.c_str())) {
            STOP_PLUGIN_FUN pFun = (STOP_PLUGIN_FUN)pLib->getSymbolAddress("stopPlugin");
            if (pFun != NULL) {
                pFun();
            }
            pLib->freeLib();
            delete pLib;
            vecPluginLibs.erase(iter);

            //remove plug-in file from path
            string strCmd = "rm " + pluginShadowPath + "/" + strName;
            system(strCmd.c_str());
            return true;
        }
    }
    return false;
}

bool PluginManager::unLoadPlugin(PluginInstance *pPlugin)
{
    vector<PluginInstance *>::iterator iter = vecPlugins.begin();
    for (; iter != vecPlugins.end(); ++iter ) {
        if (pPlugin == *iter) {
            vecPlugins.erase(iter);
            return true;
        }
    }
    return false;
}

void PluginManager::notifyData(string &data)
{
    if(producer != NULL) {
        producer->doNotifyData(data);
    }
}

vector<PluginInstance *> PluginManager::getAllPlugins()
{
    return vecPlugins;
}
