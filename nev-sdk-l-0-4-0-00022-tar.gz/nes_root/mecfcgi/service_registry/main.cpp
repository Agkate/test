/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file main.cpp
 * @brief Implementation of Main
*/

#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include "Log.h"
#include "ConfigManager.h"
#include "FcgiBackend.h"
#include "DbManager.h"
#include "RawRequest.h"
#include "ConfigurationManager.h"
#include "PolicyManager.h"

using namespace std;

int init(int argc, char *argv[])
{
    // Init mecfcgi log
    mecfcgiLogInit();

    // Load config file
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::openConfigFile(argv[1])){
        MECFCGI_LOG(ERR, "Could not open config file %s. \n", argv[1]);
        return -1;
    }

    // Init FastCGI backend
    string hostIp;
    string hostPort;
    string fastcgiPass;
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("SERVICE_REGISTRY", "host_ip", hostIp)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "NGINX", "host_ip");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("SERVICE_REGISTRY", "host_port", hostPort)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "NGINX", "host_port");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("SERVICE_REGISTRY", "fastcgi_pass", fastcgiPass)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "NGINX", "serviceregistry_pass");
        ConfigManager::closeConfigFile();
        return -1;
    }
    FcgiBackend::setNginxInfo(hostIp, uint16_t(atoi((char *)hostPort.c_str())), fastcgiPass);

    // Init redis
    string redisIp = "";
    string redisPort = "";
    string password = "";
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("REDIS", "host_ip", redisIp)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "REDIS", "host_ip");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("REDIS", "host_port", redisPort)){
        MECFCGI_LOG(ERR, "Section [%s] enter %s missing in config file.\n", "REDIS", "host_port");
        ConfigManager::closeConfigFile();
        return -1;
    }
    if (ConfigManager::CFGFILE_SUCCESS != ConfigManager::getConfigData("REDIS", "password", password) ||
        0 == password.compare("")){
        MECFCGI_LOG(ERR, "Redis password not found in config file. \n");
        ConfigManager::closeConfigFile();
        return -1;
    }
    Redis::setRedisInfo(redisIp, uint16_t(atoi((char *)redisPort.c_str())), password);

    ConfigManager::closeConfigFile();
    return 0;
}
void registerRESTfulAPI(RawRequest &raw)
{
    SaveMeAppConfiguration saveMeAppConfiguration;
    RemoveMeAppConfiguration removeMeAppConfiguration;

    AuthenticateMeApp authenticateMeApp;
    RetrievePermittedServiceOps retrievePermittedServiceOps;
    RetrieveAuthorizedPotentialSubscribers retrieveAuthorizedPotentialSubscribers;
    RetrieveSubscribableServices retrieveSubscribableServices;
    RetrievePermittedTrafficRuleOps retrievePermittedTrafficRuleOps;

    raw.postDispatcher.registerHandler("serviceregistry/v1/configure", saveMeAppConfiguration);
    raw.delDispatcher.registerHandler("serviceregistry/v1/configure/UUID", removeMeAppConfiguration);
    raw.postDispatcher.registerHandler("serviceregistry/v1/policy/service", retrievePermittedServiceOps);
    raw.postDispatcher.registerHandler("serviceregistry/v1/policy/app", authenticateMeApp);
    raw.postDispatcher.registerHandler("serviceregistry/v1/policy/subscriber", retrieveAuthorizedPotentialSubscribers);
    raw.getDispatcher.registerHandler("serviceregistry/v1/policy/subscriber/UUID", retrieveSubscribableServices);
    raw.postDispatcher.registerHandler("serviceregistry/v1/policy/trafficrule", retrievePermittedTrafficRuleOps);
}
void handle_signals(int signal) {
    if (SIGTERM == signal) {
        MECFCGI_LOG(INFO, "SIGTERM SIGINT, exiting now\n");
        exit(0);
    }
}
int main(int argc, char *argv[])
{
    struct sigaction act;
    act.sa_handler = &handle_signals;
    act.sa_flags = 0;
    act.sa_flags |= SA_RESTART;
    sigfillset(&act.sa_mask);
    if (sigaction(SIGTERM, &act, NULL) == -1) {
        cerr<<"Cannot handle SIGTERM"<<endl;
        return -1;
    }

    if (0 != init(argc, argv)){
        return -1;
    }


    RawRequest raw ("/");
    registerRESTfulAPI(raw);
    FcgiBackend::run(raw);

    return 0;

}