/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file nes_dns.h
 * @brief Header file for nes_dns
 */


#ifndef NES_DNS_AGENT_H
#define	NES_DNS_AGENT_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "nts/nts_acl.h"

#define DNS_AGENT_LOCAL_DNS_IP "local-ip"
#define DNS_AGENT_LOCAL_DNS_MAC "local-mac"
#define DNS_AGENT_EXTERNAL_DNS_GW_MAC "external-dns-gw-mac"
#define DNS_AGENT_EXTERNAL_DNS_IP "external-ip"
#define DNS_AGENT_FORWARD_UNRESOLVED "forward-unresolved"

typedef struct dns_header_s {
    uint16_t id;

    // Little endian order
    uint8_t rd : 1;
    uint8_t tc : 1;
    uint8_t aa : 1;
    uint8_t opcode : 4;
    uint8_t qr : 1;

    uint8_t rcode : 4;
    uint8_t z : 3;
    uint8_t ra : 1;

    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t qrcount;
} __attribute__((__packed__)) dns_header_t;

/**
 * @brief dns agent main thread function
 *
 * @return NES_SUCCESS on success and NES_FAIL on fail.
 */
int nes_dns_agent_main(__attribute__((unused))void *);

int nes_dns_agent_add_routings(nes_acl_ctx_t* lookup_ctx);


#ifdef	__cplusplus
}
#endif

#endif	/* NES_DNS_AGENT_H */

