#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

set -e

# checking if "jq" package is installed
type jq > /dev/null 2>&1 || \
{
    echo "No \"jq\" package found"
    echo "Try to install with \"yum install jq\" command"
    exit
}

BASE_DIR=$(pwd)
CONFIG_FILE="config.json"
GGC_DEPLOYMENT=$(jq -r ".ProjectName" ${CONFIG_FILE})
LAMBDA_NAME=$(jq -r ".Lambda.Name" ${CONFIG_FILE})
LAMBDA_FILENAME=$(jq -r ".Lambda.Package" ${CONFIG_FILE})
RESOURCE_NAME=$(jq -r ".Resource.Name" ${CONFIG_FILE})
RESOURCE_PATH=$(jq -r ".Resource.Path" ${CONFIG_FILE})

IOTHOST=`aws iot describe-endpoint | jq -r ".endpointAddress"`
GGREGION=`aws configure get region`

# DELETE THING
#$1 Thing name
function delete_thing()
{
    THING=$(aws iot list-things | jq -r ".things[] | select (.thingName==\"${1}\")")
    if [ -n "${THING}" ]; then
        aws iot list-thing-principals --thing-name "$1" | \
            jq -r ".principals[]" | \
            while read thingcertid;
            do
                aws iot detach-thing-principal --thing-name ${1} --principal $thingcertid

                aws iot list-policy-principals --policy-name "${1}-Policy" | \
                    jq -r ".principals[]" | \
                    while read policycertid;
                    do
                        # delete only the same certificate attached to thing and policy
                        if [ "${thingcertid}" == "${policycertid}" ]; then
                            echo "Removing Policy \"${1}-Policy\""
                            aws iot detach-principal-policy --policy-name ${1}-Policy --principal ${thingcertid}
                            aws iot update-certificate --certificate-id ${thingcertid#*/} --new-status INACTIVE
                            aws iot delete-certificate --certificate-id ${thingcertid#*/}
                        fi
                    done
            done
        echo "Removing thing \"${1}\""
        aws iot delete-thing --thing-name ${1}
    fi
    POLICY=$(aws iot list-policies | jq -r ".policies[] | select (.policyName==\"${1}-Policy\")")
    if [ -n "${POLICY}" ]; then
        # detach certificate from policy if diffrent is attached
        aws iot list-policy-principals --policy-name "${1}-Policy" | \
            jq -r ".principals[]" | \
            while read policycertid;
            do
                echo "Removing cert from policy \"${1}-Policy\""
                aws iot detach-principal-policy --policy-name ${1}-Policy --principal ${thingcertid}
            done
        aws iot delete-policy --policy-name ${1}-Policy
    fi
}

# Group
aws greengrass list-groups | jq -r ".Groups[] | select (.Name==\"${GGC_DEPLOYMENT}-Group\") | .Id" | \
    while read groupid;
    do
        echo "Removing groupid $groupid";
        DEPLOYMENTS=$(aws greengrass list-deployments --group-id ${groupid} | \
            jq -r ".Deployments[]")
        if [ -n "${DEPLOYMENTS}" ]; then
            aws greengrass reset-deployments --group-id ${groupid}
        fi
        aws greengrass delete-group --group-id ${groupid}
    done

# Subscription
aws greengrass list-subscription-definitions | \
    jq -r ".Definitions[] | select (.Name==\"${GGC_DEPLOYMENT}-Sub\") | .Id" | \
    while read subid;
    do
        echo "Removing SubscriptionId $subid";
        aws greengrass delete-subscription-definition --subscription-definition-id ${subid}
    done

# Lambda functions
aws greengrass list-function-definitions | \
    jq -r ".Definitions[] | select (.Name==\"${LAMBDA_NAME}\") | .Id" | \
    while read lambdaid;
    do
        echo "Removing LambdaId $lambdaid";
        aws greengrass delete-function-definition --function-definition-id ${lambdaid}
    done

FUNCTION_ARN=$(aws lambda list-functions | \
    jq -r ".Functions[] | select (.FunctionName==\"${LAMBDA_NAME}\") | .FunctionArn")

if [ -n "${FUNCTION_ARN}" ]; then
    # LAMBDA aliases
    aws lambda list-aliases --function-name ${LAMBDA_NAME} | \
        jq -r ".Aliases[] | .Name" | \
        while read aliasname;
        do
            echo "Removing Alias $aliasname";
            aws lambda delete-alias --function-name "${LAMBDA_NAME}" --name "${aliasname}"
        done
    aws lambda delete-function --function-name "${LAMBDA_NAME}"
    echo "51"
    # Resources
    aws greengrass list-resource-definitions | \
        jq -r ".Definitions[] | select (.Name==\"${RESOURCE_NAME}\") | .Id" | \
        while read resid;
        do
            echo "Removing ResourceId $resid";
            aws greengrass delete-resource-definition --resource-definition-id ${resid}
        done
fi

aws greengrass list-core-definitions | \
    jq -r ".Definitions[] | select (.Name==\"${GGC_DEPLOYMENT}-Core\") | .Id" | \
    while read coreid;
    do
        echo "Removing CoreId $coreid";
        aws greengrass delete-core-definition --core-definition-id ${coreid}
    done

delete_thing "${GGC_DEPLOYMENT}-Core"

aws greengrass list-device-definitions | \
    jq -r ".Definitions[] | select (.Name==\"${GGC_DEPLOYMENT}-devices\") | .Id" | \
    while read devid;
    do
        echo "Removing DevId $devid";
        aws greengrass delete-device-definition --device-definition-id ${devid}
    done

# remove all devices
jq -r ".Devices[] | .Name" ${CONFIG_FILE} |
    while read devname;
    do
        delete_thing "${devname}"
    done

