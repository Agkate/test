/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
 * @file    Producer.cpp
 * @brief   Implementation of Producer.
 */

#include "Producer.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include "HttpsMaster.h"
#include <map>
#include "Log.h"
#include "Exception.h"

const string BASE_URL = "/appliance/v1";
map<string, string> Producer::serviceIds;

Producer::Producer()
{
}

Producer::~Producer() 
{
}

static void sendMessageToMEPlatform(string url, 
                                    string method, 
                                    Json::Value request, 
                                    string &status, 
                                    Json::Value &response)
{
    HttpsMaster requestMaster;
    string respBody = "";
    Json::Reader reader;    
    requestMaster.connect();
    requestMaster.httpsRequest(url, method, request, "application/json");
    try {
        requestMaster.httpsResponse(status, respBody);
        requestMaster.disconnect();
    }
    catch (Exception &e) {
        throw;
    }
    reader.parse(respBody, response);
}


void Producer::doNotifyData(string data){
    Json::Reader reader;
    Json::Value serviceData;
    reader.parse(data, serviceData);
    string serviceName = serviceData["serviceData"]["serviceName"].asString();
    string serviceId = Producer::serviceIds[serviceName];
    
    Json::Value request, response;
    request["serviceData"] = serviceData["serviceData"];
    request["serviceId"] = serviceId;
    string method = "POST";
    string URL = BASE_URL + "/notifications";
    string status = "";
    sendMessageToMEPlatform(URL, method, request, status, response);
    if(response.get("result", "Nil").compare("OK") != 0) {
        MECFCGI_LOG(ERR, 
            "[NG] Mobile Edge Service Data Update and Publication: %s, DATA:%s.\n",
            response.get("result", "Nil").asString().c_str(), data.c_str());
    }
}

bool Producer::activateMobileEdgeService(string serviceInfo)
{
    Json::Reader reader;
    Json::Value request, response;
    reader.parse(serviceInfo, request);
    string serviceName = request["serviceName"].asString();

    string method = "POST";
    string URL = BASE_URL + "/service";
    string status = "";
    sendMessageToMEPlatform(URL, method, request, status, response);
    if((response.get("result", "Nil").compare("OK") != 0) &&
        (response.get("result", "Nil").compare("ServiceExist") != 0)) {
        MECFCGI_LOG(ERR, "[NG] Mobile Edge Service Activation: %s",
            response.get("result", "Nil").asString().c_str());
        return false;
    } else {
        string serviceId = response.get("serviceId", "Nil").asString();
        Producer::serviceIds.insert(make_pair(serviceName, serviceId));
    }
    return true;
}

bool Producer::producerLiveIndicator(string appid, string secret)
{
    Json::Value request, response;
    request["appid"] = appid;
    request["secret"] = secret;
    request["type"] = "MEPLATFORMPRODUCERAPP";
    
    string URL = BASE_URL + "/live_apps";
    string method = "POST";
    string status = "";
    sendMessageToMEPlatform(URL, method, request, status, response);
    string result = response.get("result", "Nil").asString();
    if((result.compare("OK") != 0) &&
        (result.compare("AppidAuthenticated") != 0)) {
        MECFCGI_LOG(ERR, "[NG] Mobile Edge Application Live Indicator: %s", 
            result.c_str());
        return false;
    }
    return true;
}
