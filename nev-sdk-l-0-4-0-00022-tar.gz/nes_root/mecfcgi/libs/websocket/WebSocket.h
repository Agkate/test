/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/** 
 * @file    WebSocket.h
 * @brief   The class in this file is responsible for handling Mobile Edge
 *          Application Connection Establishment.
 *          An ME App/ME App Service can use the procedure below to establish a 
 *          connection.
 *            - Procedure       Notifications Request
 *            - Schemes         ws
 *            - URL             /appliance/v1/notifications/{RefID}
 *            - Method          GET
 *            - Content Type    N/A
 *            - Request Body    N/A
 *          By calling function "sendEventToClient", the ME Platform can push 
 *          message to ME App/ME App Service.
 */

#ifndef __MECFCGI__WEBSOCKET__  
#define __MECFCGI__WEBSOCKET__  
#pragma once
#include "Defs.h"
#include <iostream>
#include <map>
using namespace std;

typedef void* ( *WebSocketDataHandFunction )(void *);

class CWebSocket;

typedef struct {
    CWebSocket *ws;
    SOCKET clSock;
}SocketInfo;

class CWebSocket
{
public:
    CWebSocket(void);
    ~CWebSocket(void);

    /**
    * @brief        Initializes socket with information.
    * @param[in]    hostIp        Host ip to establish a connection.
    * @param[in]    portNo        Port NO. to establish a connection.
    * @param[in]    maxLis        Maximum length of the waiting queue.
    * @return       true.
    */
    void initSocket(string hostIp, int portNo, int maxLis);
 
    /**
    * @brief        Gets handshake message from App/ME App Service and 
    *               generate a header message.
    * @param[out]   dest          Header message.
    * @param[in]    req           Request info that comes from ME App/ME App 
    *                             Service.
    * @param[out]   token         ME App/ME App Service's token (reference ID).
    * @return       Header message.
    */ 
    char *get_hand_shake_msg(char *dest, char *req, string &token);

    /**
    * @brief        Sets a socket mapping using ME App's/ME App Service's token
    *               and socket.
    * @param[in]    token         ME App's/ME App Service's token 
    *                             (reference ID).
    * @param[in]    sock          Communication chain handle used to describe 
    *                             IP address and port.
    * @return       true on success and false on fail.
    */ 
    bool setNewSocket(string token, SOCKET sock);

    /**
     * @brief        Deletes a socket mapping from the client list.
     * @param[in]    token         ME App's/ME App Service's token 
     *                             (reference ID).
     * @return       true on success and false on failuire.
     */ 
    bool closeSocket(string token);
 
    /**
     * @brief        Sends message to client.
     * @param[in]    token         ME App's/ME App Service's token
     *                             (reference ID).
     * @param[in]    pdata         Message data to be sent.
     * @param[in]    size          Size of message data.
     * @return       The total number of data sent on success and -1 on fail.
     */ 
    int sendEventToClient(string token, char *pdata, int size);

    /**
     * @brief        Encodes data to be sent.
     * @param[in]    data         Un-encoded message data.
     * @param[out]   msg          Encoded message data.
     * @return       integer
     */ 
    int getEncodeOutgoingMsg(char *msg, char *data);

    /**
     * @brief        Encodes a plain-text string into a sha1-encrypted string.
     * @param[in]    source        Unencrypted string.
     * @param[out]   dest          Encrypted string.
     * @return       void
     */
    void get_sha1_string(char *dest, char *source);
    
    /**
     * @brief        Starts a listening thread to receive socket connections.
     * @return       false on fail.
     */
    bool startListenThread();    
    
    /**
     * @brief        Pushes data to ME App/ME App Service.
     * @param[in]    target         The target of the data push(sessionId).
     * @param[in]    eventId        An event ID to be sent.
     * @param[in]    data           The data to be sent.
     * @return       void
     */
    void pushData(string target, const string eventId, string data);

protected:
    /**
     * @brief        Handles a connection with given socket info.
     * @param[in]    parm        socket info.
     * @return       void
     */
    static void * websocketHandAConnection(void *parm);
private:    
    SOCKET m_hSocket;
    
    map<string, SOCKET> clientList;
    string ip;
    int    port;
    int    maxListeners;
    WebSocketDataHandFunction dataHandFunction;
    static pthread_cond_t cond;  
    static pthread_mutex_t lock ;  
    
    pthread_mutex_t listLock;
};

#endif
