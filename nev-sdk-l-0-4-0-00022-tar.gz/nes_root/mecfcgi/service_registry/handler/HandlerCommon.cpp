/*******************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2018 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intel's prior express written permission.
* 
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intel's suppliers
* or licensors in any way.
* 
*  version: NEV_SDK.L.0.4.0-00022
*******************************************************************************/
/**
* @file     HandlerCommon.cpp
* @brief    Commonly-used function implementaitons.
*/

#include "HandlerCommon.h"
#include <boost/regex.hpp>
#include <arpa/inet.h>

// Traffic Rules Control type macro definitions
const string RULE_FIELD_NAME_PRIO = "prio";
const string RULE_FIELD_NAME_ENCAP_PROTO = "encap_proto";
const string RULE_FIELD_NAME_UE_IP = "ue_ip";
const string RULE_FIELD_NAME_SRV_IP = "srv_ip";
const string RULE_FIELD_NAME_ENB_IP = "enb_ip";
const string RULE_FIELD_NAME_EPC_IP = "epc_ip";
const string RULE_FIELD_NAME_UE_PORT = "ue_port";
const string RULE_FIELD_NAME_SRV_PORT = "srv_port";

const uint32_t IP_MASK_MIN = 0;
const uint32_t IP_MASK_MAX = 32;
const uint32_t PORT_MIN = 0;
const uint32_t PORT_MAX = 65535;
const uint32_t PRIO_MAX = 536870911;

using namespace std;
using namespace boost;

const string macExpr =  "([0-9a-fA-F]{2}):([0-9a-fA-F]{2}):([0-9a-fA-F]{2})"
                        ":([0-9a-fA-F]{2}):([0-9a-fA-F]{2}):([0-9a-fA-F]{2})";


bool checkIPv4(const char *ip_str) {
    struct sockaddr_in sa;
    return 1 == inet_pton(AF_INET, ip_str, &(sa.sin_addr));
}

bool checkRegex(string expr, const char *str)
{
    regex expression(expr);
    cmatch what;
    if (!regex_match(str, what, expression)){
        return false;
    }
    return true;
}

void HandlerCommon::checkTrafficRuleFormat(string &result, Json::Value traffic)
{
    // MAC address Check
    if (!traffic.isMember("macAddress")) {
        // Invalid MAC Address
        result = "InvalidMacAddress";
        return;
    }
    string macAddress = traffic.get("macAddress","Nil").asString();
    if(!checkRegex(macExpr, (char*)macAddress.c_str())){
        // Invalid MAC Address
        result = "InvalidMacAddress";
        return;
    }
    // VM ID Check
    if ((!traffic.isMember("vmId")) || (!traffic["vmId"].isUInt())) {
        // Invalid VM id
        result = "InvalidVMId";
        return;
    }

    // TrafficRule Check
    if ((!traffic.isMember("trafficRule")) ||
        (!traffic["trafficRule"].isObject())){
        // Invalid traffic rule
        result = "InvalidTrafficRule";
        return;
    }
    Json::Value trafficRule = traffic.get("trafficRule","Nil");
    if ((!trafficRule.isMember(RULE_FIELD_NAME_PRIO)) ||
        (!trafficRule[RULE_FIELD_NAME_PRIO].isUInt())) {
        // Invalid prio
        result = "InvalidTrafficRule";
        return;
    }
    if (trafficRule.get(RULE_FIELD_NAME_PRIO, "").asUInt() > PRIO_MAX){
        // Invalid prio
        result = "InvalidTrafficRule";
        return;
    }
    // Rule Fields Check
    if ((!trafficRule.isMember("ruleFields")) ||
        (!trafficRule["ruleFields"].isArray())){
        // Invalid rule fields
        result = "InvalidTrafficRule";
        return;
    }

    Json::Value ruleFields = trafficRule.get("ruleFields","Nil");
    int size = ruleFields.size();
    for (int i = 0; i < size; i++) {
        if (!ruleFields[i].isMember("name")){
            // Invalid name in rule field
            result = "InvalidTrafficRule";
            return;
        }
        string name = ruleFields[i].get("name","Nil").asString();
        if (0 == name.compare(RULE_FIELD_NAME_ENCAP_PROTO)) {
            string value =
                ruleFields[i].get("value","Nil").asString();
            if ((0 != value.compare("gtpu")) &&
                (0 != value.compare("noencap"))) {
                result = "InvalidTrafficRule";
                return;
            }
        } else if ((0 == name.compare(RULE_FIELD_NAME_UE_IP)) ||
            (0 == name.compare(RULE_FIELD_NAME_SRV_IP)) ||
            (0 == name.compare(RULE_FIELD_NAME_ENB_IP)) ||
            (0 == name.compare(RULE_FIELD_NAME_EPC_IP))) {
            if (!ruleFields[i].isMember("ip")){
                // Invalid ip in rule field
                result = "InvalidTrafficRule";
                return;
            }
            string ip = ruleFields[i].get("ip","Nil").asString();
            if(!checkIPv4((char*)ip.c_str())){
                // Invalid ip in rule field
                result = "InvalidTrafficRule";
                return;
            }
            // IP Mask check
            if (ruleFields[i].isMember("ip_mask")){
                if (!ruleFields[i]["ip_mask"].isUInt()) {
                    // Invalid ip mask in rule field
                    result = "InvalidTrafficRule";
                    return;
                }
                uint32_t ip_mask = ruleFields[i].get("ip_mask", "").asUInt();
                if (ip_mask > IP_MASK_MAX) {
                    // Invalid ip mask in rule field
                    result = "InvalidTrafficRule";
                    return;
                }
            }
        } else if ((0 == name.compare(RULE_FIELD_NAME_UE_PORT)) ||
                    (0 == name.compare(RULE_FIELD_NAME_SRV_PORT))) {
            if ((!ruleFields[i].isMember("min")) ||
                (!ruleFields[i]["min"].isUInt())) {
                // Invalid min
                result = "InvalidTrafficRule";
                return;
            }

            uint32_t min = ruleFields[i].get("min", "").asUInt();
            uint32_t max = min;
            if (ruleFields[i].isMember("max")){
                if (!ruleFields[i]["max"].isUInt()) {
                    // Invalid max
                    result = "InvalidTrafficRule";
                    return;
                }
                max = ruleFields[i].get("max", "").asUInt();
            }

            if  ((min > max) || (max > PORT_MAX)) {
                // Invalid min or max
                result = "InvalidTrafficRule";
                return;
            }
        }
        else {
            // Undefined field
            result = "InvalidTrafficRule";
            return;
        }
    }
    result = "OK";
}

void HandlerCommon::compareTrafficRule(bool &match, Json::Value settableTraffic,
                                        Json::Value traffic)
{
    match = false;
    string macAddress = traffic.get("macAddress", "Nil").asString();
    if (0 != macAddress.compare(
        settableTraffic.get("macAddress", "Nil").asString())) {
        // MacAddress mismatch
        return;
    }

    if (traffic.get("vmId","").asUInt() !=
        settableTraffic.get("vmId","").asUInt()){
        // vmId mismatch
        return;
    }

    if (settableTraffic["trafficRule"].get(RULE_FIELD_NAME_PRIO, "").asUInt()
        != traffic["trafficRule"].get(RULE_FIELD_NAME_PRIO, "").asUInt()) {
        // prio mismatch
        return;
    }

    Json::Value settableRuleFields =
        settableTraffic["trafficRule"]["ruleFields"];

    Json::Value ruleFields = traffic["trafficRule"]["ruleFields"];
    int settableRuleFieldsSize = settableRuleFields.size();
    int size = ruleFields.size();

    if ( settableRuleFieldsSize != size ){
        // ruleFields size mismatch
        return;
    }

    for (int i = 0; i < settableRuleFieldsSize; i++){
        bool fieldMatch = false;
        for (int j = 0; j < size; j++){
            if (ruleFields[j].isMember("matched")){
                continue;
            }
            string name = ruleFields[j].get("name","Nil").asString();
            if (0 == name.compare(settableRuleFields[i].get(
                "name","Nil").asString())){
                if (0 == name.compare(RULE_FIELD_NAME_ENCAP_PROTO)) {
                    string value =
                        ruleFields[j].get("value","Nil").asString();
                    if (0 != value.compare(
                        settableRuleFields[i].get("value","Nil").asString())) {
                        //encap_proto mismatch
                        return;
                    }
                } else if ((0 == name.compare(RULE_FIELD_NAME_UE_IP)) ||
                    (0 == name.compare(RULE_FIELD_NAME_SRV_IP)) ||
                    (0 == name.compare(RULE_FIELD_NAME_ENB_IP)) ||
                    (0 == name.compare(RULE_FIELD_NAME_EPC_IP))) {
                    string ip = ruleFields[j].get("ip","Nil").asString();
                    if (0 != ip.compare(settableRuleFields[i].get(
                        "ip","Nil").asString())){
                        // ip mismatch
                        return;
                    }

                    if ((ruleFields[j].isMember("ip_mask")) && 
                        (settableRuleFields[i].isMember("ip_mask"))) {
                        if (settableRuleFields[i].get("ip_mask", "").asUInt() !=
                            ruleFields[j].get("ip_mask", "").asUInt()){
                            // ip mask mismatch
                            return;
                        }
                    } else if (settableRuleFields[i].isMember("ip_mask") ||
                        (ruleFields[j].isMember("ip_mask")) ){
                        // ip mask mismatch
                        return;
                    }
                } else if ((0 == name.compare(RULE_FIELD_NAME_UE_PORT)) ||
                            (0 == name.compare(RULE_FIELD_NAME_SRV_PORT))) {
                    uint32_t min = ruleFields[j].get("min", "").asUInt();
                    uint32_t max = min;
                    if (ruleFields[j].isMember("max")){
                        max = ruleFields[j].get("max", "").asUInt();
                    }
                    uint32_t settableMin =
                        settableRuleFields[i].get("min", "").asUInt();
                    uint32_t settableMax = settableMin;
                    if (settableRuleFields[i].isMember("max")){
                        settableMax =
                            settableRuleFields[i].get("max", "").asUInt();
                    }

                    if ((settableMin > min) || (settableMax < max)) {
                        // Min or Max mismatch
                        return;
                    }
                }
                else {
                    // Undefined field
                    return;
                }
                ruleFields[j]["matched"] = "matched";
                fieldMatch = true;
                break;
            }
        }
        if (!fieldMatch){
            // Rule Field mismatch
            return;
        }
    }
    match = true;
}


