/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 ************************************************************************************/
/**
 * @file nes_latency.c
 * @brief implementation of nes_latency
 */
#include "nes_latency.h"
#include "nes_common.h"

#ifdef NES_LATENCY
static FILE* stats_file;

extern struct latency_stats_s latency_stats;
extern rte_atomic16_t reset_stats;

static void
print_stats(void) {
    if (NULL == stats_file) {
        return;
    }

    static double cpu_freq = 0;
    if (0 == cpu_freq)
        cpu_freq = rte_get_tsc_hz() / 1E6;
    fprintf(stats_file, "%.03f,%.03f,%.03f,%"PRIu64"\n",
            latency_stats.min / cpu_freq,
            (latency_stats.total / latency_stats.pkts) / cpu_freq,
            latency_stats.max / cpu_freq,
            latency_stats.pkts);
    fflush(stats_file);
}

int
nes_latency_main(__attribute__((unused))void *arg) {
    stats_file = fopen(LATENCY_STATS_FILE_PATH, "w+");
    if (NULL == stats_file) {
        NES_LOG(ERR, "Failed to open %s, stats won't be saved!\n", LATENCY_STATS_FILE_PATH);
    }

    fprintf(stats_file, "Min[us],Avg[us],Max[us],Pkts,Check interval: %d ms\n", PRINT_LATENCY_STATS_DELAY_MS);
    NES_LOG(INFO, "nes_latency_main started\n");
    while (1) {
        if (latency_stats.pkts) {
            print_stats();
        }
        rte_atomic16_set(&reset_stats, 1);
        rte_delay_ms(PRINT_LATENCY_STATS_DELAY_MS);
    }
    return 0;
}
#endif