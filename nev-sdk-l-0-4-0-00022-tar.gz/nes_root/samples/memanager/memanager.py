#!/usr/bin/python
# coding: utf-8
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

import httplib2
import threading
import socket
import time
import json
import sys
import re
import ctypes
import getopt
import os.path
import logging
import websocket
import random
import commands

def outputLog():  
    if False == os.path.exists('./log'):
        os.makedirs('./log')
    logFilename = './log/memanager.log'
    logging.basicConfig(  
                    level   = logging.DEBUG,                                                           
                    format  = '%(message)s',
                    datefmt = '%m-%d %H:%M',
                    filename= logFilename, 
                    filemode= 'w')

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(message)s')
    console.setFormatter(formatter)  
    logging.getLogger().addHandler(console)

MEMANAGER_LOG = logging.getLogger('MEMANAGER_LOG')

# Select a module to run by specifying the corresponding command
COMMANDS = {'L1': 'oqn',
            'L2': 'atvldq'}
dictOpts = {'quit': 'q',                                    # common
            'nevSdk': 'n', 'logOut': 'o',                   # L1
            'applicationconfiguration': 'a',                # L2
            'applicationtermination': 't',
            'applicationtestart': 'v',
            'applicationtestop': 'd',
            'connectionestablishment': 'l'}
gLevel = 'L1'

class Vector:
    first=""
    second=""
    def __init__(self,x,y):
        self.first=x
        self.second=y

# Memanager class
class Memanager:
    def __init__(self):
        self.__HOSTPORT = '8080'                            # host port
        self.__WEBSOCKETPORT = '8888'
        self.__HOSTADDR = 'mec.local'                         # host ip
        self.__CERTPATH = '/etc/nginx/ssl/mec.crt'
        self.__h = httplib2.Http(".cache", ca_certs=self.__CERTPATH)
        self.__cookie = ''                                  # cookie value
        self.__stopped = True                               # thread switch
        self.__baseJsonPath = "json/"                       # file path prefix for json files
        self.logFlagForDebug = False                        # debug log output switch
        self.index = ''
        self.thread = ""                                    # websocket thread
        self.platformType = 1
        self.provideConfigurationList = []
        self.finishedConfigurationList = []
        self.appStartList = []
        self.appVMList = []
        self.__appid = ""
        self.__baseUrl = 'https://' + self.__HOSTADDR + ':' + self.__HOSTPORT + '/appliance/v1' # url prefix

# Mobile Edge Application Configuration(-a)
    def applicationConfiguration(self):
        procedure = 'Configuration Request Request'
        url = self.__baseUrl + '/configuration'
        method = "POST"
        contentType = "application/json"
        requestBody = ""
        jsonPath = self.__baseJsonPath + 'AppConfiguration'
        if not os.path.exists(jsonPath):
            print("The directory \"{}\" cannot be found.".format(jsonPath))
            return

        for parent,dirnames,filenames in os.walk(jsonPath):
            if not filenames:
                print "There are no configuration files found on the specified path."
                return
            del self.provideConfigurationList[:]
            for filename in filenames:
                fileCon = self.loadJsonFile(os.path.join(parent, filename))
                appid = fileCon['appid']
                provideConfiguration = Vector(appid, fileCon)
                self.provideConfigurationList.append(provideConfiguration)
        if self.__appid:
            for provideConfiguration_ in self.provideConfigurationList:
                if self.__appid == provideConfiguration_.first:
                    requestBody = provideConfiguration_.second
                    appid = provideConfiguration_.first
                    break
            if not requestBody:
                print("The appid specified on the command line is not found.")
                return
        else:
            userSelect = self.getServicesFromUser(self.provideConfigurationList)
            if not userSelect.first:
                print("No serial number was entered.")
                return
            appid = userSelect.first
            requestBody = userSelect.second

        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            found = False
            for finishedConfiguration_ in self.finishedConfigurationList:
                if appid == finishedConfiguration_.first:
                    found = True
                    break
            if not found:
                finishenConf = Vector(appid, requestBody)
                self.finishedConfigurationList.append(finishenConf)
            print('[OK] Mobile Edge Application Configuration.')
        else:
            print('[NG] Mobile Edge Application Configuration.')

# Do Mobile Edge Application Termination(-t)
    def applicationTermination(self):
        procedure = 'Termination Request'
        url = self.__baseUrl + '/termination'
        method = "POST"
        contentType = "application/json"
        requestBody = {"appid":"", "gracefulTerminationTimeout": 10}

        if not self.finishedConfigurationList:
            print("There are no finished configuration.")
            return
        if self.__appid:
            requestBody["appid"] = self.__appid
            requestBody["gracefulTerminationTimeout"] = 10
            str = '1'
            self.index = str.split()
        else:
            appid = self.getServicesFromUser(self.finishedConfigurationList).first
            if not appid:
                print("No serial number was entered.")
                return
            tmpCount = raw_input('\n>>>Please enter the length of graceful termination period in seconds, \n    or press enter to use the default value (10):')
            timer = self.checkAttrForUpdate(tmpCount, '10')
            timeout = timer.split()

            requestBody["appid"] = appid
            requestBody["gracefulTerminationTimeout"] = int(timeout[0])
        # send request
        resp, content = self.__h.request(url,
                                        method,
                                        json.dumps(requestBody),
                                        headers={'content-type': contentType, 'cookie': self.__cookie})

        if self.logFlagForDebug:
            # output log
            self.reqLogout({'Tip':procedure,
                            'URL':url,
                            'Method':method,
                            'ContentType':contentType,
                            'Cookie':self.__cookie,
                            'Body':requestBody})
            self.respLogout({'Tip':procedure.replace('Request','Response'),
                            'Resp':resp,
                            'Content':content})

        # check result
        if self.checkResult(resp, content):
            
            self.finishedConfigurationList.pop(int(self.index[0])-1)
            print('[OK] Mobile Edge Application Termination.')
        else:
            print('[NG] Mobile Edge Application Termination.')

    def checkAttrForUpdate(self, value, defaultValue):
        while True:
            if not value:
                value = defaultValue
                break
            else:
                if not re.match('^[0-9]+$', value):
                    value = raw_input('\n>>>The input is not a valid number. Please enter again:')
                    continue
                break
        return value
# Do Mobile Edge Application Instance Launch Process(-v)   
    def applicationteStart(self):
        if self.platformType == 0:
            jsonPath = self.__baseJsonPath + 'StartVM/windriver'
        elif self.platformType == 1:
            jsonPath = self.__baseJsonPath + 'StartVM/centos'
        if not os.path.exists(jsonPath):
            print("The directory \"{}\" cannot be found.".format(jsonPath))
            return
        vmid = ""
        for parent,dirnames,filenames in os.walk(jsonPath):
            if not filenames:
                print "There are no configuration files found on the specified path."
                return
            del self.appStartList[:]
            for filename in filenames:
                fileCon = self.loadJsonFile(os.path.join(parent, filename))
                appid = fileCon['appid']
                appStart = Vector(appid, fileCon)
                self.appStartList.append(appStart)
        if self.__appid:
            appid = ""
            for appStart_ in self.appStartList:
                if self.__appid == appStart_.first:
                    appid = appStart_.first
                    vmid = appStart_.second["vmid"]
                    imageName = appStart_.second["imageName"]
                    break
            if not appid:
                print("The appid specified on the command line is not found.")
                return
        else:
            userSelect = self.getServicesFromUser(self.appStartList)
            if not userSelect.first:
                print("No serial number was entered.")
                return
            appid = userSelect.first
            vmid = userSelect.second["vmid"]
            imageName = userSelect.second["imageName"]
        
        path = sys.path[0]
        command = path + '/script/start_vm.sh is_running ' + str(vmid)
        (status, output) = commands.getstatusoutput(command)
        if status == 0:
            appVM = Vector(appid, vmid)
            if appVM not in self.appVMList:
                self.appVMList.append(appVM)
            print 'The vm{} was already exist.'.format(vmid)
            return
        command = path + '/script/start_vm.sh start_vm ' + imageName + ' ' + str(vmid)
        if self.platformType == 0: 
            (status, output) = commands.getstatusoutput(command)
            if status == 0:
                if self.platformType == 1: 
                    if output.find("failed") != -1:
                        print('[NG] Mobile Edge Application Instance Launch Process.')
                        return
                appVM = Vector(appid, vmid)
                self.appVMList.append(appVM)
                print('[OK] Mobile Edge Application Instance Launch Process.')
            else:
                print('[NG] Mobile Edge Application Instance Launch Process.')
        else:
            os.popen(command)
            time.sleep(5)
            path = sys.path[0]
            command = path + '/script/start_vm.sh is_running ' + str(vmid)
            print command
            (status, output) = commands.getstatusoutput(command)
            if (status == 0):
                appVM = Vector(appid, vmid)
                if appVM not in self.appVMList:
                    self.appVMList.append(appVM)
                print('[OK] Mobile Edge Application Instance Launch Process.')
                return
            print('[NG] Mobile Edge Application Instance Launch Process.')
# Do Mobile Edge Application Instance Termination Process(-d)   
    def applicationteStop(self):
        if not self.appVMList:
            print("There are no VM instances.")
            return
        if self.__appid:
            appid = ""
            for appVM_ in self.appVMList:
                if self.__appid == appVM_.first:
                    appid = appVM_.first
                    vmid = appVM_.second
                    sr = '1'
                    self.index = sr.split()
                    break
            if not appid:
                print("The appid specified on the command line is not found.")
                return
        else:
            userSelect = self.getServicesFromUser(self.appVMList)
            if not userSelect.first:
                print("No serial number was entered.")
                return
            appid = userSelect.first                    
            vmid = userSelect.second
        path = sys.path[0]
        command = path + '/script/start_vm.sh stop_vm ' + str(vmid)
        (status, output) = commands.getstatusoutput(command)

        if status == 0:
            print('[OK] Mobile Edge Application Instance Termination Process.')
            self.appVMList.pop(int(self.index[0])-1)                               
        else:
            print('[NG] Mobile Edge Application Instance Termination Process.')

# Do Mobile Edge Platform Manager Connection Establishment(-l)
    def connectionEstablishment(self):
        if not self.__stopped:
            print('[WARNING] ME Platform Manager Connection is already established.')
            return
        self.__stopped = False
        self.thread = threading.Thread(name = "WebsocketThread", target = self.createWebSocket)
        self.thread.setDaemon(True)
        self.thread.start()

# Delete thread
    def delWebSocket(self):
        self.__stopped = True

    def formatChannelListenerResponse(self, str):
        str = list(str)
        temp = ""
        count = 0
        for s in str:
            if s == '{' :
                count += 1
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == '[' :
                count += 1
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == ',':
                temp += s + '\n'
                temp = self.addTable(temp,count)
            elif s == '}':
                count -= 1
                temp += '\n'
                temp = self.addTable(temp,count)
                temp += s
            elif s == ']':
                count -= 1
                temp += '\n'
                temp = self.addTable(temp,count)
                temp += s
            else:
                temp += s
        return temp
    def addTable(self,s,num):
        for i in range(0,num):
            s += '    '
        return s

# Create WebSocket
    def createWebSocket(self):
        url = 'ws://' + self.__HOSTADDR + ':' + self.__WEBSOCKETPORT + '/notifications/memanager'
        try:
            websocket.enableTrace(True)
            ws = websocket.create_connection(url)
        except:
            print ('[NG] ME Platform Manager Connection Establishment Failed: WebSocket header is invalid. Please try again.')
            self.__stopped = True
            return
        print ('[OK] ME Platform Manager Connection Establishment.')
        while not self.__stopped:
            result = ws.recv()
            if result:
                printResult = self.formatChannelListenerResponse(result)
                MEMANAGER_LOG.info(printResult)                
                if result.find('id') != -1 and result.find('data') != -1:
                    respDic = json.loads(result)
                    appid = respDic['data']                    
                    for appVM_ in self.appVMList:
                        if appid == appVM_.first:
                            vmid = appVM_.second                      
                            command = path + '/script/start_vm.sh stop_vm ' + str(vmid)
                            (status, output) = commands.getstatusoutput(command)
                            if status == 0:
                                print('[OK] Mobile Edge Application Instance Termination Process.')
                                self.appVMList.remove(appVM_)                                
                            else:
                                print('[NG] Mobile Edge Application Instance Termination Process.')
                            

# result check
    def checkResult(self, resp, content):
        if not 'status' in resp:
            print "The HTTP server is not running!"
            return False
        try:
            respDic = json.loads(content)
            if respDic['result'] == "OK" or respDic['result'] == "AppidAuthenticated":
                return True
            else:
                print('result:{}'.format(respDic['result']))
                return False
        except ValueError:
            print "The HTTP server is not running!"
            return False
# Returns the selected content according to the user's choice
    def getServicesFromUser(self, selectedList):
        userSelect = Vector("","")
        if not selectedList or None == selectedList:
            return userSelect
        else:
            self.printSelectedList(selectedList)
        # Waiting for user input
        max = len(selectedList)
        while 1:
            str = raw_input('>>>>>>Please enter a serial number within the range [1-{}] :'.format(max))
            self.index = str.split()
            if not str:
                return userSelect
            elif len(self.index) > 1:
                print('Input contains multiple characters.')
            elif not re.search(r'^[\d\s]*$', str):
                print('Input contains non-numeric characters.')
            elif int(self.index[0]) > max or int(self.index[0]) < 1:
                print('No.{} is out of range.'.format(int(self.index[0])))
            else:
                break

        userSelect = selectedList[int(self.index[0])-1]
        return userSelect
# print list of selected items
    def printSelectedList(self, selectedList):
        count = 0
        print('No.    itemName')
        for sub in selectedList:
            count += 1
            print(' {}     {}'.format(count, sub.first, indent=2))
# read data from json file
    def loadJsonFile(self, path):
        fp = open(path, 'r')
        jsonData = json.load(fp)
        fp.close()

        return jsonData

# output request log
    def reqLogout(self, data):
        if data['Body']:
            data['Body'] = json.dumps(data['Body'], sort_keys=True, indent=4)
        MEMANAGER_LOG.info('')
        MEMANAGER_LOG.info("{}".format(data['Tip']))
        MEMANAGER_LOG.info('')
        MEMANAGER_LOG.info("Request Header")
        MEMANAGER_LOG.info("  URL        : {}".format(data['URL']))
        MEMANAGER_LOG.info("  Method     : {}".format(data['Method']))
        MEMANAGER_LOG.info("  ContentType: {}".format(data['ContentType']))
        MEMANAGER_LOG.info("  Cookie     : {}".format(data['Cookie']))
        MEMANAGER_LOG.info('')
        MEMANAGER_LOG.info("Request Body")
        MEMANAGER_LOG.info('{}'.format(data['Body']))
        MEMANAGER_LOG.info('')

# output response log
    def respLogout(self, data):
        data['Resp'] = json.dumps(data['Resp'], sort_keys=True, indent=4)
        if "result" in data['Content']:
            data['Content'] = json.dumps(json.loads(data['Content']), sort_keys=True, indent=4)
        MEMANAGER_LOG.info('')
        MEMANAGER_LOG.info("{}".format(data['Tip']))
        MEMANAGER_LOG.info('')
        MEMANAGER_LOG.info("Response Header")
        MEMANAGER_LOG.info('{}'.format(data['Resp']))
        MEMANAGER_LOG.info('')
        MEMANAGER_LOG.info("Response Body")
        MEMANAGER_LOG.info('{}'.format(data['Content']))
        MEMANAGER_LOG.info('')

    def setJsonPath(self, path):
        self.__baseJsonPath = path
    def setAppid(self, appid):
        self.__appid = appid
# python parameter specification
def usage(name):
    global gLevel
    print ""
    if 'L1' == gLevel:
        print "[ {} ] Demonstrate ME Manager API ".format("n")
        print "[ {} ] Enable Log ".format("o")
        print "[ {} ] Exit".format("q")
    elif 'L2' == gLevel:
        print "[ {} ] Do Application Configuration".format("a")
        print "[ {} ] Do Application Termination".format("t")
        print "[ {} ] Do Manager Connection Establishment".format("l")
        print "[ {} ] Do Mobile Edge Application Instance Launch Process".format("v")
        print "[ {} ] Do Mobile Edge Application Instance Termination Process".format("d")
        print "[ {} ] Back".format("q")
    else:
        pass

def levelOne(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        print "exit program"
        sys.exit(0)
    if dictOpts['nevSdk'] in opts:
        gLevel = 'L2'
        usage(sys.argv[0] + ': ' + gLevel)

def levelTwo(opts):
    global gLevel
    if dictOpts['quit'] in opts:
        gLevel = 'L1'
        usage(sys.argv[0] + ': ' + gLevel)
        return
    for subOpts in opts:
        if dictOpts['applicationconfiguration'] == subOpts:
            memanager.applicationConfiguration()
        elif dictOpts['applicationtermination'] == subOpts:
            memanager.applicationTermination()
        elif dictOpts['connectionestablishment'] == subOpts:
            memanager.connectionEstablishment()
        elif dictOpts['applicationtestart'] == subOpts:
            memanager.applicationteStart()
        elif dictOpts['applicationtestop'] == subOpts:
            memanager.applicationteStop()
        else:
            pass


levelFunc = {'L1': levelOne, 'L2': levelTwo}

# Module execution control
def modulePerforms(opts):
    global gLevel
    if not opts:
        usage(sys.argv[0] + ': ' + gLevel)
        return

    if dictOpts['logOut'] in opts:
        # turn on debug log output switch
        memanager.logFlagForDebug = True
        opts.remove(dictOpts['logOut'])
    levelFunc.get(gLevel)(opts)

# convert string into opts
def stringToOpts(data):
    global gLevel
    opts = []
    dataTemp = re.findall('[A-Za-z]+', data)
    dataTemp = list('.'.join(dataTemp))
    for sep in dataTemp:
        if sep in COMMANDS[gLevel]:
            opts.append(sep)
    return opts

def initPlatformType():
    path = sys.path[0]
    command = path + '/script/start_vm.sh is_wr'
    (status, output) = commands.getstatusoutput(command)
    if status == 0:
        memanager.platformType = 0
    else:
        memanager.platformType = 1
if __name__ == '__main__':
    outputLog()
    memanager = Memanager()
    initPlatformType()
    actioncontinue = ""
    if len(sys.argv) > 1:
        try:
            opts, args = getopt.getopt(sys.argv[1:], "t:p:n:a:", ["actioncontinue=","path=","noninteractive=", "appid="])
        except getopt.GetoptError:
            print sys.argv[0], " [-t <actioncontinue>] [-p <json path>] [-n <cmds>] [-a <appid>]"
            sys.exit(1)

        cmds = ""
        JsonPath = ""
        cookie = ""

        for opt, arg in opts:
            if opt in ("-p", "--path"):
                JsonPath=arg
                if not JsonPath or not os.path.exists(JsonPath):
                    print("The directory \"{}\" cannot be found.".format(JsonPath))
                    print "exit program"
                    sys.exit(0)
                memanager.setJsonPath(JsonPath)
            if opt in ("-t", "--actioncontinue"):
                actioncontinue = arg
            if opt in ("-n", "--noninteractive"):
                cmds=arg
            if opt in ("-a", "--appid"):
                appid=arg
                memanager.setAppid(appid)

        if cmds:
            for arg in cmds.split():
                modulePerforms(stringToOpts(arg))
                if arg == "l":
                    print("Sleeps for WebSocket creation.")
                    time.sleep(2)
            if actioncontinue != "True":
                sys.exit(0)
        elif cookie:
            print sys.argv[0], " [-t <actioncontinue>] [-p <json path>] [-n <cmds>] [-a <appid>]"
            sys.exit(1)
        elif not JsonPath:
            print sys.argv[0], " [-t <actioncontinue>] [-p <json path>] [-n <cmds>] [-a <appid>]"
            sys.exit(1)
    if actioncontinue != "True":
        usage(sys.argv[0] + ': ' + gLevel)
    while True:
        command = raw_input('\n>>>Please enter a command:')
        opts = stringToOpts(command)
        modulePerforms(opts)
        time.sleep(0.5)

