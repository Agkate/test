#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

UE_IP=192.168.200.1
EPC_IP=192.168.219.185
ENB_IP=192.168.219.179
MME_IP=192.168.219.181
LBP_IP=192.168.100.118
LBP_NES_IP=192.168.4.1

LBP_LOGIN=root
LBP_PASS=root

# VM
VM1_MGMT_IP=192.168.100.34
VM2_MGMT_IP=192.168.100.116
VM_NES_MGMT_IP=192.168.100.115
VM1_NES_IP=192.168.1.5
VM1_NAME=vm0
VM2_NES_IP=192.168.1.6
VM2_NAME=vm1
VM_LOGIN=root
VM_PASSWORD=root
VM_NES_ETH=eth1

MEAPP_VM_PATH='/root/smoke_test/samples/meapp'

MGMT_NET='tenant-mgmt-net'
LOG_FILE="../result/smoke_test.log"

#get list of all VMs
#if [ -z "$VM1_NAME" -o -z "$VM2_NAME" ]; then
#	VM_LIST=($(nova list | grep "ACTIVE" | tr -s '|' | cut -d ' ' -f 4 -s))
#	VM1_NAME=${VM_LIST[0]}
#	VM2_NAME=${VM_LIST[1]}
#fi

TRAFFIC_FILE=json/trafficRule/trafficRules.json

#$1 IP
#$2 login
#$3 password
#$4 command
function exec_on_remote()
{
	expect <<-EOF
	set timeout 130
	spawn ssh -q -o PreferredAuthentications=password -o PubkeyAuthentication=no $2@$1 "$4"
	expect "*assword:"
	send "$3\r"
	expect eof
	EOF
}


#$1 VM_IP
#$2 command
function exec_on_vm()
{
	if [ -z "$1" ]; then
		echo "no parameter"
	fi
	ssh -q ${VM_LOGIN}@$1 "$2" || return 1
	return 0
}


#$1 - VM_IP
#$2 - ACTION(CREATE,REMOVE)
#$3 - VMID
#$4 - MAC address
#$5 - srv_ip,ue_ip,enb_ip,epc_ip,srv_port,ue_port
#$6 - ip/port
#$7 - ip_mask
function modify_route()
{
	local MEAPP_CMD=t
	local ANSWER="\[OK\] Mobile Edge Traffic Rule Creation"

	#exec_on_vm $1 "mkdir -p ${MEAPP_VM_PATH}/log"

	if [ "$2" == "REMOVE" ]; then
		MEAPP_CMD=r
		ANSWER="\[OK\] Mobile Edge Traffic Rule Removal"
	fi

	local RULE=""

	if [[ $5 == *"_ip" ]]; then
		RULE="	\"name\":\"$5\",
					\"ip\":\"$6\",
					\"ip_mask\":$7"
	elif [[ $5 == *"_port" ]]; then
		RULE="	\"name\":\"$5\",
					\"min\":$6,
					\"max\":$7"
	fi

	local JSON="{
	\"vmId\":$3,
	\"macAddress\":\"$4\",
	\"trafficRule\":
		{
			\"prio\":99,
			\"ruleFields\":[
				{
					$RULE
				}
			]
		}
	}"

	#echo $JSON
	#echo IP=$1

	echo "${JSON}" | ssh -q ${VM_LOGIN}@${1} "cd ${MEAPP_VM_PATH}; cat > $TRAFFIC_FILE; python $MEAPP_VM_PATH/meapp.py -n \"o n s z t $MEAPP_CMD\" -f trafficRules;" 2>&1 | tee json.log | grep "^$ANSWER"
        if [ $? == 0 ]; then
		echo "ROUTE $2D"
		return 0
	fi
	echo "Unable to $2 route"
	return 1
}

#$1 VM_IP
#$2 ethernet
function get_MAC_addr()
{
	exec_on_vm $1 "ifconfig $2 | grep -o -E '([[:xdigit:]]{1,2}:){5}[[:xdigit:]]{1,2}'"
}

#$1 state
#$2 test case
#$3 description
function put_result()
{
	local LOG_TXT=""
	if [ "$1" = 1 ];then
                LOG_TXT="[Fail] case$2: $3 failed"
	else
		LOG_TXT="[Pass] case$2: $3 successful"
	fi
	echo $LOG_TXT >> $LOG_FILE
	echo $LOG_TXT
}

#$1 parameters
function do_iperf()
{
	iperf3 $1 2>&1 | tee iperf.log | grep "^iperf Done"
        if [ $? == 0 ]; then
                echo "iperf3 succeed"
                return 0
        fi
        echo "iperf3 failed"
        return 1
}

#$1 VM_IP
function copy_sshkey_to_vm()
{
	local SSHSRCKEYFILE=~/.ssh/id_rsa

	#check if ssh key file exists
	if [ ! -f "${SSHSRCKEYFILE}.pub" ]; then
		ssh-keygen -t rsa -f ${SSHSRCKEYFILE} -q -N ""
	fi
	if [ -f "${SSHSRCKEYFILE}.pub" ]; then
		expect <<-EOF
		set timeout 130
		spawn bash -c "cat ${SSHSRCKEYFILE}.pub | ssh -q -o StrictHostKeyChecking=no -o PreferredAuthentications=password -o PubkeyAuthentication=no ${VM_LOGIN}@$1 'mkdir -p ~/.ssh && cat >  ~/.ssh/authorized_keys' 2>&1"
		expect "*assword:"
		send "$VM_PASSWORD\r"
		expect eof
		EOF
		return 0
	fi
	return 1
}

#$1 VM_IP
function rem_sshkey_in_vm()
{
	local SSHKEY=$(cat ~/.ssh/id_rsa.pub)

	exec_on_vm $1 "sed -i '\|$SSHKEY|d' ~/.ssh/authorized_keys"
}

if [ -z "${UE_MAC}" ]; then
	export UE_MAC=$(ifconfig -a | grep ${UE_IP} -B 1 | grep -o -E '([[:xdigit:]]{1,2}:){5}[[:xdigit:]]{1,2}')
fi
