#!/usr/bin/expect
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

set timeout 10
log_user 0

spawn ssh -q -o StrictHostKeyChecking=no $::env(DEV1_USER)@$::env(DEV1_IP)

set timeout 30

#invoke route del
send "cd ~/$::env(ROUTE_DEL_PATH); PYTHONPATH=.. python $::env(ROUTE_DEL_NAME) -vDEBUG \
--root-ca=root-ca.pem \
--certificate=$::env(ROUTE_DEL_KEY).cert.pem \
--private-key=$::env(ROUTE_DEL_KEY).private.key \
--client-id=$::env(ROUTE_DEL_DEVICE_ID) \
--topic=$::env(ROUTE_DEL_TOPIC) $::env(ROUTE_DEL_MODE) \
--mec-action $::env(ROUTE_DEL_ACTION) $::env(ENDPOINT)\r"


expect {
    timeout { send_user "\nTimeout on $::env(DEV1_IP).\n"; exit 1}
    "*No such file or directory" { send_user "\nFailed to find directory on $::env(DEV1_IP)\n"; exit 1 }
    "*{\"result\": \"*successfully\"}*" { send_user "\nRoute deleted successfully.\n" }
}

set timeout 30

send "ping $::env(GG_CORE1) -c 4\r"

expect {
    timeout { send_user "\nTimeout on $::env(DEV1_IP). Ping to $::env(GG_CORE1) is not working.\n" }
    "*4 packets transmitted, 4 received*" { send_user "\nPing to $::env(GG_CORE1) is working.\n"; exit 1 }
    "*4 packets transmitted, 0 received*" { send_user "\nPing to $::env(GG_CORE1) is not working.\n"  }
}

set timeout 30

send "cd ~/$::env(SAMPLE_PATH_1); \
PYTHONPATH=../.. python $::env(SCRIPT_NAME_1) -vDEBUG \
--root-ca=root-ca.pem \
--certificate=$::env(KEY_1).cert.pem \
--private-key=$::env(KEY_1).private.key \
--client-id=$::env(CLIENT_ID_1) \
--topic 'mec/rtt' \
--thing $::env(DEVICE_ID_1) \
--core-arn=$::env(CORE_ARN) $::env(ENDPOINT)\r"


expect {
    timeout { send_user "\nTimeout on $::env(DEV1_IP). Shadow device is hold on prompt\n" }
    "*Keep-alive: 600.000000 sec*" { send_user "\nKeep-alive: 600.000000 sec. Shadow device is hold on prompt.\n" }
    "*AWSIoTPythonSDK.core.protocol.mqtt_core - INFO - Keep-alive: 600.000000 sec*" { send_user "\nShadow device is hold on prompt - Keep-alive.\n" }
    "*Filling in fixed event callbacks: CONNACK, DISCONNECT, MESSAGE*" { send_user "\nFilling in fixed event callbacks...\n" }
}
send "\x03\r"
send "exit\r"
close
