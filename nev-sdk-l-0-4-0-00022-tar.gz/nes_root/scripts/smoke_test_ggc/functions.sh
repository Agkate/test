#!/bin/bash
#########################################################
# INTEL CONFIDENTIAL
# Copyright 2009-2018 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission.
# 
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intel's suppliers
# or licensors in any way.
# 
#  version: NEV_SDK.L.0.4.0-00022
#########################################################

#$1 IP
#$2 username
#$3 command
function exec_on_remote()
{
    if [ -z "$1" ]; then
            echo "no parameter"
    fi
    ssh ${2}@${1} "${3}" || return 1
    return 0
}

#$1 state
#$2 test case
#$3 description
function put_result()
{
    local LOG_TXT=""
    if [ "$1" = 1 ];then
            LOG_TXT="[Fail] case$2: $3 failed"
    else
            LOG_TXT="[Pass] case$2: $3 successful"
    fi
    echo $LOG_TXT >> $LOG_FILE
    echo $LOG_TXT
}

#$1 parameters
function do_iperf()
{
    iperf3 $1 2>&1 | tee iperf.log | grep "^iperf Done"
    if [ $? == 0 ]; then
            echo "iperf3 succeed"
            return 0
    fi
    echo "iperf3 failed"
    return 1
}

#$1 IP
#$2 username
#$3 password
function copy_sshkey_to_remote()
{
    local SSHSRCKEYFILE=~/.ssh/id_rsa

    #check if ssh key file exists
    if [ ! -f "${SSHSRCKEYFILE}.pub" ]; then
	ssh-keygen -t rsa -f ${SSHSRCKEYFILE} -q -N ""
    fi
    if [ -f "${SSHSRCKEYFILE}.pub" ]; then
        expect <<-EOF
	set timeout 130
	spawn bash -c "cat ${SSHSRCKEYFILE}.pub | ssh -q -o StrictHostKeyChecking=no -o PreferredAuthentications=password -o PubkeyAuthentication=no ${2}@${1} 'mkdir -p ~/.ssh && cat >>  ~/.ssh/authorized_keys' 2>&1"
	expect "*assword:"
	send "${3}\r"
	expect eof
	EOF
	return 0
    fi
    return 1
}

#$1 IP
#$2 username
function rem_sshkey_in_remote()
{
    local SSHKEY=$(cat ~/.ssh/id_rsa.pub)
    exec_on_remote "${1}" "${2}" "sed -i '\|$SSHKEY|d' ~/.ssh/authorized_keys"
}

#$1 device_name
function get_key_prefix()
{
    CERT_FILEPATH=$(find ${1} -name "*.cert.pem")
    CERT_FILENAME=$(basename -- ${CERT_FILEPATH})
    echo ${CERT_FILENAME%*.cert.pem}
}

#$1 device_name
function check_dev_res()
{
    if [ -d "${GG_HELLO_PUB_NAME}" ]; then
        local CERT=$(find ${1} -name "*.cert.pem")
        local ROOT_KEY=$(find ${1} -name "root-ca.pem")
        local PRIV_KEY=$(find ${1} -name "*.private.key")
        if [ ! -f "${CERT}" ]; then
            echo "No \"*.cert.pem\" file for \"${1}\" device in \"${PWD}/${1}\" directory"
            return 1
        fi
        if [ ! -f "${ROOT_KEY}" ]; then
            echo "No \"root-ca.pem\" file for \"${1}\" device in \"${PWD}/${1}\" directory"
            return 1
        fi
        if [ ! -f "${PRIV_KEY}" ]; then
            echo "No \"*.private.key\" file for \"${1}\" device in \"${PWD}/${1}\" directory"
            return 1
        fi
        return 0
    fi
    echo "Copy \"${1}\" device resource files to \"${PWD}/${1}\" directory"
    return 1
}

#$1 src
#$2 dst IP
#$3 dst user
#$4 dst path
function copy_to_remote()
{
    scp -r ${1} ${3}@${2}:${4}/
}
