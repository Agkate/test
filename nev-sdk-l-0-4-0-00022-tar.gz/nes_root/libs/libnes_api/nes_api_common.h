/************************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2009-2018 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intel's prior express written permission.
 * 
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intel's suppliers
 * or licensors in any way.
 * 
 *  version: NEV_SDK.L.0.4.0-00022
 * ************************************************************************************/
/**
 * @file nes_api_common.h
 * @brief Common header file for NES daemon and external client
 *
 * Contains definitions shared between NES daemon and NES API user.
 * Should not be included directly, but it is not prohibited.
 */
#ifndef _NES_API_COMMON_H_
#define _NES_API_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __DOXYGEN__
#ifdef NES_DAEMON
#include <rte_ether.h>
#include <rte_ip.h>
#else
#include <netinet/ether.h>
#include <netinet/ip.h>
#endif /* NES_DAEMON */
#endif /*__DOXYGEN__*/

/** Size of ctrl device or ring name string */
#define CTRL_NAME_SIZE 15

/**
 * NES error return values
 */
enum NES_ERROR {
    /**
     * on success
     */
    NES_SUCCESS = 0,
    /**
     * on failure
     */
    NES_FAIL
};

/**
 * NTS editing modes.
 * Except NULL_CALLBACK all edit modes assume forwarding after packet is modified.
 */
typedef enum {
    /**
     * Special purpose "do-not-touch" mode
     */
    NTS_EDIT_NULL_CALLBACK,
    /**
     * Actions: decapsulate and forward
     */
    NTS_EDIT_DECAP_ONLY,
    /**
     * Actions: do not decapsulate, forward
     */
    NTS_EDIT_NODECAP,
    /**
     * Actions: decapsulate, replace service IP with VM IP, forward
     */
    NTS_EDIT_DECAP_IP_REPLACE,
    /**
     * Actions: update reference counter and send the packet to the VM
     */
    NTS_EDIT_MIRROR,
    /**
     * Actions: update reference counter, send the packet to the VM and send it upstream or downstream.
     */
    NTS_EDIT_MIRROR_LAST
} nts_edit_modes_t;


/**
 * Route entry contents.
 */
typedef struct nes_route_entry_data_s {
    /**
     * VM MAC address (a placeholder).
     */
    struct ether_addr macaddr;
    /**
     * VM IP address (a placeholder).
     */
    struct in_addr    ipaddr;
    /**
     * VM identifier.
     */
    int               vmid;
    /**
     * Callback mode.
     */
    nts_edit_modes_t  cbmode;
} nes_route_entry_data_t;

/**
 * Statistics for device structure
 */
typedef struct nes_dev_stats_s {
    /**
     * Number of packets received
     */
    uint64_t  rcv_cnt;
    /**
     * Number of packets sent
     */
    uint64_t  snd_cnt;
    /**
     * Number of packets dropped (caused by a TX buffer overflow)
     */
    uint64_t  drp_cnt_1;
    /**
     * Number of packets dropped (read from physical card)
     */
    uint64_t  drp_cnt_2;
    /**
     * Number of bytes received
     */
    uint64_t  rcv_bytes;
    /**
     * Number of bytes sent
     */
    uint64_t  snd_bytes;
    /**
     * Number of bytes dropped (caused by a TX buffer overflow)
     */
    uint64_t  drp_bytes_1;
    /**
     * Number of IP fragmented packets
     */
    uint64_t  ip_fragment;
} __attribute__ ((__packed__)) nes_dev_stats_t;

/**
 * Statistics for ring structure
 */
typedef struct nes_ring_stats_s {
    /**
     * Number of packets received
     */
    uint64_t  rcv_cnt;
    /**
     * Number of packets sent
     */
    uint64_t  snd_cnt;
    /**
     * Ring Full dropped packets counter
     */
    uint64_t  drp_cnt_1;
    /**
     * No Route dropped packets counter
     */
    uint64_t  drp_cnt_2;

} __attribute__ ((__packed__)) nes_ring_stats_t;

#define VERIFY_PTR_OR_RET(ptr, ret_val) do {    \
                        if (NULL == (ptr))      \
                            return (ret_val);   \
                        } while(0)


#ifdef __cplusplus
}
#endif
#endif /* _NES_API_COMMON_H_ */

